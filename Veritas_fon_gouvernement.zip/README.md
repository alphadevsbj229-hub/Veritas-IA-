# Veritas BJ

Assistant conversationnel qui interroge Wikipédia, DuckDuckGo, Wikidata,
Google News, le web ouvert (via recherche élargie) et — pour tout ce qui
concerne le Bénin — directement les sites officiels de l'État béninois. Il
croise les résultats et formule sa réponse via un **moteur IA local**
(Ollama, gratuit, tourne sur ton PC — voir `AI_LOCAL.md`), avec repli
automatique sur des templates si le moteur local n'est pas installé. Aucune
dépendance à Claude, ChatGPT ou Gemini n'est nécessaire au fonctionnement de
l'application.

*Développé par AlphaDevs BJ 🦁 — alphadevsbj229@gmail.com*

## Démarrage rapide

1. **[AI_LOCAL.md](./AI_LOCAL.md)** — installer le moteur IA local (Ollama) sur ton PC Windows. Recommandé, mais optionnel : sans lui, Veritas fonctionne quand même, juste avec une formulation plus simple.
2. Section "1. Lancer le backend" ci-dessous
3. Section "2. Lancer le frontend" ci-dessous

## Structure du projet

Tous les fichiers principaux sont à la racine, le moteur IA dans `ai/` :

```
veritas/
├── app.py                 # Serveur Flask : recherche + API + config DB
├── config.py                # Configuration centralisée (modèle IA, endpoints...)
├── ai/
│   ├── provider.py            # Interface AIProvider (contrat commun)
│   ├── local_provider.py       # Implémentation Ollama (moteur local)
│   └── __init__.py              # Fabrique get_ai_provider()
├── models.py               # Modèles de base de données (User, Conversation, Message)
├── auth.py                 # Inscription / connexion / tokens JWT / mots de passe hashés (bcrypt)
├── conversations.py        # Sauvegarde et récupération des conversations
├── humanizer.py             # Reformulation naturelle des réponses (sans invention de faits)
├── requirements.txt
├── index.html               # Interface de chat + écrans de connexion/inscription
├── style.css                 # Thème sombre façon ChatGPT/Claude
├── app.js                     # Logique (auth, conversations, appels API)
├── manifest.json               # Permet d'installer l'appli sur téléphone
├── icon-192.png / icon-512.png  # Icônes de l'appli (générées depuis le logo fourni)
├── render.yaml                   # Config de déploiement automatique sur Render
├── veritas.db                     # Base SQLite (créée automatiquement au 1er lancement)
└── .secret_key                     # Clé de signature des sessions (générée automatiquement)
```

## Interface

- **Mode sombre / mode clair** : bouton 🌙/☀️ dans la sidebar (et sur l'écran de connexion). Le choix est mémorisé sur l'appareil et appliqué immédiatement au chargement, sans flash blanc/noir — comme sur Claude.ai ou ChatGPT.
- **Style façon Claude/ChatGPT** : sidebar avec historique des conversations, bulles de discussion, avatar (photo de profil si connecté avec Google, sinon initiale), indicateur de saisie animé, mise en page centrée et responsive (mobile + desktop).
- **Sujet le plus populaire du jour** : au premier message de chaque nouvelle conversation, Veritas te salue et te dit de quoi tout le monde parle aujourd'hui (classement réel des pages Wikipédia les plus consultées la veille — pas une invention). Si tu réponds simplement "oui", "dis-m'en plus", "c'est quoi ?", etc., Veritas te donne directement l'info complète avec ses sources, sans que tu aies à reformuler la question.

## Connexion avec Google (optionnel)

Par défaut, seule la connexion par email/mot de passe est active. Pour activer aussi "Se connecter avec Google" :

1. Va sur [Google Cloud Console → Identifiants](https://console.cloud.google.com/apis/credentials)
2. Crée un projet (ou utilise un projet existant), puis **Créer des identifiants → ID client OAuth**
3. Type d'application : **Application Web**
4. Dans **Origines JavaScript autorisées**, ajoute l'URL exacte où tourne ton frontend (ex. `http://localhost:8080`, ou ton URL de production)
5. Copie l'**ID client** généré (il ressemble à `123456789-xxxx.apps.googleusercontent.com`)
6. Colle-le à deux endroits :
   - dans `app.js`, ligne `const GOOGLE_CLIENT_ID = "";` → mets ton ID entre les guillemets
   - côté serveur, définis la variable d'environnement `GOOGLE_CLIENT_ID` avec la même valeur avant de lancer `python app.py` (ou dans les "Environment Variables" de Render si tu déploies en ligne)

Sans cette configuration, le bouton Google reste simplement invisible et l'appli fonctionne normalement avec email/mot de passe.

**Sécurité :** le jeton envoyé par Google est vérifié cryptographiquement côté serveur (signature + audience) via la bibliothèque officielle `google-auth` avant de créer ou connecter le compte — jamais de confiance aveugle dans ce que le frontend prétend recevoir.

## Sécurité du compte

- Les mots de passe ne sont **jamais stockés en clair** : ils sont hashés avec `bcrypt` avant d'être sauvegardés en base.
- La connexion utilise des **tokens JWT** signés, valables 30 jours, envoyés dans le header `Authorization: Bearer <token>` de chaque requête protégée.
- Chaque conversation est liée à l'`user_id` — impossible pour un utilisateur de voir les conversations d'un autre.
- Le mot de passe doit faire au moins 8 caractères avec au moins une lettre et un chiffre.

## 1. Lancer le backend (obligatoire, sur ton ordinateur)

```bash
pip install -r requirements.txt
python app.py
```

Le serveur tourne sur `http://localhost:5000` en mode production (pas de trace d'erreur détaillée). Pour du débogage local uniquement : `FLASK_DEBUG=1 python app.py`.

**Important en production :** définis aussi `ALLOWED_ORIGINS` avec l'URL exacte de ton frontend déployé (ex. `ALLOWED_ORIGINS=https://mon-frontend.com`), sinon le navigateur bloquera les appels API depuis ton propre site (protection CORS).

## 2. Lancer le frontend

Le plus simple pour un test rapide sur ton ordinateur :

```bash
python -m http.server 8080
```

Puis ouvre `http://localhost:8080` dans ton navigateur (ça sert `index.html`).

## 3. Utiliser Veritas sur ton téléphone (installation en appli)

Le backend Flask doit être accessible depuis ton téléphone. Deux options :

**Option simple (même réseau Wi-Fi) :**
1. Trouve l'adresse IP locale de ton ordinateur (`ipconfig` sur Windows, `ifconfig` sur Mac/Linux — cherche un truc du genre `192.168.1.XX`)
2. Dans `app.js`, remplace la ligne :
   ```js
   const API_BASE = "http://localhost:5000";
   ```
   par :
   ```js
   const API_BASE = "http://192.168.1.XX:5000";
   ```
3. Sur ton téléphone, connecté au même Wi-Fi, ouvre `http://192.168.1.XX:8080` dans Chrome
4. Menu Chrome (⋮) → "Ajouter à l'écran d'accueil" → Veritas s'installe comme une vraie appli

**Option en ligne (accessible partout) :** voir `DEPLOIEMENT.md` (déploiement du backend sur Render, gratuit).

## Comment ça marche

- **Recherche multi-sources élargie** : chaque question interroge Wikipédia (français, puis anglais en repli si rien n'est trouvé), DuckDuckGo, Wikidata, Google News, Wikinews (repli actualité), Wiktionnaire (repli définitions), **et désormais une recherche web ouverte** (via DuckDuckGo HTML, sans clé API) qui va lire directement des pages de sites institutionnels/officiels non couverts par les API structurées ci-dessus. Si au moins deux sources répondent, la réponse est marquée "✓ Vérifiée sur N sources".
- **Objectif Veritas BJ — sites officiels du Bénin** : si la question concerne le Bénin (mot-clé détecté : Bénin, Cotonou, Porto-Novo, un sigle administratif béninois, etc.), Veritas interroge en priorité une liste de **21 domaines officiels béninois vérifiés manuellement** : `gouv.bj`, `presidence.bj`, `assemblee-nationale.bj`, `sgg.gouv.bj` (textes officiels), `journalofficiel.gouv.bj`, `finances.bj`, `impots.finances.gouv.bj` (DGI), `e-services.impots.bj` (télédéclaration), `douanes.gouv.bj`, `justice.gouv.bj`, `diplomatie.gouv.bj`, `developpement.gouv.bj`, `service-public.bj`, `marches-publics.bj`, `andf.bj` (foncier/cadastre), `evisa.gouv.bj`, `dei.gouv.bj` (immigration/passeports), `ravip.bj`, `anip.bj` (identification), `instad.bj` (statistiques, ex-INSAE) et `apdp.bj`. Selon les mots-clés de la question (visa, passeport, statistique, impôt, douane, foncier, décret, assemblée nationale...), Veritas cible directement le site le plus pertinent. Cette liste est volontairement limitée aux domaines confirmés — mieux vaut peu de sources fiables que des URLs devinées.
- **"Pour aller plus loin"** : en plus du résumé, Veritas récupère les liens "Voir aussi" et liens externes cités en bas de l'article Wikipédia trouvé, affichés sous la réponse pour que l'utilisateur puisse approfondir directement depuis l'appli.
- **Fait du jour** : au démarrage, l'appli affiche "Bonjour [prénom], saviez-vous que..." avec un événement historique du jour (`onthisday` de Wikipédia).
- **Formulation naturelle ("demi-IA")** : les réponses sont introduites et articulées avec des tournures conversationnelles variées (module `humanizer.py`) plutôt que d'être un copier-coller brut d'article, avec une vraie synthèse quand plusieurs sources concordent. **Important à comprendre** : ce n'est toujours pas une IA générative — le contenu factuel reste strictement extrait des sources, seule la mise en forme est plus naturelle. Le module ne reformule jamais au point de risquer de déformer un fait ; en cas de doute, il juxtapose les extraits plutôt que de les fusionner. Pour de vraies réponses reformulées en profondeur, il faudrait une API comme Claude (payante).
- **Sauvegarde résiliente** : chaque message est mis en file d'attente locale et retenté automatiquement (avec délai progressif) jusqu'à confirmation du serveur — utile car le plan gratuit Render met du temps à se réveiller après une pause. Un indicateur dans la sidebar affiche l'état de synchronisation.
- **Compte utilisateur** : inscription par email + mot de passe. Les conversations sont sauvegardées côté serveur (base SQLite), liées à ton compte — tu les retrouves en te connectant depuis n'importe quel appareil, tant qu'il pointe vers le même backend.

## Mise à jour depuis une version précédente

Si tu avais déjà lancé Veritas avant (un fichier `veritas.db` existe déjà), **supprime-le** avant de relancer le serveur si tu viens d'une version dont la structure de base de données diffère. Il sera recréé automatiquement, vide, au prochain démarrage. Sur Render, un redéploiement recrée la base automatiquement (le disque gratuit est de toute façon éphémère, voir `DEPLOIEMENT.md`).

## Limites connues (important à comprendre)

- Ce n'est **pas une IA générative** : elle ne "comprend" pas la question, elle cherche des articles/pages qui correspondent aux mots-clés. Une reformulation étrange donnera parfois un mauvais résultat.
- DuckDuckGo Instant Answer répond bien aux questions factuelles courtes, mais pas aux questions complexes ou conversationnelles ; la recherche web élargie (scraping HTML) compense en partie mais reste plus fragile qu'une vraie API de recherche (elle peut casser si DuckDuckGo change son HTML).
- La liste de sites officiels béninois n'est pas exhaustive — elle ne contient que des domaines vérifiés manuellement. Si une administration manque, elle peut être ajoutée dans `BENIN_OFFICIAL_SITES` (`app.py`) une fois son domaine confirmé.
- Pour de vraies réponses reformulées et plus "intelligentes", il faudrait brancher une API comme Claude ou OpenAI (payante) — je peux te montrer comment faire si tu veux évoluer plus tard.
