# ARCHITECTURE.md — Comment Veritas BJ fonctionne

## Vue d'ensemble

```
Utilisateur (navigateur, PWA installée)
        ↓
index.html / app.js (thème clair-sombre, conversations, auth)
        ↓
API Flask (app.py)
        ↓
Orchestrateur (ai/orchestrator.py) — détecte l'intention
        ↓
   ┌────────────┬─────────────┬──────────────┬───────────────────┐
   │ IDENTITY   │ CALCULATION │ CONVERSATION │ SEARCH             │
   │ (texte fixe)│ (tools/     │ (IA locale ou│ (build_answer :   │
   │            │ calculator) │ repli simple)│ sources en//)      │
   └────────────┴─────────────┴──────────────┴───────────────────┘
                                                        ↓
                                        Wikipédia, DuckDuckGo, Wikidata,
                                        Google News, sites officiels Bénin,
                                        base de connaissances (RAG),
                                        recherche web élargie
                                                        ↓
                                        Détection de contradictions
                                        chiffrées (verification_status)
                                                        ↓
                                        Formulation (ai/local_provider.py
                                        ou ai/gemini_provider.py, repli sur
                                        humanizer.py si indisponible)
                                                        ↓
                                        Réponse + sources + statut
```

## Principe fondamental : les faits ne viennent jamais du modèle de langage

Le modèle IA (local via Ollama, ou Gemini en option) ne sert **jamais** de
source de connaissance. Son rôle se limite à trois choses :
1. Résoudre le contexte conversationnel ("il" → la personne mentionnée avant)
2. Générer une reformulation naturelle d'extraits déjà trouvés par la recherche
3. Répondre aux salutations/questions de politesse

Tous les faits proviennent des sources (Wikipédia, sites officiels, base de
connaissances...), jamais inventés par le modèle. Si le modèle IA n'est pas
disponible, Veritas continue de fonctionner avec `humanizer.py` (templates).

## Fournisseurs IA (`ai/`)

`ai/provider.py` définit l'interface `AIProvider` (contrat : `is_available()`,
`generate()`). Deux implémentations existent :
- `ai/local_provider.py` → `OllamaProvider` (défaut, recommandé, gratuit, local)
- `ai/gemini_provider.py` → `GeminiProvider` (optionnel, cloud, jamais requis)

`ai/__init__.py::get_ai_provider()` choisit l'implémentation selon
`config.AI_PROVIDER`. Le reste du code (`app.py`) n'appelle jamais
`OllamaProvider` ou `GeminiProvider` directement — toujours via cette
fabrique. Ajouter un futur fournisseur (OpenAI, Anthropic...) ne demande
qu'un nouveau fichier `ai/xxx_provider.py` + une branche dans la fabrique.

## Orchestrateur (`ai/orchestrator.py`)

`detect_intent(query)` classe chaque question en 4 catégories routées
différemment aujourd'hui : `IDENTITY`, `CALCULATION`, `CONVERSATION`,
`SEARCH`. Les autres intentions prévues par le projet (BENIN, HISTORY,
GEOGRAPHY, DOCUMENT...) existent comme documentation/extension future mais
tombent toutes dans `SEARCH` pour l'instant — les séparer n'apporterait rien
tant qu'elles n'ont pas chacune un traitement différent (`ALL_INTENTS` dans
le fichier liste ce qui est prévu).

## Recherche multi-sources (`app.py::build_answer`)

Toutes les sources indépendantes sont interrogées **en parallèle**
(`ThreadPoolExecutor`), pas en série — une question béninoise peut déclencher
jusqu'à 6 recherches simultanées (sites officiels, base de connaissances,
Wikipédia, DuckDuckGo, Wikidata, actualité). Une source qui échoue est
loggée et ignorée, jamais bloquante pour les autres.

## Base de connaissances Bénin (`rag/`)

Pipeline RAG minimal, sans dépendance lourde (pas de FAISS/Chroma) :
`rag/ingest.py` découpe les documents de `knowledge/benin/` en morceaux et
calcule leurs embeddings via Ollama (`nomic-embed-text`), stockés dans un
index JSON. `rag/retrieve.py` compare l'embedding de la question à l'index
par similarité cosinus (Python pur). Reconstruction manuelle après ajout
d'un document (`python -m rag.ingest`), pas automatique — voir AI_LOCAL.md.

## Vérification (`app.py::detect_numeric_contradiction`)

Détection **bornée** : repère quand deux sources citent un chiffre différent
pour la même unité (ex. "15 milliards" vs "17 milliards"). Ce n'est pas un
système complet d'extraction d'affirmations et de fact-checking sémantique
— une contradiction non chiffrée (deux dates différentes en toutes lettres,
par exemple) n'est pas détectée aujourd'hui. `verification_status` reflète
ce qui est réellement vérifié : `CONFIRMED`, `CONTRADICTED`, `UNCONFIRMED`,
`INSUFFICIENT_EVIDENCE`.

## Mémoire conversationnelle (`app.py::resolve_query_with_context`)

Fenêtre bornée aux 8 derniers messages (jamais tout l'historique), envoyée
par `app.js` à chaque question. Si le moteur IA est disponible, la question
est reformulée en une version autonome avant la recherche ("il" résolu en
son référent). Sans moteur IA, la question part inchangée — pas de vrai
résumé automatique des très longues conversations (limite assumée).

## Authentification (`auth.py`, `models.py`)

Email/mot de passe (bcrypt) ou Google OAuth (jeton vérifié
cryptographiquement, jamais de confiance aveugle). Sessions par JWT signé
avec un `jti` unique par token, permettant une **révocation réelle** au
logout (table `RevokedToken`) — pas juste un effacement local côté
navigateur.

## Sécurité transversale

Voir `SECURITY.md` pour le détail complet (CORS, rate limiting, SSRF,
logs, secrets).

## Base de données (`models.py`)

SQLite par défaut (aucune installation), PostgreSQL supporté via
`DATABASE_URL` en production. Migrations gérées par Flask-Migrate/Alembic
(voir `MIGRATIONS.md`) plutôt que `db.create_all()` une fois en production.

## Analyse de documents (`tools/document.py`)

PDF, DOCX et TXT (`pypdf` pour les PDF, `python-docx` pour les DOCX,
tableaux compris). Un PDF scanné (image sans couche de texte) peut être lu
via OCR (PyMuPDF + pytesseract) si `OCR_ENABLED=1` — désactivé par défaut,
non testé faute de binaire Tesseract disponible en développement.

Documents longs : découpés en morceaux (~12 000 caractères chacun, jusqu'à
8 morceaux) et traités en **map-reduce** pour le résumé (chaque morceau
résumé séparément puis combiné), et par **sélection des morceaux les plus
pertinents par similarité** (embeddings Ollama déjà utilisés pour le RAG)
pour les questions/réponses — au lieu d'une simple troncature au début du
document. Au-delà de 8 morceaux, le document est encore tronqué
(honnêtement signalé via `truncated`).

Deux modes : résumé ou question/réponse, tous deux **entièrement dépendants
du moteur IA** — contrairement à la recherche, cette fonctionnalité n'a pas
de repli par templates (un résumé fiable nécessite une vraie compréhension
du texte), et renvoie une erreur claire (503) si aucun moteur IA n'est
disponible plutôt que de prétendre fonctionner. Accessible depuis le chat
via le bouton 📎.

## Ce qui n'est PAS construit (transparence, point 45)

- OCR non testé en conditions réelles (pas de Tesseract disponible en développement) — le code existe mais reste désactivé par défaut
- Mémoire utilisateur à long terme (préférences retenues d'une session à l'autre) — point 11, différent de la mémoire conversationnelle déjà construite
- Vrai résumé automatique des conversations très longues
- Extraction d'affirmations générale pour le fact-checking (seule la contradiction chiffrée est détectée)
