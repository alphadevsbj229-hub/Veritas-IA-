"""
Veritas BJ - Configuration centralisée du moteur IA
-----------------------------------------------------
Un seul endroit pour changer de modèle ou de fournisseur — jamais de nom de
modèle ou d'URL en dur ailleurs dans le code (voir point 7 du cahier des
charges Veritas BJ).

Pour changer de modèle : change AI_PROFILE (une variable d'environnement),
PAS le code. Exemple (Windows, PowerShell) :

    $env:AI_PROFILE = "confort"
    python app.py

Développé par AlphaDevs BJ 🦁
"""

import os

# "local" est le seul fournisseur nécessaire au fonctionnement de Veritas BJ.
# D'autres valeurs ("openai", "anthropic", ...) pourront être ajoutées plus
# tard SANS jamais devenir obligatoires — Veritas BJ doit toujours pouvoir
# fonctionner à 100% sans clé API externe.
AI_PROVIDER = os.environ.get("AI_PROVIDER", "local")

# Ollama tourne en local par défaut sur ce port, aucune configuration requise
# après installation (voir AI_LOCAL.md).
LOCAL_AI_ENDPOINT = os.environ.get("LOCAL_AI_ENDPOINT", "http://localhost:11434")

# ---------------------------------------------------------------------------
# Profils de modèle — prêts à l'avance, tu bascules quand TU veux
# ---------------------------------------------------------------------------
# L'idée : les trois profils sont déjà définis ici. Tu démarres avec "minimal"
# (PC Windows classique, CPU seul). Le jour où tu as le matériel pour "confort"
# ou "élevé", tu changes juste AI_PROFILE — aucune ligne de code à toucher.
#
# ATTENTION (honnêteté) : ce switch est gratuit et instantané côté LOGICIEL.
# Il ne remplace PAS le matériel nécessaire. Si tu passes à "eleve" sans avoir
# le GPU qui va avec, Ollama sera soit incapable de charger le modèle (pas
# assez de RAM/VRAM), soit extrêmement lent (le système "swap" sur le disque
# dur, ce qui peut prendre plusieurs MINUTES par réponse au lieu de secondes).
AI_PROFILES = {
    "minimal": {
        "model": "llama3.2:3b",
        "description": "PC Windows standard, CPU seul, 8 Go RAM libre",
    },
    "confort": {
        "model": "llama3.1:8b",
        "description": "16 Go RAM, ou petit GPU 6-8 Go VRAM (ex. RTX 4060 Ti 16 Go)",
    },
    "eleve": {
        "model": "llama3.1:70b",
        "description": (
            "GPU sérieux obligatoire : 2x RTX 4090 (48 Go VRAM cumulés) ou "
            "1x A100/H100 80 Go — voir nos échanges sur le matériel. "
            "Sans ce matériel, ce profil ne fonctionnera pas correctement."
        ),
    },
}

_profile_name = os.environ.get("AI_PROFILE", "minimal")
_profile = AI_PROFILES.get(_profile_name, AI_PROFILES["minimal"])

# LOCAL_AI_MODEL reste modifiable directement si tu veux un modèle précis en
# dehors des 3 profils ci-dessus (ex. "qwen2.5:3b") — sinon, il suit le profil.
LOCAL_AI_MODEL = os.environ.get("LOCAL_AI_MODEL", _profile["model"])

# Délai maximum d'attente d'une réponse du modèle local, en secondes. Un
# modèle plus gros (profil "élevé") peut légitimement prendre plus de temps
# même avec un bon GPU ; le minimum ci-dessous s'adapte au profil, mais reste
# modifiable directement via LOCAL_AI_TIMEOUT si besoin.
_default_timeout = {"minimal": 25, "confort": 30, "eleve": 45}.get(_profile_name, 25)
LOCAL_AI_TIMEOUT = int(os.environ.get("LOCAL_AI_TIMEOUT", str(_default_timeout)))

# Nombre max de tokens générés par réponse. Volontairement modeste : Veritas
# formule un résumé de sources, pas un essai — et ça reste rapide sur CPU.
LOCAL_AI_MAX_TOKENS = int(os.environ.get("LOCAL_AI_MAX_TOKENS", "300"))

# ---------------------------------------------------------------------------
# Base de connaissances Bénin (point 19) — modèle d'embeddings
# ---------------------------------------------------------------------------
# Séparé du modèle de génération : nomic-embed-text est petit (~274 Mo) et
# fait UNE seule chose (transformer un texte en vecteur), pas de génération.
# Installation : `ollama pull nomic-embed-text` (voir AI_LOCAL.md).
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "nomic-embed-text")
EMBEDDING_TIMEOUT = int(os.environ.get("EMBEDDING_TIMEOUT", "10"))

# Dossier contenant les documents sources (.md/.txt) et chemin de l'index
# généré par `python -m rag.ingest`.
KNOWLEDGE_DIR = os.environ.get("KNOWLEDGE_DIR", "knowledge/benin")
KNOWLEDGE_INDEX_PATH = os.environ.get("KNOWLEDGE_INDEX_PATH", "knowledge/index.json")

# ---------------------------------------------------------------------------
# Fournisseur Gemini (optionnel, cloud) — JAMAIS obligatoire
# ---------------------------------------------------------------------------
# Second fournisseur possible en plus du local, pour qui veut une formulation
# plus rapide/poussée sans matériel dédié. Le local (Ollama) reste le
# fournisseur PAR DÉFAUT et recommandé — Veritas BJ doit toujours pouvoir
# fonctionner sans clé API externe (voir point 6 du cahier des charges).
#
# Pour l'activer : AI_PROVIDER=gemini + GEMINI_API_KEY (variable
# d'environnement UNIQUEMENT — jamais en dur dans un fichier, jamais collée
# dans un chat ou un ticket). Voir AI_LOCAL.md pour la procédure complète.
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-flash-latest")
GEMINI_TIMEOUT = int(os.environ.get("GEMINI_TIMEOUT", "20"))

# ---------------------------------------------------------------------------
# Email (mot de passe oublié) — fournisseur SMTP générique, optionnel
# ---------------------------------------------------------------------------
# N'importe quel fournisseur SMTP fonctionne (Gmail, Outlook, un service pro
# comme SendGrid/Brevo en mode SMTP...) — c'est volontairement générique pour
# ne pas t'imposer un choix. Tant que SMTP_HOST n'est pas configuré, "mot de
# passe oublié" reste fonctionnel côté logique (jetons créés, expiration
# gérée) mais aucun email n'est réellement envoyé — jamais de faux-semblant.
SMTP_HOST = os.environ.get("SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
SMTP_FROM = os.environ.get("SMTP_FROM", SMTP_USER)
SMTP_USE_TLS = os.environ.get("SMTP_USE_TLS", "1") == "1"

# URL du frontend, pour construire le lien cliquable dans l'email de
# réinitialisation (ex. https://mon-frontend.com/reset?token=...).
FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:8080")
PASSWORD_RESET_TOKEN_LIFETIME_MINUTES = int(os.environ.get("PASSWORD_RESET_TOKEN_LIFETIME_MINUTES", "60"))

# ---------------------------------------------------------------------------
# TTS Fon (accessibilité — voir FON_TTS.md pour l'état réel du chantier)
# ---------------------------------------------------------------------------
# Désactivé par défaut : nécessite `transformers` + `torch` + `scipy` (voir
# requirements.txt), non installés par défaut pour ne pas alourdir
# l'installation de base de Veritas BJ. Le modèle (~150 Mo, facebook/mms-tts-fon,
# licence CC-BY-NC 4.0 — usage non commercial) est téléchargé au premier
# appel puis mis en cache localement.
#
# HONNÊTETÉ : ce module sait uniquement transformer du texte DÉJÀ EN FON en
# audio. Il ne traduit PAS le français. Seules les clés de
# knowledge/benin/fon_phrases.json marquées "validated": true (par un(e)
# locuteur(trice) Fon natif(ve)) sont synthétisables via /api/tts.
TTS_ENABLED = os.environ.get("TTS_ENABLED", "0") == "1"
FON_PHRASES_PATH = os.environ.get("FON_PHRASES_PATH", "knowledge/benin/fon_phrases.json")
# Dossier des VRAIS enregistrements humains (voir tools/fon_recorder.html) —
# priorité 1, aucune dépendance lourde requise, fonctionne dès qu'un fichier
# y est déposé et que "validated": true est mis dans fon_phrases.json.
FON_AUDIO_DIR = os.environ.get("FON_AUDIO_DIR", "knowledge/benin/audio_fon")

# Traduction automatique FR->Fon (NLLB-200) + synthèse — désactivée par
# défaut. NON VÉRIFIÉE par un humain, voir FON_TTS.md et
# ai/translate_fon_provider.py. Séparée de TTS_ENABLED pour que l'activer
# soit un choix conscient et distinct (le TTS seul, sur des phrases
# validées, est bien plus fiable).
AUTO_TRANSLATE_FON_ENABLED = os.environ.get("AUTO_TRANSLATE_FON_ENABLED", "0") == "1"

# Reconnaissance vocale Fon (STT) — voir ai/asr_fon_provider.py et FON_TTS.md.
# Désactivée par défaut. Nécessite speechbrain + torchaudio + pydub, et
# ffmpeg installé sur le système (pour convertir l'audio du navigateur).
STT_ENABLED = os.environ.get("STT_ENABLED", "0") == "1"

# OCR pour les PDF scannés (voir tools/document.py) — désactivé par défaut :
# nécessite PyMuPDF + pytesseract + Pillow (pip) ET le binaire Tesseract OCR
# installé sur le système (avec le paquet de langue française). Qualité non
# testée dans l'environnement de développement (pas de Tesseract disponible
# ici pour vérifier).
OCR_ENABLED = os.environ.get("OCR_ENABLED", "0") == "1"
