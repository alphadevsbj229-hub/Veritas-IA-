"""
Veritas - Modèles de base de données
--------------------------------------
Utilise SQLite (fichier local, pas de serveur à installer) via SQLAlchemy.
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    username = db.Column(db.String(50), nullable=False)
    password_hash = db.Column(db.String(255), nullable=True)  # nul pour un compte Google pur
    google_id = db.Column(db.String(255), unique=True, nullable=True, index=True)
    avatar_url = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # Horodatage du dernier changement de mot de passe. Permet d'invalider
    # automatiquement les anciens tokens JWT émis AVANT ce changement (voir
    # auth.py::login_required) — sans ça, réinitialiser son mot de passe ne
    # déconnecterait pas un token déjà volé.
    password_changed_at = db.Column(db.DateTime, nullable=True)

    conversations = db.relationship(
        "Conversation", backref="user", lazy=True, cascade="all, delete-orphan"
    )

    def to_public_dict(self):
        return {
            "id": self.id,
            "email": self.email,
            "username": self.username,
            "avatar_url": self.avatar_url,
            "has_password": bool(self.password_hash),
        }


class Conversation(db.Model):
    __tablename__ = "conversations"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    title = db.Column(db.String(200), default="Nouvelle discussion")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    messages = db.relationship(
        "Message", backref="conversation", lazy=True,
        cascade="all, delete-orphan", order_by="Message.created_at"
    )

    def to_dict(self, include_messages=False):
        data = {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at.isoformat(),
        }
        if include_messages:
            data["messages"] = [m.to_dict() for m in self.messages]
        return data


class Message(db.Model):
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("conversations.id"), nullable=False, index=True)
    role = db.Column(db.String(10), nullable=False)  # "user" ou "ai"
    text = db.Column(db.Text, nullable=False)
    sources_json = db.Column(db.Text, default="[]")  # JSON stocké en texte
    related_links_json = db.Column(db.Text, default="[]")  # liens "pour aller plus loin"
    verified = db.Column(db.Boolean, default=False)
    # Statut de vérification honnête (CONFIRMED / CONTRADICTED / UNCONFIRMED /
    # INSUFFICIENT_EVIDENCE) — voir app.py::detect_numeric_contradiction.
    # `verified` reste pour rétrocompatibilité mais ce champ est plus précis.
    verification_status = db.Column(db.String(24), nullable=True)
    # Identifiant généré côté client (UUID) : si le frontend retente l'envoi
    # d'un message après un timeout (voir la file d'attente dans app.js), ce
    # champ permet de détecter que c'est le même message et de ne pas le
    # dupliquer, même si la première tentative avait en fait réussi côté
    # serveur mais que la réponse s'était perdue en route.
    client_message_id = db.Column(db.String(64), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint(
            "conversation_id", "client_message_id",
            name="uq_message_conversation_client_id",
        ),
    )

    def to_dict(self):
        import json
        return {
            "id": self.id,
            "role": self.role,
            "text": self.text,
            "sources": json.loads(self.sources_json or "[]"),
            "related_links": json.loads(self.related_links_json or "[]"),
            "verified": self.verified,
            "verification_status": self.verification_status,
        }


class RevokedToken(db.Model):
    """
    Liste noire des tokens JWT invalidés avant leur expiration naturelle
    (déconnexion explicite). Sans cette table, un token JWT reste valide
    jusqu'à ses 30 jours même après un clic sur "Se déconnecter" — voir
    point 26 du cahier des charges (révocation).
    """
    __tablename__ = "revoked_tokens"

    id = db.Column(db.Integer, primary_key=True)
    jti = db.Column(db.String(64), unique=True, nullable=False, index=True)
    expires_at = db.Column(db.DateTime, nullable=False)  # pour purger les entrées devenues inutiles


class PasswordResetToken(db.Model):
    """
    Jeton à usage unique pour réinitialiser un mot de passe oublié. On ne
    stocke jamais le jeton en clair (seulement son empreinte SHA-256) — même
    en cas de fuite de la base de données, les jetons bruts déjà envoyés par
    email restent inutilisables pour un attaquant qui ne lirait "que" la base.
    """
    __tablename__ = "password_reset_tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    token_hash = db.Column(db.String(64), unique=True, nullable=False, index=True)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
