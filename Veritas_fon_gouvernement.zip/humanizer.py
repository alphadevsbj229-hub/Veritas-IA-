"""
Veritas - Humanizer
---------------------
Rend les réponses plus naturelles et fluides, façon assistant conversationnel,
SANS jamais ajouter d'information qui ne vienne pas des sources récupérées.

Règle d'or : ce module ne fait que réarranger, introduire et relier des
phrases déjà extraites des sources. Il n'invente aucun fait, aucun chiffre,
aucune date. S'il ne peut pas relier deux extraits sans risquer de déformer
leur sens, il les juxtapose simplement plutôt que de les fusionner.

Développé par AlphaDevs BJ 🦁
"""

import random
import re

# ---------------------------------------------------------------------------
# Variété des tournures (choisies aléatoirement pour éviter un ton robotique)
# ---------------------------------------------------------------------------

INTROS_SINGLE = [
    "Alors, {text}",
    "Voici ce que j'ai trouvé : {text}",
    "D'après mes recherches, {text}",
    "{text}",
    "Pour répondre simplement : {text}",
]

INTROS_MULTI = [
    "Alors, en croisant plusieurs sources : {text}",
    "D'après ce que j'ai pu vérifier à plusieurs endroits, {text}",
    "Voici une synthèse de ce que j'ai trouvé : {text}",
    "En rassemblant les informations disponibles : {text}",
]

CONNECTORS_ADD = [
    "Pour compléter, {snippet}",
    "D'ailleurs, {snippet}",
    "À noter aussi : {snippet}",
    "Autre précision utile : {snippet}",
    "On peut ajouter que {snippet}",
]

CLOSERS = [
    "",
    "",
    "",
    " N'hésite pas si tu veux que je creuse un point en particulier.",
    " Dis-moi si tu veux plus de détails sur un aspect précis.",
]

NO_RESULT_MESSAGES = [
    "Je n'ai trouvé aucune information fiable sur ce sujet dans mes sources "
    "(Wikipédia, DuckDuckGo, Wikidata, actualités). Essaie de reformuler ta "
    "question, ou précise un peu plus le contexte.",
    "Mes recherches n'ont rien donné de concret cette fois-ci. Peux-tu "
    "reformuler la question ou préciser de quoi/qui il s'agit exactement ?",
    "Aucune source ne me permet de répondre à cette question avec certitude "
    "pour l'instant. Une reformulation plus précise m'aiderait à mieux "
    "chercher.",
]


def _first_sentence(text, max_chars=220):
    """Extrait une première phrase (ou un fragment) courte et propre d'un texte."""
    text = text.strip()
    match = re.search(r"^.{1,%d}?[\.!?](?=\s|$)" % max_chars, text)
    fragment = match.group(0) if match else text[:max_chars].rsplit(" ", 1)[0]
    fragment = fragment.strip()
    # Met en minuscule la première lettre si on va l'insérer après un connecteur
    return fragment


def _lowercase_first(s):
    """Met en minuscule la première lettre, uniquement pour les mots courants
    qui commencent typiquement une phrase (articles, démonstratifs...). On
    évite de toucher aux noms propres ou acronymes (ex. "Cotonou", "INSAE"),
    qu'on ne peut pas fiablement distinguer autrement que par une liste connue.
    Dans le doute, on préserve la casse d'origine plutôt que de risquer de
    déformer un nom propre — une majuscule après un connecteur reste
    grammaticalement correcte en français."""
    if not s:
        return s
    common_starters = (
        "le ", "la ", "les ", "l'", "un ", "une ", "des ", "ce ", "cet ",
        "cette ", "ces ", "il ", "elle ", "ils ", "elles ", "on ", "son ",
        "sa ", "ses ", "leur ", "leurs ", "au ", "aux ", "du ", "de ",
    )
    if s.lower().startswith(common_starters):
        return s[:1].lower() + s[1:]
    return s


def clean_snippet(text):
    return re.sub(r"\s+", " ", text or "").strip()


# ---------------------------------------------------------------------------
# Fonctions publiques utilisées par app.py
# ---------------------------------------------------------------------------

def humanize_single_source(main_text):
    """Une seule source disponible : on l'introduit simplement, sans fusion risquée."""
    template = random.choice(INTROS_SINGLE)
    text = main_text if template == "{text}" else _lowercase_first(main_text)
    answer = template.format(text=text)
    return (answer + random.choice(CLOSERS)).strip()


def humanize_multi_source(main_text, other_snippets):
    """
    Plusieurs sources concordent : on introduit le fait principal, puis on
    ajoute — sous forme de phrases courtes et distinctes — les compléments
    utiles trouvés ailleurs, sans jamais les faire passer pour un unique
    texte réécrit (on ne reformule jamais au point de perdre le sens exact).
    """
    intro_template = random.choice(INTROS_MULTI)
    answer = intro_template.format(text=_lowercase_first(main_text))

    # On ajoute au maximum 2 compléments, courts, et clairement distincts
    # du texte principal pour éviter la redondance et les répétitions.
    added = 0
    seen_starts = {main_text[:40].lower()}
    for snippet in other_snippets:
        if added >= 2:
            break
        fragment = _first_sentence(clean_snippet(snippet), max_chars=180)
        if not fragment or len(fragment) < 15:
            continue
        key = fragment[:40].lower()
        if key in seen_starts:
            continue
        seen_starts.add(key)
        connector = random.choice(CONNECTORS_ADD)
        answer += "\n\n" + connector.format(snippet=_lowercase_first(fragment))
        added += 1

    return (answer + random.choice(CLOSERS)).strip()


def no_result_message():
    return random.choice(NO_RESULT_MESSAGES)
