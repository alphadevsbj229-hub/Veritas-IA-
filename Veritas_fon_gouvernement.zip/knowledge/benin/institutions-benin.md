# Institutions politiques du Bénin
Source: https://presidence.bj/les-institutions/
Consulté le: 2026-09-11

Le Bénin est une République multipartite à régime présidentiel : le président de la République est à la fois chef de l'État et chef du gouvernement.

Le Parlement béninois est de type monocaméral (une seule chambre), appelé Assemblée nationale. Cette configuration existe depuis les indépendances en 1960 et a été confirmée par la Constitution du 11 décembre 1990, qui prévoit que l'Assemblée nationale exerce le pouvoir législatif et contrôle l'action du Gouvernement.

La Constitution du 11 décembre 1990 a instauré le multipartisme au Bénin. Elle fait suite à la Conférence nationale souveraine tenue à Cotonou en février 1990, qui a mis fin au régime marxiste-léniniste alors en place. La Constitution a été approuvée par référendum le 2 décembre 1990.

Plusieurs institutions constitutionnelles complètent l'architecture de l'État béninois, notamment : la Cour suprême (plus haute juridiction de l'État en matière administrative, judiciaire et des comptes publics) ; la Haute Autorité de l'Audiovisuel et de la Communication (HAAC), composée de neuf membres, chargée notamment de la régulation des médias ; la Haute Cour de Justice ; et la Cour des comptes, qui contrôle les comptes des comptables publics ainsi que la gestion des entreprises publiques et des organismes de sécurité sociale.

Note importante : le nombre de sièges à l'Assemblée nationale et la durée des mandats (présidentiel et parlementaire) ont changé plusieurs fois au fil des réformes constitutionnelles et électorales (notamment en 2019 et en novembre 2025). Pour connaître les chiffres exacts en vigueur aujourd'hui, mieux vaut consulter directement presidence.bj ou assemblee-nationale.bj plutôt que de se fier à un chiffre figé dans ce document, qui peut devenir obsolète.
