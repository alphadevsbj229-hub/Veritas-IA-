# Système éducatif du Bénin
Source: https://brokenchalk.org/author/f-galgalo/
Consulté le: 2026-09-11

Le système éducatif béninois suit un modèle proche du système éducatif français : six années de primaire, quatre années de collège, trois années de lycée, puis l'enseignement supérieur. On appelle parfois ce schéma le système "6-4-3-3" (source : UNESCO, 2023).

Au Bénin, l'école n'est pas obligatoire : les familles peuvent choisir de scolariser leurs enfants ou de les garder à la maison, notamment pour les aider dans les tâches domestiques ou pour qu'ils entrent directement dans le monde du travail.

Les élèves béninois passent plusieurs examens nationaux au cours de leur scolarité : le Certificat d'Études Primaires (CEP) en fin de primaire, le Brevet d'Étude du Premier Cycle (BEPC) en fin de collège (classe de 3ème), puis le Baccalauréat (BAC) en fin de lycée (classe de Terminale), sur le modèle français.

Depuis la réforme introduite à partir de la session 2024, la distinction entre séries générales et séries techniques a été supprimée pour une partie du parcours : les élèves étudient et sont évalués sur un tronc commun de matières plutôt que de choisir entre deux voies de formation dès le lycée (source : lepetitjournal.com/cotonou/education).

Après le baccalauréat, les études supérieures se déroulent dans des universités publiques ou des instituts spécialisés, selon un système Licence (3 ans) / Master / Doctorat.

Le calendrier officiel des examens nationaux (CEP, BEPC, BAC et autres) est fixé chaque année par arrêté interministériel et publié sur le portail du gouvernement (gouv.bj).

Note : les taux de réussite au baccalauréat varient chaque année (environ 63% au niveau national en 2023 selon la presse) — pour un chiffre à jour, une recherche web reste plus fiable qu'un document statique comme celui-ci.
