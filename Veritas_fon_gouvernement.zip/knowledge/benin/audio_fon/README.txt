Dépose ici les fichiers audio enregistrés via tools/fon_recorder.html
(identity.webm, greeting.webm, no_result.webm...).

N'oublie pas ensuite de passer "validated": true pour chaque clé dans
knowledge/benin/fon_phrases.json.
