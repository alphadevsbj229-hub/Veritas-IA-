# SECURITY.md — Sécurité de Veritas BJ

## Ce qui est en place

### Authentification
- Mots de passe hashés avec **bcrypt** — jamais stockés en clair
- Mot de passe : 8 caractères minimum, au moins une lettre et un chiffre
- Connexion Google : jeton vérifié **cryptographiquement** (signature + audience) via la bibliothèque officielle `google-auth`, jamais de confiance aveugle dans ce que le frontend prétend recevoir
- Sessions par JWT signé (30 jours), avec un identifiant unique (`jti`) par token

### Révocation de session (déconnexion réelle)
- `/api/auth/logout` invalide le token **immédiatement**, avant son expiration naturelle (table `RevokedToken`)
- Testé : déconnecter une session ne déconnecte pas les autres sessions du même compte (pas d'effet de bord global)

### Limitation de débit (anti brute-force / anti-abus)
- `/api/auth/login` : 10 tentatives/minute
- `/api/auth/register` : 5/heure
- `/api/ask` : 20/minute (protège aussi contre un bannissement de l'IP du serveur par DuckDuckGo en cas d'abus)

### CORS
- Liste blanche d'origines explicite (`ALLOWED_ORIGINS`), jamais `*` (toutes origines)

### Protection SSRF
- Toute URL que le serveur va chercher lui-même (résultats de recherche web) est vérifiée **avant** la requête : protocole http(s) uniquement, résolution DNS puis vérification que l'IP n'est ni privée, ni loopback, ni lien-local (bloque notamment l'accès aux métadonnées cloud type `169.254.169.254`)
- Testé contre 9 cas malveillants (IP privées, loopback IPv6, mauvais protocoles, métadonnées cloud) — tous bloqués **avant** toute tentative réseau

### Calculatrice sécurisée
- Aucune expression utilisateur n'est jamais évaluée avec `eval()` — analyse via `ast` avec liste blanche stricte d'opérateurs mathématiques
- Testé contre 5 tentatives d'exécution de code arbitraire (`__import__`, `exec`, évasion de sandbox Python) — toutes bloquées

### Isolation entre utilisateurs
- Chaque conversation est liée à un `user_id` ; un utilisateur ne peut ni lire, ni modifier, ni supprimer les conversations d'un autre (testé explicitement)

### Secrets
- Aucune clé API, mot de passe, ou secret n'est écrit en dur dans le code — tout passe par des variables d'environnement (`SECRET_KEY`, `GOOGLE_CLIENT_ID`, `GEMINI_API_KEY`...)
- `SECRET_KEY` généré automatiquement et stocké localement (`.secret_key`) si non fourni par variable d'environnement — **ce fichier ne doit jamais être commité dans Git** (voir `.gitignore`)

### Logs
- Format structuré (JSON), avec un `request_id` commun à toute une requête
- **Filtrage actif** (pas juste une convention) : mot de passe, token, clé API ne peuvent jamais apparaître dans un log, même par erreur d'un développeur futur — testé explicitement
- Le contenu des questions n'est jamais loggé (seulement sa longueur), pour limiter la donnée personnelle conservée

### Erreurs
- `debug=False` par défaut — aucune trace technique (chemins serveur, requêtes SQL) exposée à un visiteur en cas d'erreur
- Un gestionnaire d'erreur global logue l'erreur côté serveur et renvoie un message générique au client

## Limites connues (transparence, point 45)

- **Pas de vérification d'email** : une adresse au bon format est acceptée sans confirmation qu'elle appartient réellement à l'utilisateur (pas de lien de confirmation envoyé par email)
- **"Mot de passe oublié" fonctionnel mais nécessite une configuration** : le flux complet existe (jeton à usage unique haché en base, expiration 1h, anti-énumération d'utilisateurs, invalidation des anciennes sessions), mais aucun email n'est réellement envoyé tant qu'un fournisseur SMTP n'est pas configuré (`SMTP_HOST` et variables associées) — voir `EMAIL.md`
- **Fenêtre théorique de moins d'1 seconde** sur l'invalidation de session après un reset de mot de passe (limite de précision des JWT standards, documentée dans `auth.py::auth_reset_password`) — non exploitable en pratique
- **Rate limiting en mémoire** (`storage_uri="memory://"` de Flask-Limiter) : si le serveur tourne sur plusieurs processus/machines, chaque instance a ses propres compteurs — suffisant pour une seule instance (le cas de démarrage), à revoir si le trafic justifie plusieurs serveurs en parallèle
- **Pas de limitation de tentatives par compte** au-delà du rate limiting par IP — un attaquant distribué sur plusieurs IP n'est pas ralenti par compte ciblé
- **Le contenu des sources web n'est pas assaini avant affichage** au-delà de l'extraction de texte basique — si une page malveillante injectait du HTML dans son contenu visible, il faudrait vérifier que le frontend l'affiche bien comme texte brut et non comme HTML interprété (à vérifier dans `app.js` si le rendu des réponses change un jour pour supporter du HTML)

## Que faire en cas de fuite de secret (clé API, token...)

1. Révoque immédiatement la clé/le token chez le fournisseur (Google AI Studio, Google Cloud Console...)
2. Génères-en un nouveau
3. Ne le colle jamais dans un chat, un ticket, ou un fichier versionné — uniquement dans une variable d'environnement
