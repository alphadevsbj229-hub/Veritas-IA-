"""
Veritas BJ - Synthèse vocale en Fon (fɔ̀ngbè)
------------------------------------------------
Utilise le modèle Meta MMS-TTS pour le Fon (facebook/mms-tts-fon), via la
bibliothèque Hugging Face `transformers`. Le modèle est un VITS : il prend en
entrée du texte EN FON (pas du français) et produit directement une forme
d'onde audio.

IMPORTANT — ce que ce module fait et ne fait PAS (honnêteté) :
- Il sait transformer du texte Fon en audio Fon. C'est tout.
- Il NE traduit PAS le français vers le Fon. Le texte qu'on lui donne doit
  déjà être en Fon (voir knowledge/benin/fon_phrases.json pour la petite
  banque de phrases fixes utilisées au démarrage).
- Tant que la banque de phrases n'est pas complétée par un(e) vrai(e)
  locuteur(trice) Fon, seules les clés marquées comme validées doivent être
  exposées côté API/app.py.

Licence du modèle : CC-BY-NC 4.0 (Meta, projet MMS) — usage non commercial.
Si Veritas BJ devient un produit commercial, il faudra revoir ce point AVANT
de déployer cette fonctionnalité en production.

Dépendances (voir requirements.txt) : transformers>=4.33, torch (CPU), scipy.
Le modèle (~150 Mo) est téléchargé une seule fois depuis Hugging Face au
premier appel, puis mis en cache localement (~/.cache/huggingface) — accès
réseau nécessaire uniquement la première fois.

Développé par AlphaDevs BJ 🦁
"""

import io
import logging

logger = logging.getLogger("veritas.tts_fon")

MODEL_ID = "facebook/mms-tts-fon"

# Limite volontairement basse : le VITS génère l'audio d'un seul bloc, un
# texte trop long consomme beaucoup de RAM/CPU et prend du temps sur une
# machine sans GPU (voir AI_PROFILES dans config.py — même philosophie).
MAX_CHARS = 300

_model = None
_tokenizer = None
_load_error = None


class FonTTSUnavailable(Exception):
    """Levée si le modèle n'a pas pu être chargé (dépendances manquantes,
    pas d'accès réseau au premier lancement, etc.) — jamais de silence."""


def _ensure_loaded():
    """Charge le modèle une seule fois (singleton), en mémoire process.
    Ne lève jamais d'exception silencieuse : soit ça charge, soit
    FonTTSUnavailable est levée avec un message clair pour l'appelant."""
    global _model, _tokenizer, _load_error

    if _model is not None and _tokenizer is not None:
        return

    if _load_error is not None:
        # On ne retente pas à chaque requête si ça a déjà échoué une fois
        # dans ce process (évite de spammer des tentatives de téléchargement
        # ratées à chaque question) — un redémarrage du serveur retentera.
        raise FonTTSUnavailable(_load_error)

    try:
        import torch  # noqa: F401 (vérifie juste que le paquet est installé)
        from transformers import VitsModel, AutoTokenizer
    except ImportError as exc:
        _load_error = (
            "Dépendances manquantes pour le TTS Fon. Installe-les avec : "
            "pip install transformers torch scipy "
            "(voir requirements.txt et FON_TTS.md). "
            f"Détail : {exc}"
        )
        raise FonTTSUnavailable(_load_error) from exc

    try:
        logger.info("Chargement du modèle TTS Fon (%s)...", MODEL_ID)
        _model = VitsModel.from_pretrained(MODEL_ID)
        _tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
        _model.eval()
        logger.info("Modèle TTS Fon chargé.")
    except Exception as exc:  # téléchargement impossible, modèle corrompu...
        _load_error = (
            f"Impossible de charger le modèle {MODEL_ID} depuis Hugging Face. "
            "Vérifie l'accès réseau lors du tout premier lancement (le "
            "modèle est ensuite mis en cache localement). "
            f"Détail : {exc}"
        )
        _model = None
        _tokenizer = None
        raise FonTTSUnavailable(_load_error) from exc


def synthesize_fon(text: str) -> bytes:
    """
    Synthétise du texte EN FON en audio WAV (bytes), prêt à être renvoyé
    tel quel dans une réponse Flask (mimetype="audio/wav").

    Lève FonTTSUnavailable si le modèle n'est pas disponible, et ValueError
    si le texte est vide ou trop long — jamais de retour audio vide ou
    silencieux sans le signaler à l'appelant.
    """
    import torch
    import scipy.io.wavfile

    text = (text or "").strip()
    if not text:
        raise ValueError("Texte vide : rien à synthétiser.")
    if len(text) > MAX_CHARS:
        raise ValueError(
            f"Texte trop long pour la synthèse Fon ({len(text)} caractères, "
            f"max {MAX_CHARS})."
        )

    _ensure_loaded()

    inputs = _tokenizer(text, return_tensors="pt")
    with torch.no_grad():
        output = _model(**inputs).waveform

    buffer = io.BytesIO()
    scipy.io.wavfile.write(
        buffer, rate=_model.config.sampling_rate, data=output.squeeze().numpy()
    )
    return buffer.getvalue()
