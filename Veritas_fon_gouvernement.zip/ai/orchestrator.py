"""
Veritas BJ - Orchestrateur (détection d'intention)
------------------------------------------------------
Analyse la question AVANT de décider quoi faire, pour éviter par exemple de
lancer une recherche web sur "combien font 25×12" (point 8 du cahier des
charges).

Honnêteté sur la portée actuelle : la liste complète d'intentions prévue
(GENERAL, BENIN, CURRENT_EVENT, FACT_CHECK, EDUCATION, CALCULATION, DOCUMENT,
ADMINISTRATION, HISTORY, GEOGRAPHY, SCIENCE, EXPLANATION, SUMMARIZATION,
CONVERSATION — point 9) existe ici comme structure extensible, mais seules 4
routes sont RÉELLEMENT distinguées pour l'instant : CALCULATION, IDENTITY,
CONVERSATION, et SEARCH (qui regroupe encore GENERAL/BENIN/CURRENT_EVENT/
HISTORY/GEOGRAPHY/SCIENCE/EXPLANATION — la recherche multi-sources existante
gère déjà bien ces cas ensemble, les séparer n'apporterait rien de plus tant
qu'ils n'ont pas chacun un traitement différent). DOCUMENT, ADMINISTRATION,
SUMMARIZATION et FACT_CHECK dédié n'ont pas encore d'outil associé — ils
retombent sur SEARCH pour l'instant plutôt que d'être une intention qui ne
mène nulle part.

Développé par AlphaDevs BJ 🦁
"""

import re

# Liste complète prévue par le cahier des charges (point 9) — sert de
# référence/documentation et de point d'extension futur, pas encore toutes
# actives en routage (voir note ci-dessus).
ALL_INTENTS = [
    "GENERAL", "BENIN", "CURRENT_EVENT", "FACT_CHECK", "EDUCATION",
    "CALCULATION", "DOCUMENT", "ADMINISTRATION", "HISTORY", "GEOGRAPHY",
    "SCIENCE", "EXPLANATION", "SUMMARIZATION", "CONVERSATION", "IDENTITY",
]

# Intentions réellement routées différemment aujourd'hui.
ROUTED_INTENTS = ["CALCULATION", "IDENTITY", "CONVERSATION", "SEARCH"]

_IDENTITY_RE = re.compile(
    r"^(qui es[- ]tu|t'es qui|tu es qui|c'est quoi veritas|qu'est[- ]ce que veritas|"
    r"es[- ]tu (une |un )?(ia|intelligence artificielle|robot|bot|chatbot)|"
    r"comment tu t'appelles|quel est ton nom|t'appelles[- ]tu comment)\s*\??\s*$",
    re.IGNORECASE,
)

_GREETING_RE = re.compile(
    r"^(bonjour|salut|bonsoir|coucou|hello|hi|bonne (journée|soirée|nuit)|"
    r"merci( beaucoup)?|au revoir|à bientôt|ça va\??|comment ça va\??|"
    r"comment vas[- ]tu\??|comment allez[- ]vous\??)[\s!.,]*$",
    re.IGNORECASE,
)

# Un calcul contient forcément un chiffre ET un opérateur — sinon, une phrase
# comme "quelle heure est-il" ou "à bientôt" pourrait être mal classée.
_CALCULATION_HINT_RE = re.compile(r"\d.*[+\-*/×÷%^].*\d|^(combien (font|fait|fais)|calcule)\b", re.IGNORECASE)


def detect_intent(query: str) -> str:
    """
    Classification rapide, déterministe, sans dépendre du modèle IA (qui
    peut être indisponible — voir ai/local_provider.py). Retourne une valeur
    de ROUTED_INTENTS.
    """
    q = query.strip()
    if not q:
        return "CONVERSATION"

    if _IDENTITY_RE.match(q):
        return "IDENTITY"

    if _CALCULATION_HINT_RE.search(q):
        return "CALCULATION"

    # Salutation courte uniquement : un message long qui contient "bonjour"
    # au milieu d'une vraie question ne doit pas être mal aiguillé.
    if len(q.split()) <= 6 and _GREETING_RE.match(q):
        return "CONVERSATION"

    return "SEARCH"
