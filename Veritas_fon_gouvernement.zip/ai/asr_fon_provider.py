"""
Veritas BJ - Reconnaissance vocale en Fon (STT)
---------------------------------------------------
Utilise `whettenr/asr-fon-with-diacritics`, un modèle de reconnaissance
vocale Fon publié sur Hugging Face (SpeechBrain, ~100M paramètres,
encodeur conformer entraîné en BEST-RQ sur ~140h puis affiné par CTC sur
FFSTC-2 + beethogedeon/fongbe-speech). Licence Apache 2.0.

IMPORTANT — honnêteté sur ce que c'est vraiment :
- C'est le modèle "de base" publié par son auteur, PAS la version
  affinée "tone_aware_v14" utilisée par certaines démos publiques
  (celle-ci n'est pas publiée, seul son WER est communiqué : ~18.79% en
  cross-corpus, à titre indicatif de ce qui est atteignable, pas une
  garantie pour NOTRE modèle de base).
- Aucune mesure de qualité n'a été faite ICI, sur nos propres
  enregistrements. Le taux d'erreur réel dépendra fortement du micro,
  du bruit ambiant, de l'accent/dialecte du locuteur (le Fon compte une
  cinquantaine de variantes régionales).
- Sortie systématiquement présentée comme un BROUILLON à corriger par
  l'utilisateur avant envoi (voir app.py, app.js) — jamais envoyée telle
  quelle à la recherche sans validation visuelle par la personne qui a
  parlé.

Dépendances (voir requirements.txt) : speechbrain, torch, torchaudio,
pydub (+ ffmpeg installé sur le système, pour convertir l'audio envoyé
par le navigateur — souvent en .webm — vers un .wav 16kHz mono que
speechbrain peut lire).

Développé par AlphaDevs BJ 🦁
"""

import logging
import os
import tempfile

logger = logging.getLogger("veritas.asr_fon")

MODEL_ID = "whettenr/asr-fon-with-diacritics"
SAVEDIR = "pretrained_models/asr-fon-with-diacritics"

_asr_model = None
_load_error = None


class FonASRUnavailable(Exception):
    """Levée si le modèle STT ou ses dépendances (speechbrain, ffmpeg via
    pydub) ne sont pas disponibles."""


def _ensure_loaded():
    global _asr_model, _load_error

    if _asr_model is not None:
        return
    if _load_error is not None:
        raise FonASRUnavailable(_load_error)

    try:
        from speechbrain.inference.ASR import EncoderASR
    except ImportError as exc:
        _load_error = (
            "Dépendance manquante pour la reconnaissance vocale Fon. "
            "Installe : pip install speechbrain torchaudio pydub "
            f"(voir requirements.txt et FON_TTS.md). Détail : {exc}"
        )
        raise FonASRUnavailable(_load_error) from exc

    try:
        logger.info("Chargement du modèle ASR Fon (%s)...", MODEL_ID)
        _asr_model = EncoderASR.from_hparams(source=MODEL_ID, savedir=SAVEDIR)
        logger.info("Modèle ASR Fon chargé.")
    except Exception as exc:
        _load_error = (
            f"Impossible de charger le modèle {MODEL_ID} depuis Hugging Face. "
            "Vérifie l'accès réseau lors du tout premier lancement. "
            f"Détail : {exc}"
        )
        _asr_model = None
        raise FonASRUnavailable(_load_error) from exc


def _convert_to_wav16k_mono(input_path: str) -> str:
    """Convertit n'importe quel format audio (webm, ogg, mp3...) en WAV
    16kHz mono, requis par le modèle. Nécessite ffmpeg installé sur le
    système (via pydub) — c'est le point le plus susceptible de casser
    selon la config de la machine, d'où l'erreur explicite ci-dessous."""
    try:
        from pydub import AudioSegment
    except ImportError as exc:
        raise FonASRUnavailable(
            "pydub n'est pas installé (pip install pydub) — nécessaire "
            f"pour convertir l'audio reçu du navigateur. Détail : {exc}"
        ) from exc

    output_path = input_path + ".converted.wav"
    try:
        audio = AudioSegment.from_file(input_path)
        audio = audio.set_frame_rate(16000).set_channels(1)
        audio.export(output_path, format="wav")
    except Exception as exc:
        raise FonASRUnavailable(
            "Conversion audio impossible — ffmpeg est-il installé et dans "
            "le PATH ? (nécessaire pour lire le format envoyé par le "
            f"navigateur). Détail : {exc}"
        ) from exc
    return output_path


def transcribe_fon(audio_bytes: bytes, original_suffix: str = ".webm") -> str:
    """
    Transcrit un enregistrement audio (bytes, n'importe quel format
    courant) en texte Fon. Retourne une chaîne — potentiellement vide si
    aucune parole détectée. Ne fait AUCUNE validation de qualité : c'est
    à l'appelant (voir app.py) de présenter ce texte comme un brouillon.
    """
    if not audio_bytes:
        raise ValueError("Aucun audio reçu.")

    _ensure_loaded()

    with tempfile.NamedTemporaryFile(suffix=original_suffix, delete=False) as tmp:
        tmp.write(audio_bytes)
        raw_path = tmp.name

    wav_path = None
    try:
        wav_path = _convert_to_wav16k_mono(raw_path)
        transcription = _asr_model.transcribe_file(wav_path)
        return (transcription or "").strip()
    finally:
        for p in (raw_path, wav_path):
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass
