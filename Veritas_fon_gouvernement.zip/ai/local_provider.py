"""
Veritas BJ - OllamaProvider
------------------------------
Implémentation locale de AIProvider via Ollama (https://ollama.com), qui
expose une API HTTP simple sur la machine où il tourne. Aucune clé API,
aucun compte, aucune dépendance à un fournisseur externe — tout tourne sur
le PC de l'utilisateur (ou le serveur), avec juste `requests` (déjà utilisé
ailleurs dans le projet, pas de nouvelle dépendance).

Développé par AlphaDevs BJ 🦁
"""

from typing import Optional

import requests

from ai.provider import AIProvider


class OllamaProvider(AIProvider):
    def __init__(self, endpoint: str, model: str, timeout: int = 25, max_tokens: int = 300):
        self.endpoint = endpoint.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.max_tokens = max_tokens

    def is_available(self) -> bool:
        """
        Interroge Ollama pour vérifier qu'il tourne ET que le modèle demandé
        est bien téléchargé — un timeout court (2s) car c'est un simple
        contrôle de disponibilité, pas une génération.
        """
        try:
            r = requests.get(f"{self.endpoint}/api/tags", timeout=2)
            r.raise_for_status()
            installed_models = [m.get("name", "") for m in r.json().get("models", [])]
            # Ollama peut lister "llama3.2:3b" ou juste "llama3.2" selon le tag
            return any(self.model in name or name in self.model for name in installed_models)
        except Exception:
            return False

    def generate(self, prompt: str, system: Optional[str] = None) -> Optional[str]:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"num_predict": self.max_tokens},
        }
        if system:
            payload["system"] = system

        try:
            r = requests.post(f"{self.endpoint}/api/generate", json=payload, timeout=self.timeout)
            r.raise_for_status()
            text = r.json().get("response", "").strip()
            return text or None
        except Exception:
            # Ollama non lancé, modèle non installé, timeout (CPU lent),
            # réponse malformée... dans tous les cas : on ne plante jamais,
            # l'appelant retombe sur le mode de repli (humanizer.py).
            return None


class OllamaEmbedder:
    """
    Génère des embeddings (vecteurs numériques représentant le sens d'un
    texte) via Ollama, pour la base de connaissances Bénin (voir rag/).
    Modèle recommandé : nomic-embed-text (~274 Mo, léger, tourne sur CPU).

    Ce n'est PAS un AIProvider (rôle différent : vecteurs, pas de texte
    généré) mais suit le même principe absolu : jamais d'exception, retourne
    None en cas d'échec pour que l'appelant retombe sur "pas de base de
    connaissances disponible" plutôt que de planter.
    """

    def __init__(self, endpoint: str, model: str = "nomic-embed-text", timeout: int = 10):
        self.endpoint = endpoint.rstrip("/")
        self.model = model
        self.timeout = timeout

    def is_available(self) -> bool:
        try:
            r = requests.get(f"{self.endpoint}/api/tags", timeout=2)
            r.raise_for_status()
            installed_models = [m.get("name", "") for m in r.json().get("models", [])]
            return any(self.model in name or name in self.model for name in installed_models)
        except Exception:
            return False

    def embed(self, text: str) -> Optional[list]:
        try:
            r = requests.post(
                f"{self.endpoint}/api/embeddings",
                json={"model": self.model, "prompt": text},
                timeout=self.timeout,
            )
            r.raise_for_status()
            vector = r.json().get("embedding")
            return vector if vector else None
        except Exception:
            return None
