"""
Veritas BJ - Interface AIProvider
------------------------------------
Contrat commun que doit respecter n'importe quel moteur IA branché sur
Veritas (local aujourd'hui, potentiellement d'autres plus tard). Le reste de
l'application ne parle jamais directement à Ollama ou à un autre moteur —
seulement à cette interface. Changer de moteur = changer la configuration
(voir config.py), jamais réécrire app.py.

Développé par AlphaDevs BJ 🦁
"""

from abc import ABC, abstractmethod
from typing import Optional


class AIProvider(ABC):
    """Contrat minimal : disponibilité + génération de texte."""

    @abstractmethod
    def is_available(self) -> bool:
        """
        Vérifie rapidement si le moteur répond, sans générer de texte.
        Ne doit JAMAIS lever d'exception — retourne False en cas de doute,
        pour que l'appelant puisse basculer sur le repli (humanizer.py)
        sans jamais faire planter l'application.
        """
        raise NotImplementedError

    @abstractmethod
    def generate(self, prompt: str, system: Optional[str] = None) -> Optional[str]:
        """
        Génère une réponse texte à partir d'un prompt (+ instruction système
        optionnelle). Retourne None en cas d'échec (timeout, moteur
        injoignable, erreur quelconque) — ne lève jamais d'exception, pour
        que l'appelant retombe simplement sur le mode de repli.
        """
        raise NotImplementedError
