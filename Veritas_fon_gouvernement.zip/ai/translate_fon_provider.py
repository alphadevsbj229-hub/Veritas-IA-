"""
Veritas BJ - Traduction français -> Fon (expérimental)
---------------------------------------------------------
Utilise NLLB-200 (No Language Left Behind, Meta), un modèle de recherche
open-source qui couvre 200 langues DONT le Fon (code FLORES-200 : fon_Latn),
via Hugging Face `transformers`.

IMPORTANT — honnêteté sur ce que c'est vraiment :
- NLLB-200 est explicitement documenté par Meta comme un MODÈLE DE
  RECHERCHE, "not released for production deployment". Sa qualité sur le
  Fon (langue à très peu de ressources) n'est pas garantie phrase par
  phrase — c'est un point de départ sérieux, pas une certification.
- On utilise ici le plus petit modèle (`distilled-600M`, ~2,4 Go) pour
  rester utilisable sur un PC sans GPU (cohérent avec les profils
  "minimal" de config.py). Les versions plus grosses (1.3B, 3.3B, 54B)
  traduisent mieux mais demandent un vrai GPU.
- Licence CC-BY-NC 4.0 — usage non commercial, comme mms-tts-fon.

CE MODULE NE REMPLACE PAS la banque de phrases validées par un humain
(knowledge/benin/fon_phrases.json) : toute traduction produite ici doit
être signalée comme automatique/non vérifiée à l'utilisateur (voir
app.py, /api/tts avec auto_translate=true) — jamais présentée comme une
traduction fiable au même titre qu'un enregistrement humain validé.

Développé par AlphaDevs BJ 🦁
"""

import logging

logger = logging.getLogger("veritas.translate_fon")

MODEL_ID = "facebook/nllb-200-distilled-600M"
SRC_LANG = "fra_Latn"
TGT_LANG = "fon_Latn"

# Volontairement court : un modèle de recherche non spécialisé sur des
# textes longs, et on veut rester rapide sur CPU (voir AI_PROFILES).
MAX_CHARS = 400

_model = None
_tokenizer = None
_load_error = None


class FonTranslationUnavailable(Exception):
    """Levée si le modèle de traduction n'a pas pu être chargé."""


def _ensure_loaded():
    global _model, _tokenizer, _load_error

    if _model is not None and _tokenizer is not None:
        return
    if _load_error is not None:
        raise FonTranslationUnavailable(_load_error)

    try:
        import torch  # noqa: F401
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
    except ImportError as exc:
        _load_error = (
            "Dépendances manquantes pour la traduction Fon. Installe : "
            "pip install transformers torch sentencepiece "
            f"(voir requirements.txt et FON_TTS.md). Détail : {exc}"
        )
        raise FonTranslationUnavailable(_load_error) from exc

    try:
        logger.info("Chargement du modèle de traduction NLLB (%s)...", MODEL_ID)
        _tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, src_lang=SRC_LANG)
        _model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_ID)
        _model.eval()
        logger.info("Modèle de traduction NLLB chargé.")
    except Exception as exc:
        _load_error = (
            f"Impossible de charger le modèle {MODEL_ID} depuis Hugging Face. "
            "Vérifie l'accès réseau lors du tout premier lancement. "
            f"Détail : {exc}"
        )
        _model = None
        _tokenizer = None
        raise FonTranslationUnavailable(_load_error) from exc


def translate_fr_to_fon(text: str) -> str:
    """
    Traduit du texte français en Fon via NLLB-200 (distillé, 600M).

    RAPPEL : sortie NON VÉRIFIÉE par un humain. À afficher/utiliser
    uniquement avec un avertissement explicite côté utilisateur (voir
    app.py). Ne jamais présenter comme équivalent à une traduction validée.
    """
    return _translate(text, src_lang=SRC_LANG, tgt_lang=TGT_LANG)


def translate_fon_to_fr(text: str) -> str:
    """
    Traduit du texte Fon en français via NLLB-200 (même modèle, sens
    inverse) — utilisé pour la reconnaissance vocale Fon (voir
    ai/asr_fon_provider.py) : la transcription Fon doit être traduite en
    français pour rejoindre le moteur de recherche existant de Veritas.

    RAPPEL : deux sources d'erreur s'additionnent ici (reconnaissance
    vocale + traduction), toutes deux non vérifiées par un humain. Ce
    texte doit être présenté comme un brouillon à corriger, jamais envoyé
    tel quel sans relecture par la personne qui a parlé.
    """
    return _translate(text, src_lang=TGT_LANG, tgt_lang=SRC_LANG)


def _translate(text: str, src_lang: str, tgt_lang: str) -> str:
    import torch

    text = (text or "").strip()
    if not text:
        raise ValueError("Texte vide : rien à traduire.")
    if len(text) > MAX_CHARS:
        raise ValueError(
            f"Texte trop long pour la traduction automatique ({len(text)} "
            f"caractères, max {MAX_CHARS})."
        )

    _ensure_loaded()
    _tokenizer.src_lang = src_lang

    inputs = _tokenizer(text, return_tensors="pt")
    forced_bos_token_id = _tokenizer.convert_tokens_to_ids(tgt_lang)
    with torch.no_grad():
        generated = _model.generate(
            **inputs, forced_bos_token_id=forced_bos_token_id, max_new_tokens=200
        )
    return _tokenizer.batch_decode(generated, skip_special_tokens=True)[0]
