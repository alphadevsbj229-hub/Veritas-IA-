"""
Veritas BJ - Package ai
--------------------------
Point d'entrée unique pour obtenir le moteur IA configuré. Le reste de
l'application appelle uniquement get_ai_provider() — jamais directement
OllamaProvider, GeminiProvider, ou un futur autre fournisseur.

Développé par AlphaDevs BJ 🦁
"""

import config
from ai.provider import AIProvider
from ai.local_provider import OllamaProvider
from ai.gemini_provider import GeminiProvider

_provider_instance = None


def get_ai_provider() -> AIProvider:
    """
    Fabrique le fournisseur IA selon AI_PROVIDER (config.py) :
    - "local" (défaut, recommandé) : Ollama, gratuit, tourne sur ta machine.
    - "gemini" (optionnel) : API cloud Google, nécessite GEMINI_API_KEY.
      JAMAIS requis pour que Veritas BJ fonctionne — voir AI_LOCAL.md.
    Ajouter un futur fournisseur ne demande qu'un nouveau fichier
    ai/xxx_provider.py + une branche ici, sans toucher au reste de
    l'application (point 6 du cahier des charges : abstraction AIProvider).
    """
    global _provider_instance
    if _provider_instance is None:
        if config.AI_PROVIDER == "local":
            _provider_instance = OllamaProvider(
                endpoint=config.LOCAL_AI_ENDPOINT,
                model=config.LOCAL_AI_MODEL,
                timeout=config.LOCAL_AI_TIMEOUT,
                max_tokens=config.LOCAL_AI_MAX_TOKENS,
            )
        elif config.AI_PROVIDER == "gemini":
            _provider_instance = GeminiProvider(
                api_key=config.GEMINI_API_KEY,
                model=config.GEMINI_MODEL,
                timeout=config.GEMINI_TIMEOUT,
            )
        else:
            raise ValueError(
                f"AI_PROVIDER='{config.AI_PROVIDER}' inconnu. "
                f"Valeurs acceptées : 'local' (défaut), 'gemini'."
            )
    return _provider_instance

