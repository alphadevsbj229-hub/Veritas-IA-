"""
Veritas BJ - GeminiProvider (optionnel)
-------------------------------------------
Second fournisseur possible en plus d'Ollama (local). JAMAIS requis pour que
Veritas BJ fonctionne — voir config.py et AI_LOCAL.md. Implémente exactement
la même interface AIProvider que OllamaProvider, donc app.py n'a besoin
d'aucune modification pour l'utiliser : seul le choix de config.AI_PROVIDER
change quel provider get_ai_provider() instancie.

Sécurité : la clé API n'est JAMAIS écrite en dur ici — elle est lue depuis
une variable d'environnement (GEMINI_API_KEY) que l'utilisateur configure
lui-même, jamais depuis un fichier versionné ni codée dans ce fichier.

Développé par AlphaDevs BJ 🦁
"""

from typing import Optional

import requests

from ai.provider import AIProvider

API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"


class GeminiProvider(AIProvider):
    def __init__(self, api_key: str, model: str, timeout: int = 20):
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    def is_available(self) -> bool:
        """
        Contrairement à Ollama (local, gratuit), chaque appel à Gemini a un
        coût réel et une limite de débit — on ne fait donc PAS d'appel réseau
        juste pour "vérifier la disponibilité" à chaque question. On se
        contente de vérifier qu'une clé est configurée ; une clé invalide ou
        épuisée sera de toute façon gérée proprement (retour None) par
        generate() au moment de l'appel réel.
        """
        return bool(self.api_key)

    def generate(self, prompt: str, system: Optional[str] = None) -> Optional[str]:
        if not self.api_key:
            return None

        payload = {"contents": [{"parts": [{"text": prompt}]}]}
        if system:
            payload["system_instruction"] = {"parts": [{"text": system}]}

        try:
            r = requests.post(
                f"{API_BASE}/{self.model}:generateContent",
                headers={
                    "Content-Type": "application/json",
                    "X-goog-api-key": self.api_key,
                },
                json=payload,
                timeout=self.timeout,
            )
            r.raise_for_status()
            data = r.json()
            candidates = data.get("candidates") or []
            if not candidates:
                return None
            parts = candidates[0].get("content", {}).get("parts") or []
            text = "".join(p.get("text", "") for p in parts).strip()
            return text or None
        except Exception:
            # Clé invalide, quota dépassé, timeout, réponse malformée... —
            # jamais d'exception qui remonte : l'appelant retombe sur le
            # mode de repli (humanizer.py), exactement comme pour Ollama.
            return None
