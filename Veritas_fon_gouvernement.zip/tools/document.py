"""
Veritas BJ - DocumentTool (point 24)
----------------------------------------
Analyse de documents PDF/DOCX/TXT : extraction de texte côté serveur, puis
résumé ou réponse à une question via le moteur IA. Contrairement à la
recherche web (qui a un repli par templates), cette fonctionnalité N'A PAS
de repli sans IA — un résumé fiable nécessite une vraie compréhension du
texte, ce qu'un template ne peut pas simuler honnêtement. Sans moteur IA
disponible, la route renvoie une erreur claire plutôt que de prétendre
fonctionner.

Ce qui a changé depuis la v1 (honnêteté sur ce qui est réellement nouveau) :
- DOCX supporté (via python-docx), en plus de PDF et TXT.
- OCR optionnel pour les PDF scannés (image sans couche de texte), via
  PyMuPDF + pytesseract — nécessite Tesseract OCR installé sur le système
  ET la config OCR_ENABLED=1 (voir config.py). Reste désactivé par défaut :
  qualité non testée ici (pas d'environnement graphique/Tesseract
  disponible pour vérifier), et ça ajoute deux dépendances système lourdes.
- Documents longs : découpés en plusieurs morceaux et résumés par
  "map-reduce" (chaque morceau résumé, puis les résumés partiels combinés)
  au lieu d'être simplement tronqués — voir summarize(). Pour les
  questions/réponses, si un embedder est disponible (Ollama
  nomic-embed-text, déjà utilisé par rag/), les morceaux les plus
  pertinents pour la question sont sélectionnés par similarité plutôt que
  de ne garder que le début du document — voir answer_question().
- Au-delà de MAX_CHUNKS morceaux, le document est encore tronqué (cas des
  documents vraiment énormes) — le flag "truncated" reste honnête sur ce
  point, ce n'est pas prétendu résolu à 100%.

Développé par AlphaDevs BJ 🦁
"""

import io
import math
from typing import List, Optional, Tuple

from pypdf import PdfReader

import config as app_config

# Taille d'un morceau : borne raisonnable pour un petit modèle local sur CPU
# (contexte limité) — voir config.py pour choisir un modèle avec plus de
# contexte si besoin. Inchangé par rapport à la v1 pour ne pas casser le
# comportement déjà testé manuellement sur les documents courts.
MAX_DOCUMENT_CHARS = 12000
CHUNK_SIZE = MAX_DOCUMENT_CHARS

# Nombre max de morceaux traités en résumé (map-reduce) — borne le temps de
# traitement sur un petit modèle CPU. 8 x 12000 = 96 000 caractères couverts
# avant troncature (contre 12 000 en v1) — grosse amélioration, pas une
# garantie de zéro troncature.
MAX_CHUNKS_SUMMARY = 8

# Nombre de morceaux les plus pertinents gardés pour répondre à une question
# sur un document long, quand un embedder est disponible.
TOP_K_CHUNKS_QA = 4


class DocumentError(Exception):
    """Erreur d'extraction, avec un message déjà adapté à l'affichage utilisateur."""
    pass


def extract_text_from_pdf(file_bytes: bytes) -> str:
    try:
        reader = PdfReader(io.BytesIO(file_bytes))
    except Exception as e:
        raise DocumentError(f"Impossible de lire ce PDF : {e}")

    if reader.is_encrypted:
        try:
            reader.decrypt("")  # certains PDF sont "protégés" sans vrai mot de passe
        except Exception:
            raise DocumentError("Ce PDF est protégé par un mot de passe, impossible de l'analyser.")

    pages_text = []
    for page in reader.pages:
        try:
            pages_text.append(page.extract_text() or "")
        except Exception:
            continue  # une page corrompue ne doit pas empêcher de lire les autres

    text = "\n".join(pages_text).strip()
    if not text:
        raise DocumentError(
            "Aucun texte exploitable trouvé dans ce PDF — c'est peut-être un PDF scanné "
            "(image), que Veritas ne sait pas encore lire (pas d'OCR)."
        )
    return text


def extract_text_from_docx(file_bytes: bytes) -> str:
    try:
        import docx  # python-docx
    except ImportError as exc:
        raise DocumentError(
            "Le support DOCX nécessite le paquet python-docx "
            f"(pip install python-docx). Détail : {exc}"
        )

    try:
        document = docx.Document(io.BytesIO(file_bytes))
    except Exception as e:
        raise DocumentError(f"Impossible de lire ce fichier DOCX : {e}")

    parts = [p.text for p in document.paragraphs if p.text.strip()]
    # Les tableaux contiennent souvent des infos importantes (montants,
    # dates...) qu'on perdrait en ne lisant que les paragraphes.
    for table in document.tables:
        for row in table.rows:
            cells_text = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells_text:
                parts.append(" | ".join(cells_text))

    text = "\n".join(parts).strip()
    if not text:
        raise DocumentError("Aucun texte exploitable trouvé dans ce fichier DOCX.")
    return text


def _extract_text_from_pdf_via_ocr(file_bytes: bytes) -> str:
    """
    Repli OCR pour un PDF scanné (image sans couche de texte). Nécessite
    PyMuPDF (rendu des pages en image, pas besoin de Poppler séparément)
    et pytesseract + le binaire Tesseract OCR installé sur le système
    (avec le paquet de langue française 'fra').

    Désactivé par défaut (voir config.OCR_ENABLED) : qualité non testée
    dans cet environnement de développement (pas de Tesseract disponible
    ici pour vérifier), et l'OCR est intrinsèquement moins fiable qu'une
    vraie couche de texte — les erreurs de reconnaissance de caractères
    peuvent déformer des chiffres, des noms propres, etc.
    """
    try:
        import fitz  # PyMuPDF
        import pytesseract
        from PIL import Image
    except ImportError as exc:
        raise DocumentError(
            "L'OCR nécessite PyMuPDF, pytesseract et Pillow "
            "(pip install pymupdf pytesseract pillow), ET le binaire "
            "Tesseract OCR installé sur le système avec le paquet de langue "
            f"française. Détail : {exc}"
        )

    try:
        pdf = fitz.open(stream=file_bytes, filetype="pdf")
    except Exception as e:
        raise DocumentError(f"Impossible d'ouvrir ce PDF pour l'OCR : {e}")

    pages_text = []
    # Zoom x2 : meilleure résolution pour l'OCR qu'un rendu à l'échelle 1:1,
    # sans exploser le temps de traitement sur un CPU modeste.
    matrix = fitz.Matrix(2, 2)
    for page in pdf:
        try:
            pix = page.get_pixmap(matrix=matrix)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            pages_text.append(pytesseract.image_to_string(img, lang="fra"))
        except Exception:
            continue  # une page illisible ne doit pas empêcher les autres

    text = "\n".join(pages_text).strip()
    if not text:
        raise DocumentError(
            "L'OCR n'a trouvé aucun texte exploitable sur ce PDF scanné "
            "(qualité d'image trop faible, ou document vierge)."
        )
    return text


def extract_text_from_txt(file_bytes: bytes) -> str:
    for encoding in ("utf-8", "latin-1"):
        try:
            return file_bytes.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise DocumentError("Impossible de décoder ce fichier texte (encodage non reconnu).")


def extract_text(filename: str, file_bytes: bytes) -> Tuple[str, bool]:
    """
    Retourne (texte, a_ete_tronque). Le texte n'est PLUS coupé à
    MAX_DOCUMENT_CHARS ici (voir v1) : la troncature éventuelle se décide
    maintenant au niveau du résumé/Q&A, une fois découpé en morceaux
    (voir split_into_chunks, summarize, answer_question) — ça permet de
    couvrir jusqu'à MAX_CHUNKS_SUMMARY x CHUNK_SIZE caractères au lieu d'un
    seul morceau.
    """
    lower = filename.lower()
    if lower.endswith(".pdf"):
        try:
            text = extract_text_from_pdf(file_bytes)
        except DocumentError:
            if app_config.OCR_ENABLED:
                text = _extract_text_from_pdf_via_ocr(file_bytes)
            else:
                raise
    elif lower.endswith(".docx"):
        text = extract_text_from_docx(file_bytes)
    elif lower.endswith(".txt"):
        text = extract_text_from_txt(file_bytes)
    else:
        raise DocumentError(
            "Format non supporté. Seuls les fichiers .pdf, .docx et .txt sont acceptés."
        )

    absolute_max = CHUNK_SIZE * MAX_CHUNKS_SUMMARY
    truncated = len(text) > absolute_max
    if truncated:
        text = text[:absolute_max]
    return text, truncated


def split_into_chunks(text: str, chunk_size: int = CHUNK_SIZE) -> List[str]:
    """
    Découpe le texte en morceaux d'environ chunk_size caractères, en
    coupant de préférence sur un saut de paragraphe proche de la limite
    plutôt qu'en plein milieu d'une phrase (plus lisible pour le modèle IA
    quand il traite un morceau isolé).
    """
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            # Cherche le dernier saut de paragraphe dans la seconde moitié
            # du morceau, pour éviter de couper au tout début si le texte
            # n'a pas de paragraphes bien marqués.
            cut = text.rfind("\n\n", start + chunk_size // 2, end)
            if cut != -1:
                end = cut
        chunks.append(text[start:end].strip())
        start = end
    return [c for c in chunks if c]


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


_SUMMARY_SYSTEM = (
    "Tu résumes un document, en français, de façon fidèle et concise. "
    "RÈGLES STRICTES : n'utilise QUE les informations du texte fourni, "
    "n'invente aucun fait absent du document. Résume en 5 à 8 phrases maximum."
)

_QA_SYSTEM = (
    "Tu réponds à une question à partir d'un document fourni, en français. "
    "RÈGLES STRICTES : réponds UNIQUEMENT à partir du texte fourni. Si la "
    "réponse ne s'y trouve pas, dis clairement que le document ne contient "
    "pas cette information plutôt que d'inventer une réponse."
)


def summarize(provider, text: str, truncated: bool) -> Optional[str]:
    """
    Résumé d'un document. Si le texte tient dans un seul morceau, comporte-
    ment identique à la v1 (déjà testé manuellement, pas de raison de le
    changer). Sinon, "map-reduce" : chaque morceau est résumé séparément
    (map), puis les résumés partiels sont combinés en un résumé final
    cohérent (reduce) — au lieu de ne résumer que le début du document.
    """
    if not provider.is_available():
        return None

    chunks = split_into_chunks(text)

    if len(chunks) == 1:
        prompt = f"Voici le document à résumer :\n\n{chunks[0]}\n\nRésume ce document."
        if truncated:
            prompt += "\n\n(Ce document a été tronqué car trop long ; ce résumé ne couvre que le début.)"
        return provider.generate(prompt, system=_SUMMARY_SYSTEM)

    partial_summaries = []
    for i, chunk in enumerate(chunks, start=1):
        prompt = (
            f"Voici la partie {i}/{len(chunks)} d'un document long :\n\n{chunk}\n\n"
            "Résume cette partie en 3 à 5 phrases, fidèlement, sans rien inventer."
        )
        partial = provider.generate(prompt, system=_SUMMARY_SYSTEM)
        if partial:
            partial_summaries.append(f"[Partie {i}/{len(chunks)}] {partial}")

    if not partial_summaries:
        return None

    reduce_prompt = (
        "Voici des résumés de différentes parties d'un même document long :\n\n"
        + "\n\n".join(partial_summaries)
        + "\n\nCombine-les en un seul résumé cohérent et fidèle du document "
          "entier, en 8 à 12 phrases maximum. N'invente rien au-delà de ce "
          "qui est dans ces résumés partiels."
    )
    final = provider.generate(reduce_prompt, system=_SUMMARY_SYSTEM)
    if final and truncated:
        final += (
            "\n\n(Ce document dépasse la taille maximale traitée par Veritas "
            "même en le découpant en plusieurs parties ; ce résumé ne couvre "
            "donc pas la toute fin du document.)"
        )
    return final


def answer_question(
    provider, text: str, question: str, truncated: bool, embedder=None
) -> Optional[str]:
    """
    Réponse à une question sur un document. Si le texte tient dans un seul
    morceau, comportement identique à la v1. Sinon :
    - si un embedder est fourni et disponible (voir ai/local_provider.py,
      OllamaEmbedder) : sélectionne les TOP_K_CHUNKS_QA morceaux les plus
      proches de la question par similarité cosinus, et répond seulement
      à partir de ceux-là (plus pertinent qu'un simple "début du document").
    - sinon (pas d'embedder disponible) : repli sur le comportement v1,
      seul le premier morceau est utilisé, avec un avertissement explicite
      que la réponse peut être incomplète — jamais un silence sur cette
      limite.
    """
    if not provider.is_available():
        return None

    chunks = split_into_chunks(text)

    if len(chunks) == 1:
        prompt = f"Document :\n\n{chunks[0]}\n\nQuestion : {question}"
        if truncated:
            prompt += "\n\n(Ce document a été tronqué car trop long ; la réponse peut être incomplète.)"
        return provider.generate(prompt, system=_QA_SYSTEM)

    selected_chunks = chunks[:1]  # repli par défaut si pas d'embedder
    incomplete_selection = True

    if embedder is not None and embedder.is_available():
        question_vector = embedder.embed(question)
        chunk_vectors = [embedder.embed(c) for c in chunks]
        if question_vector and all(v is not None for v in chunk_vectors):
            scored = sorted(
                zip(chunks, chunk_vectors),
                key=lambda pair: _cosine_similarity(question_vector, pair[1]),
                reverse=True,
            )
            selected_chunks = [c for c, _ in scored[:TOP_K_CHUNKS_QA]]
            incomplete_selection = False

    context = "\n\n---\n\n".join(selected_chunks)
    prompt = f"Extraits pertinents du document :\n\n{context}\n\nQuestion : {question}"
    if incomplete_selection:
        prompt += (
            "\n\n(Ce document est long et a été découpé ; faute de moteur de "
            "similarité disponible, seul le début a pu être passé en revue "
            "— la réponse peut être incomplète si l'information se trouve "
            "plus loin dans le document.)"
        )
    elif truncated:
        prompt += "\n\n(Ce document dépasse la taille maximale traitée par Veritas ; la réponse peut être incomplète.)"

    return provider.generate(prompt, system=_QA_SYSTEM)
