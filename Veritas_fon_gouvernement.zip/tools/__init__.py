"""Veritas BJ - Outils (calculator, et futurs autres outils)."""
