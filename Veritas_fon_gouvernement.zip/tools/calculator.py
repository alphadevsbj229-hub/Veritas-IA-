"""
Veritas BJ - CalculatorTool
------------------------------
Calculs mathématiques : jamais confiés au modèle de langage (qui peut se
tromper sur des calculs, voir point 23 du cahier des charges), et jamais
évalués avec eval() (risque d'exécution de code arbitraire si une entrée
malveillante passe par là). On parse l'expression avec le module `ast` et on
n'autorise QUE les opérations arithmétiques de base.

Développé par AlphaDevs BJ 🦁
"""

import ast
import operator
import re
from typing import Optional

# Whitelist stricte : uniquement ces opérateurs, rien d'autre. Toute autre
# construction (appel de fonction, nom de variable, import, etc.) est rejetée
# avant même d'atteindre l'évaluation.
_ALLOWED_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

_MAX_EXPONENT = 1000  # évite un calcul gigantesque type 9**9**9 qui bloquerait le serveur


class CalculatorError(Exception):
    pass


def _safe_eval_node(node):
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise CalculatorError("Valeur non numérique.")
    if isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in _ALLOWED_OPERATORS:
            raise CalculatorError("Opérateur non autorisé.")
        left = _safe_eval_node(node.left)
        right = _safe_eval_node(node.right)
        if op_type is ast.Pow and (abs(right) > _MAX_EXPONENT):
            raise CalculatorError("Exposant trop grand.")
        if op_type in (ast.Div, ast.FloorDiv, ast.Mod) and right == 0:
            raise CalculatorError("Division par zéro.")
        return _ALLOWED_OPERATORS[op_type](left, right)
    if isinstance(node, ast.UnaryOp):
        op_type = type(node.op)
        if op_type not in _ALLOWED_OPERATORS:
            raise CalculatorError("Opérateur non autorisé.")
        return _ALLOWED_OPERATORS[op_type](_safe_eval_node(node.operand))
    # Tout le reste (appel de fonction, nom de variable, attribut, import,
    # liste, dictionnaire...) est explicitement refusé.
    raise CalculatorError("Expression non autorisée.")


def safe_calculate(expression: str) -> float:
    """Évalue une expression arithmétique simple. Lève CalculatorError si invalide/interdite."""
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError:
        raise CalculatorError("Expression mal formée.")
    return _safe_eval_node(tree.body)


# Normalise les notations courantes en français/clavier avant le parsing
_REPLACEMENTS = {
    "×": "*", "x": "*", "X": "*",
    "÷": "/",
    ",": ".",  # virgule décimale française -> point
    "^": "**",
}

_MATH_EXPRESSION_RE = re.compile(r"^[\d\s+\-*/().%]+$")


def _extract_expression(query: str) -> Optional[str]:
    """Isole la partie calcul d'une phrase du type 'combien font 25 x 12 ?'."""
    q = query.strip().rstrip("?!.").strip()
    for phrase in ("combien font", "combien fait", "combien fais", "calcule", "calculer", "calcul de"):
        if q.lower().startswith(phrase):
            q = q[len(phrase):].strip()
            break
    for old, new in _REPLACEMENTS.items():
        q = q.replace(old, new)
    q = q.strip()
    if not q or not _MATH_EXPRESSION_RE.match(q):
        return None
    return q


def try_calculate(query: str) -> Optional[str]:
    """
    Tente de traiter la question comme un calcul. Retourne une réponse
    formatée si c'est bien un calcul valide, sinon None (l'appelant doit
    alors retomber sur la recherche normale — jamais de blocage).
    """
    expression = _extract_expression(query)
    if expression is None:
        return None
    try:
        result = safe_calculate(expression)
    except CalculatorError:
        return None
    except (ZeroDivisionError, OverflowError):
        return None

    # Format propre : entier si le résultat est un nombre entier, sinon décimal
    if isinstance(result, float) and result.is_integer():
        result = int(result)
    elif isinstance(result, float):
        result = round(result, 6)

    return f"{expression} = {result}"


# ---------------------------------------------------------------------------
# SchoolAverageTool (point 23) — moyennes avec coefficients
# ---------------------------------------------------------------------------
# Format reconnu : une suite de "note coeff X" (coefficient optionnel, 1 par
# défaut si absent). Ex. "15 coeff 3, 12 coeff 2, 9" -> moyenne pondérée.
# Volontairement strict plutôt que de deviner un format ambigu : si rien ne
# correspond clairement, on retourne None (repli sur la recherche normale)
# plutôt que de risquer un calcul silencieusement faux à partir d'une
# mauvaise interprétation du texte.
_GRADE_TOKEN_RE = re.compile(
    r"(\d+(?:[.,]\d+)?)\s*(?:/\s*20)?"
    r"(?:\s*[\(,]?\s*coef?f?(?:icient)?s?\.?\s*:?\s*(\d+(?:[.,]\d+)?)\)?)?",
    re.IGNORECASE,
)


def try_calculate_average(query: str) -> Optional[str]:
    """Calcule une moyenne pondérée si le texte contient des notes reconnaissables. Sinon, None."""
    if "moyenne" not in query.lower():
        return None

    grades = []
    for note_str, coeff_str in _GRADE_TOKEN_RE.findall(query):
        try:
            note = float(note_str.replace(",", "."))
        except ValueError:
            continue
        if note < 0 or note > 20:
            continue  # hors barème /20 -> probablement pas une vraie note, on ignore par prudence
        coeff = 1.0
        if coeff_str:
            try:
                coeff = float(coeff_str.replace(",", "."))
            except ValueError:
                coeff = 1.0
        if coeff <= 0:
            continue
        grades.append((note, coeff))

    if not grades:
        return None

    total_weighted = sum(n * c for n, c in grades)
    total_coeff = sum(c for _, c in grades)
    average = round(total_weighted / total_coeff, 2)

    details = ", ".join(f"{n:g}/20 (coeff {c:g})" for n, c in grades)
    return f"Moyenne calculée sur {details} : {average:g}/20"
