"""
Veritas BJ - Envoi d'email (SMTP générique)
------------------------------------------------
Utilise uniquement smtplib (bibliothèque standard Python) — aucune nouvelle
dépendance. Fonctionne avec n'importe quel fournisseur SMTP (Gmail,
Outlook, SendGrid en mode SMTP, etc.), configuré via config.py.

Si SMTP_HOST n'est pas configuré, send_email() retourne False sans lever
d'exception — la fonctionnalité qui en dépend (mot de passe oublié) reste
donc stable, juste sans envoi réel tant que ce n'est pas configuré.

Développé par AlphaDevs BJ 🦁
"""

import smtplib
from email.mime.text import MIMEText

import config
from logging_config import log_event


def send_email(to_email: str, subject: str, body: str) -> bool:
    if not config.SMTP_HOST:
        log_event("warning", "Email non envoyé : SMTP non configuré (SMTP_HOST manquant)")
        return False

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = config.SMTP_FROM or config.SMTP_USER
    msg["To"] = to_email

    try:
        with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=10) as server:
            if config.SMTP_USE_TLS:
                server.starttls()
            if config.SMTP_USER:
                server.login(config.SMTP_USER, config.SMTP_PASSWORD)
            server.sendmail(msg["From"], [to_email], msg.as_string())
        return True
    except Exception as e:
        # Jamais d'exception qui remonte : un email qui échoue à partir ne
        # doit pas faire planter la requête HTTP qui l'a déclenché.
        log_event("error", "Échec d'envoi d'email", error=str(e))
        return False
