"""Tests de l'outil calculatrice (point 23) : calculs valides, non-calculs, et sécurité (point 25)."""

import pytest

from tools.calculator import try_calculate, safe_calculate, CalculatorError


@pytest.mark.parametrize("query,expected_substring", [
    ("25 × 12", "300"),
    ("combien font 25 x 12 ?", "300"),
    ("combien fait 100 / 4", "25"),
    ("3 + 4 * 2", "11"),
    ("(3 + 4) * 2", "14"),
    ("10 % 3", "1"),
    ("2^10", "1024"),
])
def test_valid_calculations(query, expected_substring):
    result = try_calculate(query)
    assert result is not None
    assert expected_substring in result


@pytest.mark.parametrize("query", [
    "Qui est le président du Bénin ?",
    "Explique-moi le BAC",
    "quelle heure est-il",
    "Calcule ma moyenne",  # pas de chiffres -> pas exploitable
])
def test_non_calculation_queries_return_none(query):
    assert try_calculate(query) is None


@pytest.mark.parametrize("malicious", [
    '__import__("os").system("echo HACKED")',
    'open("/etc/passwd").read()',
    '[x for x in ().__class__.__base__.__subclasses__()]',
    'exec("print(1)")',
    'import os',
])
def test_malicious_expressions_are_blocked(malicious):
    """Sécurité (point 25) : jamais d'exécution de code, quoi qu'on essaie d'injecter."""
    with pytest.raises((CalculatorError, SyntaxError)):
        safe_calculate(malicious)


def test_division_by_zero_handled_gracefully():
    assert try_calculate("10/0") is None


def test_huge_exponent_handled_gracefully():
    assert try_calculate("9**9**9") is None


# ---------------------------------------------------------------------------
# SchoolAverageTool (point 23)
# ---------------------------------------------------------------------------

from tools.calculator import try_calculate_average


def test_average_with_explicit_coefficients():
    result = try_calculate_average("Calcule ma moyenne : 15 coeff 3, 12 coeff 2, 9 coeff 1")
    assert result is not None
    assert "13" in result  # (15*3 + 12*2 + 9*1) / 6 = 13.0


def test_average_defaults_coefficient_to_one():
    result = try_calculate_average("Quelle est ma moyenne avec 10, 12, 14 sans coefficient")
    assert result is not None
    assert "12" in result  # (10+12+14)/3 = 12.0


def test_average_returns_none_without_moyenne_keyword():
    assert try_calculate_average("Combien font 25 x 12") is None


def test_average_returns_none_without_any_grade():
    assert try_calculate_average("Calcule ma moyenne") is None


def test_average_ignores_out_of_range_grades():
    result = try_calculate_average("Calcule ma moyenne : 15 coeff 3, 999 coeff 2")
    assert result is not None
    assert "999" not in result
