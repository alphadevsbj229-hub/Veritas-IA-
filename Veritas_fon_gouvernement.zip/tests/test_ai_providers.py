"""
Tests des fournisseurs IA (point 6) : chaque provider doit respecter le
contrat AIProvider (jamais d'exception, None en cas d'échec), qu'il s'agisse
du moteur local (gratuit) ou de Gemini (cloud, optionnel).
"""

import requests

from ai.local_provider import OllamaProvider, OllamaEmbedder
from ai.gemini_provider import GeminiProvider


class FakeResponse:
    def __init__(self, json_data, status_code=200):
        self._json = json_data
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")

    def json(self):
        return self._json


def test_ollama_unavailable_returns_none_gracefully(monkeypatch):
    def fail(*args, **kwargs):
        raise requests.ConnectionError("Ollama non lancé (simulation)")

    monkeypatch.setattr(requests, "get", fail)
    monkeypatch.setattr(requests, "post", fail)

    provider = OllamaProvider(endpoint="http://127.0.0.1:11434", model="llama3.2:3b")
    assert provider.is_available() is False
    assert provider.generate("test") is None


def test_ollama_available_and_generates(monkeypatch):
    monkeypatch.setattr(requests, "get", lambda *a, **k: FakeResponse({"models": [{"name": "llama3.2:3b"}]}))
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse({"response": "Réponse simulée."}))

    provider = OllamaProvider(endpoint="http://127.0.0.1:11434", model="llama3.2:3b")
    assert provider.is_available() is True
    assert provider.generate("test") == "Réponse simulée."


def test_ollama_embedder_unavailable_returns_none(monkeypatch):
    monkeypatch.setattr(requests, "post", lambda *a, **k: (_ for _ in ()).throw(requests.ConnectionError("off")))
    embedder = OllamaEmbedder(endpoint="http://127.0.0.1:11434", model="nomic-embed-text")
    assert embedder.embed("texte") is None


def test_ollama_embedder_returns_vector(monkeypatch):
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse({"embedding": [0.1, 0.2, 0.3]}))
    embedder = OllamaEmbedder(endpoint="http://127.0.0.1:11434", model="nomic-embed-text")
    assert embedder.embed("texte") == [0.1, 0.2, 0.3]


def test_gemini_without_key_is_unavailable_and_makes_no_request(monkeypatch):
    calls = {"n": 0}
    monkeypatch.setattr(requests, "post", lambda *a, **k: calls.__setitem__("n", calls["n"] + 1))

    provider = GeminiProvider(api_key="", model="gemini-flash-latest")
    assert provider.is_available() is False
    assert provider.generate("test") is None
    assert calls["n"] == 0  # jamais d'appel réseau sans clé


def test_gemini_generates_with_valid_response(monkeypatch):
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse({
        "candidates": [{"content": {"parts": [{"text": "Réponse de Gemini."}]}}]
    }))
    provider = GeminiProvider(api_key="fake-key-for-test", model="gemini-flash-latest")
    assert provider.is_available() is True
    assert provider.generate("test") == "Réponse de Gemini."


def test_gemini_key_sent_in_header_not_in_body(monkeypatch):
    """La clé ne doit jamais fuiter dans le corps JSON (ex. logs d'accès qui loguent le body)."""
    captured = {}

    def spy_post(url, headers=None, json=None, timeout=None):
        captured["headers"] = headers
        captured["json"] = json
        return FakeResponse({"candidates": [{"content": {"parts": [{"text": "ok"}]}}]})

    monkeypatch.setattr(requests, "post", spy_post)
    provider = GeminiProvider(api_key="cle-secrete-de-test", model="gemini-flash-latest")
    provider.generate("test")

    assert captured["headers"]["X-goog-api-key"] == "cle-secrete-de-test"
    assert "cle-secrete-de-test" not in str(captured["json"])


def test_gemini_invalid_key_returns_none_gracefully(monkeypatch):
    monkeypatch.setattr(requests, "post", lambda *a, **k: FakeResponse({"error": "invalid"}, status_code=403))
    provider = GeminiProvider(api_key="cle-invalide", model="gemini-flash-latest")
    assert provider.generate("test") is None
