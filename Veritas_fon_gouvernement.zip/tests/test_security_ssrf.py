"""Tests de la protection SSRF (point 25) : jamais de requête serveur vers le réseau interne."""

import socket

import pytest

import app as veritas_app


@pytest.mark.parametrize("malicious_url", [
    "http://127.0.0.1/admin",
    "http://localhost:8080/secret",
    "http://169.254.169.254/latest/meta-data/",  # métadonnées cloud (AWS/GCP/Azure)
    "http://192.168.1.1/router-admin",
    "http://10.0.0.5/internal-api",
    "ftp://example.bj/file",
    "file:///etc/passwd",
    "javascript:alert(1)",
    "http://[::1]/admin",
])
def test_dangerous_urls_are_blocked(malicious_url):
    assert veritas_app.is_safe_external_url(malicious_url) is False


def test_legit_public_url_is_accepted(monkeypatch):
    """DNS simulé (IP publique) : l'URL doit être acceptée."""
    monkeypatch.setattr(socket, "gethostbyname", lambda hostname: "8.8.8.8")
    assert veritas_app.is_safe_external_url("https://www.gouv.bj/actualite") is True


def test_dns_failure_is_rejected_by_default(monkeypatch):
    """Échec de résolution DNS -> jamais 'sûr par défaut'."""
    def fail(hostname):
        raise socket.gaierror("simulation : domaine introuvable")
    monkeypatch.setattr(socket, "gethostbyname", fail)
    assert veritas_app.is_safe_external_url("https://domaine-inexistant.bj/") is False


def test_fetch_page_snippet_never_makes_request_to_blocked_url(monkeypatch):
    """Le blocage doit avoir lieu AVANT toute tentative réseau, pas après."""
    call_count = {"n": 0}

    def spy_get(*args, **kwargs):
        call_count["n"] += 1
        raise AssertionError("Ne devrait jamais être appelé pour une URL interne !")

    monkeypatch.setattr(veritas_app.requests, "get", spy_get)
    result = veritas_app.fetch_page_snippet("http://169.254.169.254/latest/meta-data/")
    assert result is None
    assert call_count["n"] == 0
