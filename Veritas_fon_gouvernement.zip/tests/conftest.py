"""
Veritas BJ - Fixtures partagées pour les tests (point 37)
--------------------------------------------------------------
Toutes les variables d'environnement sont fixées AVANT l'import de app.py
(qui lit sa config au moment de l'import) : base de données de test isolée
(jamais veritas.db, la vraie base de dev), clé secrète de test, et un
endpoint IA local volontairement injoignable par défaut — pour que les tests
qui ne mockent pas explicitement Ollama testent bien le mode de repli
(comportement déterministe, pas dépendant de ce qui tourne ou non sur la
machine qui exécute les tests).

Lancer les tests : `pytest` à la racine du projet (voir TESTING.md).
"""

import os
import sys
import tempfile

TEST_DB_PATH = os.path.join(tempfile.gettempdir(), "veritas_test.db")
if os.path.exists(TEST_DB_PATH):
    os.remove(TEST_DB_PATH)

os.environ["DATABASE_URL"] = f"sqlite:///{TEST_DB_PATH}"
os.environ["SECRET_KEY"] = "test-secret-key-never-use-in-production"
os.environ["FLASK_DEBUG"] = "0"
os.environ["ALLOWED_ORIGINS"] = "http://localhost:8080"
# Port injoignable exprès : par défaut, Ollama est "indisponible" dans les
# tests, sauf si un test mocke explicitement requests.get/post.
os.environ["LOCAL_AI_ENDPOINT"] = "http://127.0.0.1:1"
os.environ.setdefault("GOOGLE_CLIENT_ID", "")
os.environ.setdefault("AI_PROVIDER", "local")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest


@pytest.fixture(scope="session")
def flask_app():
    import app as veritas_app
    with veritas_app.app.app_context():
        veritas_app.db.create_all()
    yield veritas_app.app


@pytest.fixture()
def client(flask_app):
    return flask_app.test_client()


@pytest.fixture(autouse=True)
def _clean_db(flask_app):
    """Vide toutes les tables entre chaque test, pour l'isolation (point 37)."""
    yield
    import app as veritas_app
    with veritas_app.app.app_context():
        for table in reversed(veritas_app.db.metadata.sorted_tables):
            veritas_app.db.session.execute(table.delete())
        veritas_app.db.session.commit()


@pytest.fixture()
def register_user(client):
    """Inscrit un utilisateur de test et renvoie (headers_auth, user_dict)."""
    def _register(email="test@veritas.bj", password="motdepasse123", username="Testeur"):
        r = client.post("/api/auth/register", json={
            "email": email, "password": password, "username": username,
        })
        assert r.status_code == 201, r.get_json()
        data = r.get_json()
        headers = {"Authorization": f"Bearer {data['token']}"}
        return headers, data["user"]
    return _register
