"""Tests du détecteur de contradictions chiffrées (point 12, 16)."""

import app as veritas_app


def test_contradiction_detected_on_different_numbers_same_unit():
    """L'exemple exact du cahier des charges : 15 vs 17 milliards FCFA."""
    sources = [
        {"source": "Web (a.bj)", "title": "A", "url": "https://a.bj",
         "text": "Le budget alloué au projet est de 15 milliards FCFA selon le communiqué."},
        {"source": "Web (b.bj)", "title": "B", "url": "https://b.bj",
         "text": "Le budget annoncé atteint 17 milliards FCFA selon le ministère."},
    ]
    contradiction = veritas_app.detect_numeric_contradiction(sources)
    assert contradiction is not None
    assert contradiction["unit"] == "milliards"
    values = {c["value"] for c in contradiction["conflicting"]}
    assert values == {15.0, 17.0}


def test_no_contradiction_when_numbers_match():
    sources = [
        {"source": "Web (a)", "title": "A", "url": "https://a.bj",
         "text": "Le pays compte environ 14 millions habitants."},
        {"source": "Web (b)", "title": "B", "url": "https://b.bj",
         "text": "Population estimée à 14 millions habitants en 2024."},
    ]
    assert veritas_app.detect_numeric_contradiction(sources) is None


def test_no_contradiction_with_single_source():
    sources = [
        {"source": "Web (a)", "title": "A", "url": "https://a.bj", "text": "15 milliards FCFA."},
    ]
    assert veritas_app.detect_numeric_contradiction(sources) is None


def test_no_contradiction_when_no_numbers():
    sources = [
        {"source": "Web (a)", "title": "A", "url": "https://a.bj", "text": "Cotonou est la plus grande ville."},
        {"source": "Web (b)", "title": "B", "url": "https://b.bj", "text": "Porto-Novo est la capitale officielle."},
    ]
    assert veritas_app.detect_numeric_contradiction(sources) is None


def test_small_rounding_difference_is_tolerated():
    """Un écart de formatage/arrondi < 0.5% ne doit pas déclencher une fausse alerte."""
    sources = [
        {"source": "Web (a)", "title": "A", "url": "https://a.bj", "text": "100.0 millions d'habitants."},
        {"source": "Web (b)", "title": "B", "url": "https://b.bj", "text": "100.2 millions d'habitants."},
    ]
    assert veritas_app.detect_numeric_contradiction(sources) is None
