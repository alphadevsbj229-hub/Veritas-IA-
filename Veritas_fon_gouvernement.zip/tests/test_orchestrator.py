"""Tests de l'orchestrateur (point 8-9) : détection d'intention sur les exemples du cahier des charges."""

import pytest

from ai.orchestrator import detect_intent


@pytest.mark.parametrize("query,expected_intent", [
    ("Bonjour", "CONVERSATION"),
    ("Salut !", "CONVERSATION"),
    ("Merci beaucoup", "CONVERSATION"),
    ("Qui est le président du Bénin ?", "SEARCH"),
    ("Explique-moi le BAC", "SEARCH"),
    ("Comment obtenir mon NPI ?", "SEARCH"),
    ("Donne-moi les universités publiques du Bénin", "SEARCH"),
    ("Je ne comprends pas cette formule", "SEARCH"),
    ("Résume ce document", "SEARCH"),
    ("Vérifie cette information", "SEARCH"),
    ("Explique-moi ça simplement", "SEARCH"),
    ("Combien font 25 x 12 ?", "CALCULATION"),
    ("Calcule ma moyenne", "CALCULATION"),  # CALCULATION même sans chiffres : le repli vers SEARCH se fait plus tard (voir test_ask_route)
    ("Qui es-tu ?", "IDENTITY"),
    ("Tu es qui ?", "IDENTITY"),
])
def test_intent_detection(query, expected_intent):
    assert detect_intent(query) == expected_intent


def test_empty_query_defaults_to_conversation():
    assert detect_intent("") == "CONVERSATION"


def test_long_message_with_greeting_word_is_not_misrouted():
    """Un message long qui contient 'bonjour' au milieu d'une vraie question ne doit pas être mal aiguillé."""
    long_query = "Bonjour, pourrais-tu m'expliquer en détail comment fonctionne le système judiciaire béninois ?"
    assert detect_intent(long_query) == "SEARCH"
