"""
Tests de la route /api/ask (point 8, orchestrateur) : chaque intention doit
être routée correctement, avec repli garanti quand un "calcul" n'en est pas
vraiment un.

La recherche web réelle (build_answer) est mockée ici : ces tests vérifient
le ROUTAGE, pas la qualité de la recherche elle-même (couverte séparément et
manuellement, faute d'accès réseau pour tester de vraies API externes de
façon fiable et reproductible en CI).
"""


def test_ask_rejects_empty_query(client):
    r = client.post("/api/ask", json={"query": "   "})
    assert r.status_code == 400


def test_ask_rejects_too_long_query(client):
    r = client.post("/api/ask", json={"query": "a" * 501})
    assert r.status_code == 400


def test_ask_routes_identity(client):
    r = client.post("/api/ask", json={"query": "Qui es-tu ?"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["intent"] == "IDENTITY"
    assert "Veritas BJ" in data["answer"]
    assert data["verified"] is True


def test_ask_routes_calculation(client):
    r = client.post("/api/ask", json={"query": "Combien font 25 x 12 ?"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["intent"] == "CALCULATION"
    assert "300" in data["answer"]
    assert data["sources"][0]["source"] == "Calculatrice Veritas"


def test_ask_calculation_falls_back_to_search_when_not_computable(client, monkeypatch):
    """'Calcule ma moyenne' déclenche l'intention CALCULATION mais n'est pas
    un calcul exploitable (pas de chiffres) -> doit retomber sur la recherche,
    jamais bloquer ni planter."""
    import app as veritas_app

    monkeypatch.setattr(veritas_app, "build_answer", lambda q: {
        "answer": "réponse simulée", "sources": [], "related_links": [],
        "verified": False, "verification_status": "INSUFFICIENT_EVIDENCE",
    })

    r = client.post("/api/ask", json={"query": "Calcule ma moyenne"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["intent"] == "SEARCH"  # repli confirmé
    assert data["answer"] == "réponse simulée"


def test_ask_routes_conversation(client):
    r = client.post("/api/ask", json={"query": "Bonjour"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["intent"] == "CONVERSATION"
    assert data["sources"] == []


def test_ask_routes_search_and_includes_intent(client, monkeypatch):
    import app as veritas_app

    monkeypatch.setattr(veritas_app, "build_answer", lambda q: {
        "answer": f"Réponse pour : {q}", "sources": [{"source": "Wikipédia", "title": "T", "url": "https://exemple.bj"}],
        "related_links": [], "verified": False, "verification_status": "UNCONFIRMED",
    })

    r = client.post("/api/ask", json={"query": "Quelle est la capitale du Bénin ?"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["intent"] == "SEARCH"
    assert "capitale du Bénin" in data["answer"]


def test_ask_uses_conversation_history_to_resolve_context(client, monkeypatch):
    """
    Point 10 : avec un historique fourni et le moteur IA disponible (mocké
    ici), la question envoyée à build_answer doit être la version résolue,
    pas la question brute avec un pronom ambigu.
    """
    import app as veritas_app

    captured_queries = []

    def fake_build_answer(q):
        captured_queries.append(q)
        return {"answer": "ok", "sources": [], "related_links": [], "verified": False, "verification_status": "UNCONFIRMED"}

    monkeypatch.setattr(veritas_app, "build_answer", fake_build_answer)

    class FakeProvider:
        def is_available(self): return True
        def generate(self, prompt, system=None): return "Quel âge a Patrice Talon ?"

    monkeypatch.setattr(veritas_app, "get_ai_provider", lambda: FakeProvider())

    r = client.post("/api/ask", json={
        "query": "Quel âge a-t-il ?",
        "history": [
            {"role": "user", "text": "Qui est Patrice Talon ?"},
            {"role": "ai", "text": "Patrice Talon est le président du Bénin."},
        ],
    })

    assert r.status_code == 200
    data = r.get_json()
    assert captured_queries == ["Quel âge a Patrice Talon ?"]
    assert data["resolved_query"] == "Quel âge a Patrice Talon ?"
