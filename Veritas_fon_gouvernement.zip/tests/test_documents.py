"""
Tests de l'analyse de documents (point 24) : extraction PDF/TXT, résumé,
questions/réponses, sécurité (taille, format).
"""

import io

import pytest


def test_analyze_document_requires_authentication(client):
    r = client.post("/api/documents/analyze", data={}, content_type="multipart/form-data")
    assert r.status_code == 401


def test_analyze_document_requires_file(client, register_user):
    headers, _ = register_user(email="doc-nofile@veritas.bj")
    r = client.post("/api/documents/analyze", data={}, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 400


def test_analyze_document_rejects_unsupported_format(client, register_user):
    # .docx est désormais supporté (voir tools/document.py) — on teste avec
    # un format qui ne l'est vraiment pas.
    headers, _ = register_user(email="doc-format@veritas.bj")
    data = {"file": (io.BytesIO(b"contenu"), "fichier.xlsx")}
    r = client.post("/api/documents/analyze", data=data, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 400
    assert "non supporté" in r.get_json()["error"]


def test_analyze_document_qa_mode_requires_question(client, register_user):
    headers, _ = register_user(email="doc-qa@veritas.bj")
    data = {"file": (io.BytesIO("Un texte.".encode("utf-8")), "notes.txt"), "mode": "qa"}
    r = client.post("/api/documents/analyze", data=data, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 400


def test_analyze_document_rejects_oversized_file(client, register_user):
    headers, _ = register_user(email="doc-size@veritas.bj")
    big_content = b"A" * (6 * 1024 * 1024)
    data = {"file": (io.BytesIO(big_content), "gros.txt")}
    r = client.post("/api/documents/analyze", data=data, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 400


def test_analyze_document_returns_503_without_ai(client, register_user):
    """
    Sans moteur IA disponible (cas par défaut des tests, endpoint injoignable
    — voir conftest.py), l'analyse doit échouer clairement, jamais prétendre
    fonctionner (point 45).
    """
    headers, _ = register_user(email="doc-noai@veritas.bj")
    data = {"file": (io.BytesIO("Le Bénin est un pays.".encode("utf-8")), "notes.txt")}
    r = client.post("/api/documents/analyze", data=data, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 503


def test_analyze_document_summarizes_with_ai_available(client, register_user, monkeypatch):
    import app as veritas_app

    class FakeProvider:
        def is_available(self):
            return True

        def generate(self, prompt, system=None):
            return "Résumé simulé du document."

    monkeypatch.setattr(veritas_app, "get_ai_provider", lambda: FakeProvider())

    headers, _ = register_user(email="doc-summary@veritas.bj")
    data = {"file": (io.BytesIO("Le Bénin est un pays d'Afrique de l'Ouest.".encode("utf-8")), "notes.txt")}
    r = client.post("/api/documents/analyze", data=data, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 200
    body = r.get_json()
    assert body["mode"] == "summary"
    assert body["truncated"] is False
    assert "Résumé simulé" in body["answer"]


def test_analyze_document_qa_with_ai_available(client, register_user, monkeypatch):
    import app as veritas_app

    class FakeProvider:
        def is_available(self):
            return True

        def generate(self, prompt, system=None):
            assert "Quel pays" in prompt  # la question est bien incluse dans le prompt
            return "Il s'agit du Bénin."

    monkeypatch.setattr(veritas_app, "get_ai_provider", lambda: FakeProvider())

    headers, _ = register_user(email="doc-qa2@veritas.bj")
    data = {
        "file": (io.BytesIO("Le Bénin est un pays d'Afrique de l'Ouest.".encode("utf-8")), "notes.txt"),
        "mode": "qa", "question": "Quel pays est décrit ?",
    }
    r = client.post("/api/documents/analyze", data=data, headers=headers, content_type="multipart/form-data")
    assert r.status_code == 200
    assert r.get_json()["mode"] == "qa"


def test_extract_text_from_real_pdf():
    """Test d'intégration réel avec pypdf (pas de mock) : un vrai PDF généré à la volée."""
    reportlab = pytest.importorskip("reportlab")
    from reportlab.pdfgen import canvas
    from tools.document import extract_text

    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    c.drawString(100, 750, "Le Bénin est un pays d'Afrique de l'Ouest.")
    c.save()

    text, truncated = extract_text("test.pdf", buf.getvalue())
    assert "Bénin" in text
    assert truncated is False


def test_extract_text_pdf_without_text_layer_raises_clear_error():
    reportlab = pytest.importorskip("reportlab")
    from reportlab.pdfgen import canvas
    from tools.document import extract_text, DocumentError

    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    c.showPage()  # page blanche, sans texte
    c.save()

    with pytest.raises(DocumentError):
        extract_text("vide.pdf", buf.getvalue())


def test_extract_text_no_longer_truncates_at_old_single_chunk_limit():
    """
    Depuis l'ajout du résumé multi-morceaux (map-reduce), un document plus
    long que l'ancienne limite (MAX_DOCUMENT_CHARS, un seul morceau) n'est
    PLUS tronqué à l'extraction — il sera juste découpé en plusieurs
    morceaux au moment du résumé/Q&A (voir split_into_chunks).
    """
    from tools.document import extract_text, MAX_DOCUMENT_CHARS

    long_text = "Phrase répétée. " * 2000  # ~34 000 caractères
    assert len(long_text) > MAX_DOCUMENT_CHARS
    text, truncated = extract_text("long.txt", long_text.encode("utf-8"))
    assert len(text) == len(long_text)
    assert truncated is False


def test_extract_text_truncates_beyond_absolute_max():
    from tools.document import extract_text, CHUNK_SIZE, MAX_CHUNKS_SUMMARY

    absolute_max = CHUNK_SIZE * MAX_CHUNKS_SUMMARY
    long_text = "A" * (absolute_max + 5000)
    text, truncated = extract_text("enorme.txt", long_text.encode("utf-8"))
    assert len(text) == absolute_max
    assert truncated is True


def test_split_into_chunks_covers_full_text():
    from tools.document import split_into_chunks

    long_text = "Phrase répétée. " * 2000
    chunks = split_into_chunks(long_text, chunk_size=5000)
    assert len(chunks) > 1
    # split_into_chunks ne fait que .strip() chaque morceau (retire les
    # espaces de bord) : aucun caractère significatif n'est perdu au milieu.
    assert sum(len(c) for c in chunks) <= len(long_text)
    assert sum(len(c) for c in chunks) > len(long_text) - len(chunks) * 2


def test_summarize_uses_map_reduce_for_long_document():
    """
    Un document trop long pour un seul morceau doit déclencher le
    map-reduce : plusieurs appels à provider.generate (un par morceau, plus
    un pour la synthèse finale), jamais un seul appel tronqué.
    """
    from tools.document import summarize

    calls = []

    class FakeProvider:
        def is_available(self):
            return True

        def generate(self, prompt, system=None):
            calls.append(prompt)
            return "Résumé simulé."

    long_text = "Phrase répétée. " * 2000  # plusieurs morceaux à 12000 caractères
    result = summarize(FakeProvider(), long_text, truncated=False)
    assert result is not None
    assert len(calls) >= 2  # au moins un "map" + le "reduce" final


def test_answer_question_uses_embedder_to_select_relevant_chunks():
    """
    Avec un embedder disponible, la réponse doit se baser sur les morceaux
    les plus proches de la question (similarité cosinus), pas seulement le
    premier morceau du document.
    """
    from tools.document import answer_question

    MARKER = "MARQUEURUNIQUE"

    class FakeEmbedder:
        def is_available(self):
            return True

        def embed(self, text):
            # Vecteur factice : proche de [1, 0] si le texte contient le
            # marqueur, sinon proche de [0, 1] — simule une vraie
            # similarité sémantique entre la question et le bon morceau.
            return [1.0, 0.0] if MARKER in text else [0.0, 1.0]

    class FakeProvider:
        def is_available(self):
            return True

        def generate(self, prompt, system=None):
            assert MARKER in prompt  # le bon morceau a bien été sélectionné
            return "Réponse basée sur le bon morceau."

    chunk_a = "Information non pertinente. " * 1000
    chunk_b = f"{MARKER} : la réponse est ici. " * 1000
    long_text = chunk_a + "\n\n" + chunk_b

    result = answer_question(
        FakeProvider(), long_text, f"Où est {MARKER} ?", truncated=False,
        embedder=FakeEmbedder(),
    )
    assert result == "Réponse basée sur le bon morceau."
