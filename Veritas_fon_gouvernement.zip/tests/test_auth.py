"""
Tests d'authentification (point 37) : inscription, connexion, validation,
déconnexion avec révocation réelle, permissions Google.
"""

import pytest


def test_register_success(client):
    r = client.post("/api/auth/register", json={
        "email": "nouveau@veritas.bj", "password": "motdepasse123", "username": "Nouveau",
    })
    assert r.status_code == 201
    data = r.get_json()
    assert "token" in data
    assert data["user"]["email"] == "nouveau@veritas.bj"
    assert data["user"]["username"] == "Nouveau"
    # Le mot de passe ne doit JAMAIS apparaître dans la réponse
    assert "password" not in data["user"]
    assert "password_hash" not in data["user"]


def test_register_rejects_duplicate_email(client, register_user):
    register_user(email="deja@veritas.bj")
    r = client.post("/api/auth/register", json={
        "email": "deja@veritas.bj", "password": "motdepasse123", "username": "Autre",
    })
    assert r.status_code == 409


@pytest.mark.parametrize("password,should_pass", [
    ("court1", False),          # trop court
    ("motdepasselong", False),  # pas de chiffre
    ("12345678", False),        # pas de lettre
    ("motdepasse123", True),    # valide
])
def test_password_validation(client, password, should_pass):
    r = client.post("/api/auth/register", json={
        "email": f"test-{password}@veritas.bj", "password": password, "username": "Test",
    })
    if should_pass:
        assert r.status_code == 201
    else:
        assert r.status_code == 400


def test_register_rejects_invalid_email(client):
    r = client.post("/api/auth/register", json={
        "email": "pas-un-email", "password": "motdepasse123", "username": "Test",
    })
    assert r.status_code == 400


def test_login_success(client, register_user):
    register_user(email="login@veritas.bj", password="motdepasse123")
    r = client.post("/api/auth/login", json={
        "email": "login@veritas.bj", "password": "motdepasse123",
    })
    assert r.status_code == 200
    assert "token" in r.get_json()


def test_login_wrong_password(client, register_user):
    register_user(email="login2@veritas.bj", password="motdepasse123")
    r = client.post("/api/auth/login", json={
        "email": "login2@veritas.bj", "password": "mauvais-mot-de-passe",
    })
    assert r.status_code == 401


def test_login_unknown_email(client):
    r = client.post("/api/auth/login", json={
        "email": "nexistepas@veritas.bj", "password": "peu-importe123",
    })
    assert r.status_code == 401


def test_me_requires_authentication(client):
    r = client.get("/api/auth/me")
    assert r.status_code == 401


def test_me_rejects_invalid_token(client):
    r = client.get("/api/auth/me", headers={"Authorization": "Bearer token-invalide"})
    assert r.status_code == 401


def test_me_returns_current_user(client, register_user):
    headers, user = register_user(email="me@veritas.bj")
    r = client.get("/api/auth/me", headers=headers)
    assert r.status_code == 200
    assert r.get_json()["user"]["email"] == "me@veritas.bj"


def test_logout_revokes_token_immediately(client, register_user):
    """
    Le cœur du correctif de sécurité (point 26) : après /api/auth/logout,
    le MÊME token ne doit plus jamais fonctionner, même avant son expiration
    naturelle de 30 jours.
    """
    headers, _ = register_user(email="logout@veritas.bj")

    r = client.get("/api/auth/me", headers=headers)
    assert r.status_code == 200  # fonctionne avant déconnexion

    r = client.post("/api/auth/logout", headers=headers)
    assert r.status_code == 200

    r = client.get("/api/auth/me", headers=headers)
    assert r.status_code == 401  # rejeté après déconnexion


def test_logout_does_not_affect_other_sessions(client, register_user):
    """Déconnecter une session ne doit PAS déconnecter les autres appareils du même compte."""
    headers1, user = register_user(email="multi@veritas.bj", password="motdepasse123")

    r = client.post("/api/auth/login", json={"email": "multi@veritas.bj", "password": "motdepasse123"})
    headers2 = {"Authorization": f"Bearer {r.get_json()['token']}"}

    client.post("/api/auth/logout", headers=headers1)

    assert client.get("/api/auth/me", headers=headers1).status_code == 401
    assert client.get("/api/auth/me", headers=headers2).status_code == 200


def test_google_login_rejects_invalid_token(client, monkeypatch):
    """Un jeton Google invalide (signature/audience) doit être rejeté, jamais accepté par défaut."""
    import auth as auth_module

    def fake_verify(*args, **kwargs):
        raise ValueError("Jeton invalide (simulation)")

    monkeypatch.setattr(auth_module.google_id_token, "verify_oauth2_token", fake_verify)
    monkeypatch.setattr(auth_module, "GOOGLE_CLIENT_ID", "fake-client-id-for-test")

    r = client.post("/api/auth/google", json={"credential": "jeton-invalide"})
    assert r.status_code == 401


def test_google_login_creates_user_from_verified_token(client, monkeypatch):
    """Un jeton Google valide (simulé) doit créer un compte sans mot de passe."""
    import auth as auth_module

    def fake_verify(token, request, client_id):
        return {
            "sub": "google-uid-12345",
            "email": "utilisateur.google@gmail.com",
            "email_verified": True,
            "name": "Utilisateur Google",
            "picture": "https://exemple.com/photo.jpg",
        }

    monkeypatch.setattr(auth_module.google_id_token, "verify_oauth2_token", fake_verify)
    monkeypatch.setattr(auth_module, "GOOGLE_CLIENT_ID", "fake-client-id-for-test")

    r = client.post("/api/auth/google", json={"credential": "jeton-simule-valide"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["user"]["email"] == "utilisateur.google@gmail.com"
    assert data["user"]["has_password"] is False  # compte créé sans mot de passe


def _extract_reset_link(monkeypatch):
    """Intercepte send_email pour récupérer le lien de reset sans vraiment envoyer d'email."""
    import auth as auth_module
    captured = {}

    def fake_send_email(to_email, subject, body):
        captured["to"] = to_email
        captured["body"] = body
        return True

    monkeypatch.setattr(auth_module, "send_email", fake_send_email)
    return captured


def test_forgot_password_returns_same_message_regardless_of_email_existing(client, register_user, monkeypatch):
    """Anti-énumération : la réponse ne doit jamais indiquer si l'email existe ou non."""
    _extract_reset_link(monkeypatch)
    register_user(email="existe@veritas.bj")

    r1 = client.post("/api/auth/forgot-password", json={"email": "existe@veritas.bj"})
    r2 = client.post("/api/auth/forgot-password", json={"email": "nexistepas@veritas.bj"})

    assert r1.status_code == 200 and r2.status_code == 200
    assert r1.get_json() == r2.get_json()


def test_forgot_password_google_only_account_does_not_send_email(client, monkeypatch):
    """Un compte créé uniquement via Google (sans mot de passe) n'a rien à réinitialiser."""
    import auth as auth_module

    captured = _extract_reset_link(monkeypatch)

    def fake_verify(token, request, client_id):
        return {"sub": "g-1", "email": "google-only@gmail.com", "email_verified": True, "name": "G"}
    monkeypatch.setattr(auth_module.google_id_token, "verify_oauth2_token", fake_verify)
    monkeypatch.setattr(auth_module, "GOOGLE_CLIENT_ID", "fake-client-id")
    client.post("/api/auth/google", json={"credential": "jeton"})

    client.post("/api/auth/forgot-password", json={"email": "google-only@gmail.com"})
    assert "body" not in captured  # aucun email envoyé, car pas de mot de passe à réinitialiser


def test_reset_password_full_cycle(client, register_user, monkeypatch):
    """
    Cycle complet (point 26) : demande -> jeton reçu -> reset -> ancien mdp
    rejeté -> ancien token JWT invalidé -> nouveau mdp et nouveau token OK.
    """
    import re
    import time

    captured = _extract_reset_link(monkeypatch)
    old_headers, _ = register_user(email="cycle@veritas.bj", password="ancienmdp123")

    client.post("/api/auth/forgot-password", json={"email": "cycle@veritas.bj"})
    raw_token = re.search(r"reset_token=([\w\-]+)", captured["body"]).group(1)

    # Léger délai : la précision seconde des JWT peut créer une fenêtre de
    # chevauchement théorique de <1s entre l'ancien token et le changement de
    # mot de passe (voir le commentaire détaillé dans auth.py::auth_reset_password).
    time.sleep(1.1)

    r = client.post("/api/auth/reset-password", json={"token": raw_token, "password": "nouveaumdp456"})
    assert r.status_code == 200

    # Le même jeton ne doit plus jamais fonctionner (usage unique)
    r = client.post("/api/auth/reset-password", json={"token": raw_token, "password": "encoreunautre789"})
    assert r.status_code == 400

    # L'ancien mot de passe ne fonctionne plus
    r = client.post("/api/auth/login", json={"email": "cycle@veritas.bj", "password": "ancienmdp123"})
    assert r.status_code == 401

    # Le nouveau mot de passe fonctionne
    r = client.post("/api/auth/login", json={"email": "cycle@veritas.bj", "password": "nouveaumdp456"})
    assert r.status_code == 200
    new_headers = {"Authorization": f"Bearer {r.get_json()['token']}"}

    # L'ancien token JWT (émis avant le reset) est rejeté même s'il n'a pas expiré
    assert client.get("/api/auth/me", headers=old_headers).status_code == 401
    # Le nouveau token fonctionne
    assert client.get("/api/auth/me", headers=new_headers).status_code == 200


def test_reset_password_rejects_invalid_token(client):
    r = client.post("/api/auth/reset-password", json={"token": "jeton-qui-nexiste-pas", "password": "motdepasse123"})
    assert r.status_code == 400


def test_reset_password_validates_new_password_strength(client, register_user, monkeypatch):
    captured = _extract_reset_link(monkeypatch)
    register_user(email="faible@veritas.bj")
    client.post("/api/auth/forgot-password", json={"email": "faible@veritas.bj"})

    import re
    raw_token = re.search(r"reset_token=([\w\-]+)", captured["body"]).group(1)

    r = client.post("/api/auth/reset-password", json={"token": raw_token, "password": "court"})
    assert r.status_code == 400
