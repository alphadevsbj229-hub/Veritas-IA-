"""Tests de la base de connaissances Bénin (point 19) : découpage, similarité, ingestion/recherche."""

import json
import os

import pytest

from rag.ingest import chunk_text, _parse_document, build_index
from rag.retrieve import _cosine_similarity, search_knowledge_base
import rag.ingest as rag_ingest
import rag.retrieve as rag_retrieve
import config


def test_chunk_text_merges_short_paragraphs():
    text = "Paragraphe un.\n\nParagraphe deux."
    chunks = chunk_text(text, max_chars=200)
    assert len(chunks) == 1  # fusionnés car ils tiennent ensemble


def test_chunk_text_splits_long_paragraph():
    long_text = "Phrase courte. " * 50
    chunks = chunk_text(long_text, max_chars=200)
    assert len(chunks) > 1
    assert all(len(c) <= 250 for c in chunks)  # marge pour la coupe par phrase


def test_parse_document_extracts_metadata(tmp_path):
    doc_path = tmp_path / "test.md"
    doc_path.write_text(
        "# Titre du document\nSource: https://exemple.bj/page\nConsulté le: 2026-09-11\n\nCorps du texte."
    )
    doc = _parse_document(str(doc_path))
    assert doc["title"] == "Titre du document"
    assert doc["source_url"] == "https://exemple.bj/page"
    assert "Corps du texte" in doc["body"]


@pytest.mark.parametrize("a,b,expected", [
    ([1, 0, 0], [1, 0, 0], 1.0),
    ([1, 0, 0], [0, 1, 0], 0.0),
    ([1, 0], [-1, 0], -1.0),
])
def test_cosine_similarity_known_vectors(a, b, expected):
    assert _cosine_similarity(a, b) == pytest.approx(expected)


def test_search_knowledge_base_empty_index_returns_empty(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "KNOWLEDGE_INDEX_PATH", str(tmp_path / "index_inexistant.json"))
    assert search_knowledge_base("une question") == []


def test_ingest_and_retrieve_end_to_end(monkeypatch, tmp_path):
    """
    Ingestion + recherche avec un embedder simulé (mots-clés -> vecteur), pour
    valider tout le pipeline sans dépendre d'un vrai Ollama en test.
    """
    keywords = ["parlement", "president", "education", "baccalaureat"]

    def fake_embed(self, text):
        t = text.lower()
        return [1.0 if kw in t else 0.0 for kw in keywords] + [0.01]

    def fake_is_available(self):
        return True

    monkeypatch.setattr(rag_ingest.OllamaEmbedder, "embed", fake_embed)
    monkeypatch.setattr(rag_ingest.OllamaEmbedder, "is_available", fake_is_available)
    monkeypatch.setattr(rag_retrieve.OllamaEmbedder, "embed", fake_embed)

    kb_dir = tmp_path / "kb"
    kb_dir.mkdir()
    (kb_dir / "institutions.md").write_text(
        "# Institutions\nSource: https://presidence.bj/test\n\n"
        "Le parlement et le president sont des institutions clés."
    )
    (kb_dir / "education.md").write_text(
        "# Éducation\nSource: https://exemple.bj/education\n\n"
        "Le baccalaureat clôture le lycée avant l'universite."
    )

    monkeypatch.setattr(config, "KNOWLEDGE_DIR", str(kb_dir))
    monkeypatch.setattr(config, "KNOWLEDGE_INDEX_PATH", str(tmp_path / "index.json"))

    assert build_index() is True

    results = search_knowledge_base("Comment fonctionne le parlement ?", min_score=0.3)
    assert len(results) == 1
    assert "Institutions" in results[0]["source"]
    assert results[0]["url"] == "https://presidence.bj/test"


def test_search_knowledge_base_returns_empty_when_embedder_unavailable(monkeypatch, tmp_path):
    index_path = tmp_path / "index.json"
    index_path.write_text(json.dumps([{
        "id": "x", "source_file": "x.md", "title": "X", "source_url": "https://x.bj",
        "text": "contenu", "embedding": [1.0, 0.0],
    }]))
    monkeypatch.setattr(config, "KNOWLEDGE_INDEX_PATH", str(index_path))
    monkeypatch.setattr(rag_retrieve.OllamaEmbedder, "embed", lambda self, text: None)

    assert search_knowledge_base("une question") == []
