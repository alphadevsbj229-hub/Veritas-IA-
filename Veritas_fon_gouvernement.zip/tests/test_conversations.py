"""
Tests des conversations (point 37) : CRUD, isolation entre utilisateurs
(permissions), et idempotence des messages (point 28).
"""


def test_create_and_list_conversation(client, register_user):
    headers, _ = register_user(email="conv1@veritas.bj")

    r = client.post("/api/conversations", json={"title": "Ma discussion"}, headers=headers)
    assert r.status_code == 201
    conv_id = r.get_json()["conversation"]["id"]

    r = client.get("/api/conversations", headers=headers)
    assert r.status_code == 200
    ids = [c["id"] for c in r.get_json()["conversations"]]
    assert conv_id in ids


def test_user_cannot_access_another_users_conversation(client, register_user):
    """Isolation stricte entre utilisateurs (point 26 : permissions, accès aux conversations)."""
    headers_a, _ = register_user(email="user-a@veritas.bj")
    headers_b, _ = register_user(email="user-b@veritas.bj")

    r = client.post("/api/conversations", json={"title": "Conversation privée de A"}, headers=headers_a)
    conv_id = r.get_json()["conversation"]["id"]

    # B ne doit voir ni lire, ni modifier, ni supprimer la conversation de A
    assert client.get(f"/api/conversations/{conv_id}", headers=headers_b).status_code == 404
    assert client.patch(f"/api/conversations/{conv_id}", json={"title": "piraté"}, headers=headers_b).status_code == 404
    assert client.delete(f"/api/conversations/{conv_id}", headers=headers_b).status_code == 404
    assert client.post(
        f"/api/conversations/{conv_id}/messages", json={"role": "user", "text": "intrusion"}, headers=headers_b
    ).status_code == 404

    # A, elle, y a bien accès
    assert client.get(f"/api/conversations/{conv_id}", headers=headers_a).status_code == 200


def test_add_message_requires_valid_role(client, register_user):
    headers, _ = register_user(email="role@veritas.bj")
    conv_id = client.post("/api/conversations", json={}, headers=headers).get_json()["conversation"]["id"]

    r = client.post(
        f"/api/conversations/{conv_id}/messages",
        json={"role": "admin", "text": "test"}, headers=headers,
    )
    assert r.status_code == 400


def test_add_message_rejects_empty_text(client, register_user):
    headers, _ = register_user(email="empty@veritas.bj")
    conv_id = client.post("/api/conversations", json={}, headers=headers).get_json()["conversation"]["id"]

    r = client.post(
        f"/api/conversations/{conv_id}/messages",
        json={"role": "user", "text": "   "}, headers=headers,
    )
    assert r.status_code == 400


def test_message_idempotence_same_client_id_not_duplicated(client, register_user):
    """
    Cœur du correctif point 28 : renvoyer le même client_message_id (ex.
    retry frontend après timeout) ne doit jamais créer un second message.
    """
    headers, _ = register_user(email="idempotent@veritas.bj")
    conv_id = client.post("/api/conversations", json={}, headers=headers).get_json()["conversation"]["id"]

    payload = {"role": "user", "text": "Qui est Patrice Talon ?", "client_message_id": "meme-id-1234"}

    r1 = client.post(f"/api/conversations/{conv_id}/messages", json=payload, headers=headers)
    assert r1.status_code == 201
    msg_id_1 = r1.get_json()["message"]["id"]

    # Renvoi du MÊME message (simule un retry) -> ne doit pas créer de doublon
    r2 = client.post(f"/api/conversations/{conv_id}/messages", json=payload, headers=headers)
    assert r2.status_code == 200  # pas 201 : rien de nouveau créé
    msg_id_2 = r2.get_json()["message"]["id"]
    assert msg_id_1 == msg_id_2

    conv = client.get(f"/api/conversations/{conv_id}", headers=headers).get_json()["conversation"]
    assert len(conv["messages"]) == 1  # un seul message, pas deux


def test_message_without_client_id_still_works(client, register_user):
    """Rétrocompatibilité : un client qui n'envoie pas encore client_message_id doit continuer à fonctionner."""
    headers, _ = register_user(email="no-client-id@veritas.bj")
    conv_id = client.post("/api/conversations", json={}, headers=headers).get_json()["conversation"]["id"]

    r = client.post(
        f"/api/conversations/{conv_id}/messages",
        json={"role": "user", "text": "Sans client_message_id"}, headers=headers,
    )
    assert r.status_code == 201


def test_first_user_message_becomes_conversation_title(client, register_user):
    headers, _ = register_user(email="title@veritas.bj")
    conv_id = client.post("/api/conversations", json={}, headers=headers).get_json()["conversation"]["id"]

    client.post(
        f"/api/conversations/{conv_id}/messages",
        json={"role": "user", "text": "Quelle est la capitale du Bénin ?"}, headers=headers,
    )
    conv = client.get(f"/api/conversations/{conv_id}", headers=headers).get_json()["conversation"]
    assert "capitale du Bénin" in conv["title"]


def test_delete_conversation(client, register_user):
    headers, _ = register_user(email="delete@veritas.bj")
    conv_id = client.post("/api/conversations", json={}, headers=headers).get_json()["conversation"]["id"]

    r = client.delete(f"/api/conversations/{conv_id}", headers=headers)
    assert r.status_code == 200

    r = client.get(f"/api/conversations/{conv_id}", headers=headers)
    assert r.status_code == 404
