"""
Veritas - Backend
------------------
API Flask qui reçoit une question, interroge plusieurs sources
(Wikipédia, DuckDuckGo, Wikidata, Wiktionnaire, Google News), croise
les résultats, et renvoie une réponse formulée naturellement avec ses
sources.

Développé par AlphaDevs BJ 🦁 — alphadevsbj229@gmail.com

Lancement :
    pip install -r requirements.txt
    python app.py

Le serveur écoute sur http://localhost:5000
"""

import os
import re
import random
import secrets
import socket
import ipaddress
import datetime
import requests
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlparse, parse_qs, unquote
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_migrate import Migrate

from models import db
from auth import register_auth_routes, login_required
from conversations import register_conversation_routes
from humanizer import humanize_single_source, humanize_multi_source, no_result_message
from ai import get_ai_provider
import json
import config as app_config
from tools.document import extract_text, DocumentError, summarize as summarize_document, answer_question as answer_document_question
from ai.orchestrator import detect_intent
from tools.calculator import try_calculate, try_calculate_average
from rag.retrieve import search_knowledge_base
from logging_config import setup_logging, log_event

app = Flask(__name__)
logger = setup_logging()

# --- CORS : liste blanche d'origines, jamais "toutes les origines" ---
# En dev, le frontend tourne en général sur http://localhost:8080. En prod,
# définis ALLOWED_ORIGINS (séparées par des virgules) sur le vrai domaine du
# frontend déployé. Une origine mal configurée -> le navigateur bloque les
# appels API depuis le frontend, ce n'est pas silencieux.
_default_origins = "http://localhost:8080,http://127.0.0.1:8080"
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", _default_origins).split(",") if o.strip()]
CORS(app, origins=ALLOWED_ORIGINS, supports_credentials=True)

# --- Rate limiting : protège l'auth (brute force) et /api/ask (abus/bannissement DuckDuckGo) ---
# Stockage en mémoire : suffisant pour un seul processus (dev, ou prod avec un
# seul worker Gunicorn). Avec plusieurs workers/instances, chaque worker aurait
# son propre compteur -> passer à un backend Redis le jour où ça devient un
# vrai besoin (voir SECURITY.md). On ne sur-ingénierie pas avant d'en avoir besoin.
limiter = Limiter(get_remote_address, app=app, default_limits=[], storage_uri="memory://")

# --- Logs structurés (point 30) : un request_id commun à toute une requête,
# et sa durée totale. Jamais de mot de passe/token dans les logs (filtré
# activement par logging_config.py, pas juste par convention). ---
import uuid
import time as _time
from flask import g


@app.before_request
def _log_request_start():
    g.request_id = uuid.uuid4().hex[:12]
    g.start_time = _time.time()


@app.after_request
def _log_request_end(response):
    duration_ms = round((_time.time() - g.get("start_time", _time.time())) * 1000, 1)
    log_event(
        "info", f"{request.method} {request.path} -> {response.status_code}",
        request_id=g.get("request_id"), method=request.method, path=request.path,
        status_code=response.status_code, duration_ms=duration_ms,
    )
    if g.get("request_id"):
        response.headers["X-Request-ID"] = g.request_id
    return response


@app.errorhandler(Exception)
def _log_unhandled_error(e):
    log_event(
        "error", "Erreur non gérée",
        request_id=g.get("request_id"), path=request.path, error=str(e),
    )
    return jsonify({"error": "Erreur interne du serveur."}), 500


# --- Configuration ---
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
# SQLite par défaut (simple, aucune installation requise). En production avec
# plus de trafic, définis DATABASE_URL vers PostgreSQL (ex.
# "postgresql://user:pass@host/dbname", nécessite `pip install psycopg2-binary`
# en plus) — le code applicatif ne change pas, seule cette variable change
# (point 27 du cahier des charges). Utile aussi pour isoler les tests
# automatisés sur une base séparée (voir tests/conftest.py).
_default_db_uri = f"sqlite:///{os.path.join(BASE_DIR, 'veritas.db')}"
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", _default_db_uri)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Clé secrète pour signer les tokens JWT. Générée une fois et sauvegardée
# dans un fichier local pour que les sessions restent valides entre les
# redémarrages du serveur.
# Clé secrète pour signer les tokens JWT.
# En production (Render, etc.), on utilise la variable d'environnement SECRET_KEY.
# En local, on la génère une fois et on la sauvegarde dans un fichier pour que
# les sessions restent valides entre les redémarrages du serveur.
env_secret = os.environ.get("SECRET_KEY")
if env_secret:
    app.config["SECRET_KEY"] = env_secret
else:
    SECRET_FILE = os.path.join(BASE_DIR, ".secret_key")
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "r") as f:
            app.config["SECRET_KEY"] = f.read().strip()
    else:
        key = secrets.token_hex(32)
        with open(SECRET_FILE, "w") as f:
            f.write(key)
        app.config["SECRET_KEY"] = key

db.init_app(app)
migrate = Migrate(app, db)

# En développement rapide avec SQLite (démarrage recommandé pour ce projet),
# les tables sont créées automatiquement — zéro commande à connaître pour
# essayer Veritas. En production avec PostgreSQL (DATABASE_URL défini), on
# utilise Alembic/Flask-Migrate à la place (`flask db upgrade`), jamais
# create_all() — voir MIGRATIONS.md (point 27 : ne pas dépendre de
# create_all() pour faire évoluer une base de production déjà remplie).
if app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite"):
    with app.app_context():
        db.create_all()

# --- Enregistrement des routes d'authentification et de conversations ---
register_auth_routes(app, limiter)
register_conversation_routes(app)

HEADERS = {"User-Agent": "Veritas/1.0 (application de questions-réponses)"}


# ---------------------------------------------------------------------------
# SOURCES DE DONNÉES
# ---------------------------------------------------------------------------

def get_wikipedia_related_links(title, lang="fr", limit=5):
    """
    Récupère les liens "Voir aussi" (autres articles Wikipédia liés) et les
    liens externes en bas de l'article, pour proposer à l'utilisateur des
    pistes "pour aller plus loin" au-delà du simple résumé.
    """
    related = []
    try:
        # Liens internes vers d'autres articles Wikipédia pertinents
        url = f"https://{lang}.wikipedia.org/w/api.php"
        params = {
            "action": "query",
            "titles": title,
            "prop": "links",
            "pllimit": 15,
            "plnamespace": 0,  # uniquement les articles, pas les pages "Discussion" etc.
            "format": "json",
        }
        r = requests.get(url, params=params, headers=HEADERS, timeout=6)
        r.raise_for_status()
        pages = r.json().get("query", {}).get("pages", {})
        for page in pages.values():
            for link in page.get("links", [])[:limit]:
                link_title = link.get("title")
                if link_title and link_title != title:
                    related.append({
                        "label": link_title,
                        "url": f"https://{lang}.wikipedia.org/wiki/{link_title.replace(' ', '_')}",
                    })
    except Exception:
        pass

    try:
        # Liens externes cités par l'article (sites officiels, sources primaires, etc.)
        url = f"https://{lang}.wikipedia.org/w/api.php"
        params = {
            "action": "query",
            "titles": title,
            "prop": "extlinks",
            "ellimit": 5,
            "format": "json",
        }
        r = requests.get(url, params=params, headers=HEADERS, timeout=6)
        r.raise_for_status()
        pages = r.json().get("query", {}).get("pages", {})
        for page in pages.values():
            for ext in page.get("extlinks", [])[:3]:
                ext_url = ext.get("*")
                if ext_url and ext_url.startswith("http"):
                    domain = re.sub(r"^https?://(www\.)?", "", ext_url).split("/")[0]
                    related.append({"label": f"Site externe : {domain}", "url": ext_url})
    except Exception:
        pass

    return related[: limit + 3]


def search_wikipedia(query, lang="fr", include_related=True):
    """Cherche un résumé pertinent sur Wikipédia, avec liens connexes."""
    try:
        search_url = f"https://{lang}.wikipedia.org/w/api.php"
        params = {
            "action": "query",
            "list": "search",
            "srsearch": query,
            "format": "json",
            "srlimit": 1,
        }
        r = requests.get(search_url, params=params, headers=HEADERS, timeout=6)
        r.raise_for_status()
        results = r.json().get("query", {}).get("search", [])
        if not results:
            return None

        title = results[0]["title"]
        summary_url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{title}"
        r2 = requests.get(summary_url, headers=HEADERS, timeout=6)
        if r2.status_code != 200:
            return None
        data = r2.json()
        extract = data.get("extract")
        if not extract:
            return None

        result = {
            "source": "Wikipédia" if lang == "fr" else "Wikipedia (EN)",
            "title": data.get("title", title),
            "text": extract,
            "url": data.get("content_urls", {}).get("desktop", {}).get("page",
                    f"https://{lang}.wikipedia.org/wiki/{title}"),
            "related_links": [],
        }

        if include_related:
            result["related_links"] = get_wikipedia_related_links(title, lang=lang)

        return result
    except Exception:
        return None


def search_duckduckgo(query):
    """Cherche une réponse instantanée via l'API DuckDuckGo (gratuite, sans clé)."""
    try:
        url = "https://api.duckduckgo.com/"
        params = {
            "q": query,
            "format": "json",
            "no_redirect": 1,
            "no_html": 1,
            "skip_disambig": 1,
        }
        r = requests.get(url, params=params, headers=HEADERS, timeout=6)
        r.raise_for_status()
        data = r.json()

        text = data.get("AbstractText") or ""
        if not text and data.get("RelatedTopics"):
            first = data["RelatedTopics"][0]
            text = first.get("Text", "") if isinstance(first, dict) else ""

        if not text:
            return None

        return {
            "source": "DuckDuckGo",
            "title": data.get("Heading", query),
            "text": text,
            "url": data.get("AbstractURL") or "https://duckduckgo.com",
        }
    except Exception:
        return None


def search_wiktionary(query, lang="fr"):
    """Fallback pour les définitions de mots simples."""
    try:
        url = f"https://{lang}.wiktionary.org/api/rest_v1/page/summary/{query}"
        r = requests.get(url, headers=HEADERS, timeout=6)
        if r.status_code != 200:
            return None
        data = r.json()
        extract = data.get("extract")
        if not extract:
            return None
        return {
            "source": "Wiktionnaire",
            "title": data.get("title", query),
            "text": extract,
            "url": data.get("content_urls", {}).get("desktop", {}).get("page", ""),
        }
    except Exception:
        return None


def search_wikidata(query, lang="fr"):
    """Cherche une entité structurée sur Wikidata (dates, chiffres, relations)."""
    try:
        search_url = "https://www.wikidata.org/w/api.php"
        params = {
            "action": "wbsearchentities",
            "search": query,
            "language": lang,
            "format": "json",
            "limit": 1,
        }
        r = requests.get(search_url, params=params, headers=HEADERS, timeout=6)
        r.raise_for_status()
        results = r.json().get("search", [])
        if not results:
            return None

        entity = results[0]
        description = entity.get("description")
        label = entity.get("label", query)
        if not description:
            return None

        entity_id = entity.get("id")
        return {
            "source": "Wikidata",
            "title": label,
            "text": f"{label} : {description}.",
            "url": f"https://www.wikidata.org/wiki/{entity_id}" if entity_id else "https://www.wikidata.org",
        }
    except Exception:
        return None


def search_news(query, lang="fr"):
    """
    Cherche des articles d'actualité récents via le flux RSS public de
    Google News (gratuit, sans clé API). Utile pour les questions sur
    l'actualité, contrairement à Wikipédia qui est plus encyclopédique.
    """
    try:
        url = f"https://news.google.com/rss/search?q={quote(query)}&hl={lang}&gl=FR&ceid=FR:{lang}"
        r = requests.get(url, headers=HEADERS, timeout=6)
        r.raise_for_status()

        root = ET.fromstring(r.content)
        items = root.findall(".//item")
        if not items:
            return None

        first = items[0]
        title = first.findtext("title") or query
        link = first.findtext("link") or "https://news.google.com"
        source_el = first.find("source")
        source_name = source_el.text if source_el is not None else "Presse"

        return {
            "source": f"Actualité ({source_name})",
            "title": title,
            "text": title,  # le flux RSS ne fournit que le titre, pas de résumé
            "url": link,
        }
    except Exception:
        return None


def search_wikinews(query, lang="fr"):
    """Source d'actualité alternative, ouverte, en complément de Google News."""
    try:
        search_url = f"https://{lang}.wikinews.org/w/api.php"
        params = {
            "action": "query",
            "list": "search",
            "srsearch": query,
            "format": "json",
            "srlimit": 1,
        }
        r = requests.get(search_url, params=params, headers=HEADERS, timeout=6)
        r.raise_for_status()
        results = r.json().get("query", {}).get("search", [])
        if not results:
            return None

        title = results[0]["title"]
        snippet = re.sub(r"<[^>]+>", "", results[0].get("snippet", ""))
        if not snippet:
            return None

        return {
            "source": "Wikinews",
            "title": title,
            "text": snippet,
            "url": f"https://{lang}.wikinews.org/wiki/{title.replace(' ', '_')}",
        }
    except Exception:
        return None


# ---------------------------------------------------------------------------
# RECHERCHE WEB ÉLARGIE (sites officiels trouvés dans les grands moteurs)
# ---------------------------------------------------------------------------
# En complément des API structurées ci-dessus, on peut aussi aller chercher
# directement dans les pages web indexées par un moteur de recherche généraliste
# (DuckDuckGo HTML, sans clé API). Cela permet d'atteindre des sites officiels
# (gouvernements, institutions, organisations internationales...) qui ne sont
# pas couverts par Wikipédia/Wikidata/DuckDuckGo Instant Answer.

def _extract_visible_text(html, max_chars=600):
    """Extraction de texte très simple à partir d'un HTML, sans dépendance externe."""
    html = re.sub(r"(?is)<(script|style|noscript|header|footer|nav)[^>]*>.*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", html)
    text = re.sub(r"&nbsp;", " ", text)
    text = re.sub(r"&amp;", "&", text)
    text = re.sub(r"&[a-zA-Z]{2,6};", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_chars]


def search_web_duckduckgo_html(query, max_results=3, site_filter=None):
    """
    Recherche web généraliste via la version HTML publique de DuckDuckGo
    (pas de clé API requise). Permet de "rentrer" dans n'importe quel site
    indexé, y compris des sites officiels, contrairement à l'API Instant
    Answer qui ne couvre que des réponses courtes toutes faites.
    """
    try:
        q = f"site:{site_filter} {query}" if site_filter else query
        url = "https://html.duckduckgo.com/html/"
        r = requests.post(url, data={"q": q}, headers=HEADERS, timeout=8)
        r.raise_for_status()

        results = []
        for match in re.finditer(
            r'(?is)<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>.*?'
            r'class="result__snippet"[^>]*>(.*?)</a>',
            r.text,
        ):
            raw_href, raw_title, raw_snippet = match.groups()
            # DuckDuckGo redirige les liens via /l/?uddg=<url encodée>
            href = raw_href
            if "uddg=" in href:
                parsed = parse_qs(urlparse(href).query)
                if parsed.get("uddg"):
                    href = unquote(parsed["uddg"][0])
            title = _extract_visible_text(raw_title, 200)
            snippet = _extract_visible_text(raw_snippet, 400)
            if href.startswith("http") and title:
                results.append({"title": title, "url": href, "snippet": snippet})
            if len(results) >= max_results:
                break
        return results
    except Exception:
        return []


# ---------------------------------------------------------------------------
# PROTECTION SSRF (point 25) — jamais de confiance aveugle dans une URL
# ---------------------------------------------------------------------------
# Les URLs qu'on va chercher côté serveur (fetch_page_snippet) viennent des
# résultats DuckDuckGo — donc en théorie manipulables. Sans ce contrôle, une
# URL pointant vers le réseau interne du serveur (localhost, IP privées,
# métadonnées cloud comme 169.254.169.254) serait interrogée par LE SERVEUR
# lui-même, ce qui peut exposer des services internes normalement
# inaccessibles depuis l'extérieur. On ne fait confiance qu'à http(s) vers
# une IP publique, résolue et vérifiée AVANT toute requête.

def is_safe_external_url(url):
    """
    Retourne True seulement si l'URL est http(s) et pointe vers une adresse
    IP publique (pas privée, pas loopback, pas lien-local, pas réservée).
    Toute incertitude (échec de résolution DNS, format invalide) => False,
    par prudence.
    """
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        if not parsed.hostname:
            return False

        # Résout le nom de domaine en IP AVANT de faire confiance à l'URL —
        # un nom de domaine peut être configuré pour pointer vers une IP
        # interne ("DNS rebinding"), donc on vérifie l'IP réelle, pas juste
        # l'apparence du nom de domaine.
        resolved_ip = socket.gethostbyname(parsed.hostname)
        ip_obj = ipaddress.ip_address(resolved_ip)

        if (
            ip_obj.is_private
            or ip_obj.is_loopback
            or ip_obj.is_link_local
            or ip_obj.is_reserved
            or ip_obj.is_multicast
            or ip_obj.is_unspecified
        ):
            return False

        return True
    except Exception:
        # DNS injoignable, format invalide, etc. -> jamais "sûr par défaut"
        return False


def fetch_page_snippet(url, max_chars=500):
    """Va chercher un court extrait de texte directement sur la page officielle."""
    if not is_safe_external_url(url):
        return None
    try:
        r = requests.get(url, headers=HEADERS, timeout=8)
        r.raise_for_status()
        text = _extract_visible_text(r.text, max_chars=max_chars)
        return text or None
    except Exception:
        return None


def search_official_web(query, max_results=2):
    """
    Repli générique : cherche des pages web pertinentes (potentiellement des
    sites officiels/institutionnels) via DuckDuckGo HTML, et va lire un
    extrait réel de la page trouvée plutôt que de se fier au seul snippet
    du moteur de recherche (pour limiter le risque d'information tronquée).
    """
    sources = []
    for res in search_web_duckduckgo_html(query, max_results=max_results):
        text = fetch_page_snippet(res["url"]) or res.get("snippet")
        if not text:
            continue
        domain = re.sub(r"^https?://(www\.)?", "", res["url"]).split("/")[0]
        sources.append({
            "source": f"Web ({domain})",
            "title": res["title"],
            "text": text,
            "url": res["url"],
        })
    return sources


# ---------------------------------------------------------------------------
# SITES OFFICIELS DE LA RÉPUBLIQUE DU BÉNIN (projet "Veritas BJ")
# ---------------------------------------------------------------------------
# Liste de domaines officiels béninois vérifiés manuellement. Volontairement
# restreinte à des domaines confirmés plutôt qu'exhaustive : mieux vaut moins
# de sources mais toutes fiables, que des URLs devinées et potentiellement
# fausses. À enrichir au fil du temps.

BENIN_OFFICIAL_SITES = {
    "gouv.bj": "Portail du Gouvernement du Bénin",
    "presidence.bj": "Présidence de la République du Bénin",
    "assemblee-nationale.bj": "Assemblée Nationale du Bénin",
    "sgg.gouv.bj": "Secrétariat Général du Gouvernement (textes officiels)",
    "journalofficiel.gouv.bj": "Journal Officiel du Bénin",
    "finances.bj": "Ministère de l'Économie et des Finances",
    "impots.finances.gouv.bj": "Direction Générale des Impôts (DGI)",
    "e-services.impots.bj": "Téléservices des impôts (déclaration/paiement en ligne)",
    "douanes.gouv.bj": "Direction Générale des Douanes et Droits Indirects",
    "justice.gouv.bj": "Ministère de la Justice et de la Législation",
    "diplomatie.gouv.bj": "Ministère des Affaires Étrangères",
    "developpement.gouv.bj": "Ministère du Développement",
    "service-public.bj": "Portail National des Services Publics",
    "marches-publics.bj": "Plateforme des Marchés Publics du Bénin",
    "andf.bj": "Agence Nationale du Domaine et du Foncier (ANDF)",
    "evisa.gouv.bj": "e-Visa Bénin",
    "dei.gouv.bj": "Direction de l'Émigration et de l'Immigration",
    "ravip.bj": "RAVIP (recensement / identification de la population)",
    "anip.bj": "Agence Nationale d'Identification des Personnes (ANIP)",
    "instad.bj": "Institut National de la Statistique et de la Démographie (ex-INSAE)",
    "apdp.bj": "Autorité de Protection des Données Personnelles",
}

# Mots-clés qui orientent vers un domaine précis plutôt que le portail général
BENIN_TOPIC_DOMAINS = [
    (("e-visa", "evisa", "visa electronique", "visa électronique"), "evisa.gouv.bj"),
    (("passeport", "immigration", "emigration", "carte de sejour", "carte de séjour"), "dei.gouv.bj"),
    (("anip", "npi", "cip", "identification des personnes"), "anip.bj"),
    (("ravip", "recensement"), "ravip.bj"),
    (("insae", "instad", "statistique", "demographie", "démographie", "recensement general"), "instad.bj"),
    (("declaration d'impot", "déclaration d'impôt", "e-services impots", "ifu", "telepaiement", "télépaiement"), "e-services.impots.bj"),
    (("impot", "impôt", "dgi", "impots.finances"), "impots.finances.gouv.bj"),
    (("finances publiques", "budget de l'etat", "budget de l'état", "ministere des finances"), "finances.bj"),
    (("douane", "douanes", "dedouanement", "dédouanement", "import", "export"), "douanes.gouv.bj"),
    (("marche public", "marchés public", "marchés publics", "marches publics", "appel d'offre"), "marches-publics.bj"),
    (("foncier", "cadastre", "titre foncier", "notaire"), "andf.bj"),
    (("assemblee nationale", "assemblée nationale", "depute", "député", "loi votee", "loi votée"), "assemblee-nationale.bj"),
    (("justice", "tribunal", "code penal", "code pénal", "legislation", "législation"), "justice.gouv.bj"),
    (("ambassade", "diplomatie", "affaires etrangeres", "affaires étrangères", "consulat"), "diplomatie.gouv.bj"),
    (("decret", "décret", "journal officiel", "ordonnance"), "sgg.gouv.bj"),
    (("donnees personnelles", "données personnelles", "protection des donnees"), "apdp.bj"),
]

BENIN_KEYWORDS = (
    "benin", "bénin", "beninois", "béninois", "beninoise", "béninoise",
    "cotonou", "porto-novo", "porto novo", "parakou", "talon", "wadagni",
) + tuple(BENIN_OFFICIAL_SITES.keys())


def is_benin_query(query):
    q = query.lower()
    return any(kw in q for kw in BENIN_KEYWORDS)


def pick_benin_domains(query, max_domains=2):
    q = query.lower()
    matched = []
    for keywords, domain in BENIN_TOPIC_DOMAINS:
        if any(kw in q for kw in keywords) and domain not in matched:
            matched.append(domain)
    if not matched:
        matched = ["gouv.bj", "presidence.bj"]
    return matched[:max_domains]


def search_benin_official(query, max_domains=2):
    """Cherche la réponse directement sur les sites officiels du Bénin."""
    sources = []
    for domain in pick_benin_domains(query, max_domains=max_domains):
        results = search_web_duckduckgo_html(query, max_results=1, site_filter=domain)
        if not results:
            continue
        res = results[0]
        text = fetch_page_snippet(res["url"]) or res.get("snippet")
        if not text:
            continue
        label = BENIN_OFFICIAL_SITES.get(domain, domain)
        sources.append({
            "source": f"Site officiel — {label}",
            "title": res["title"],
            "text": text,
            "url": res["url"],
        })
    return sources


# ---------------------------------------------------------------------------
# CROISEMENT DES SOURCES
# ---------------------------------------------------------------------------

def clean_text(t):
    return re.sub(r"\s+", " ", t).strip()


# ---------------------------------------------------------------------------
# DÉTECTION DE CONTRADICTIONS CHIFFRÉES (bornée, honnête sur ses limites)
# ---------------------------------------------------------------------------
# Ce n'est PAS un vrai système de fact-checking (extraction d'affirmations,
# comparaison sémantique) — ça, c'est un sujet à part entière (RAG + NLP).
# Ceci ne fait qu'une chose précise et fiable : repérer quand deux sources
# citent un chiffre différent pour la même unité (ex. "15 milliards FCFA" vs
# "17 milliards FCFA"), pour ne jamais annoncer "vérifié" en pareil cas — quitte
# à rater des contradictions non numériques (limite assumée, pas cachée).

_NUMBER_UNIT_RE = re.compile(
    r"(\d[\d\s.,]{0,12}\d|\d)\s*"
    r"(milliards?|millions?|mille|%|fcfa|habitants?|ans|km2|km²)",
    re.IGNORECASE,
)


def _extract_numbers_by_unit(text):
    """Renvoie {unité_normalisée: valeur_numérique} pour la 1ère occurrence de chaque unité."""
    found = {}
    for match in _NUMBER_UNIT_RE.finditer(text):
        raw_number, unit = match.groups()
        unit = unit.lower()
        try:
            value = float(raw_number.replace(" ", "").replace(",", "."))
        except ValueError:
            continue
        if unit not in found:
            found[unit] = value
    return found


def detect_numeric_contradiction(sources):
    """
    Compare les chiffres cités par chaque source. Renvoie None si rien de
    suspect, ou un dict décrivant le conflit sinon (jamais caché à l'utilisateur,
    conformément à la règle : une contradiction importante ne se masque pas).
    """
    per_source_numbers = []
    for s in sources:
        nums = _extract_numbers_by_unit(s.get("text", ""))
        if nums:
            per_source_numbers.append((s, nums))

    if len(per_source_numbers) < 2:
        return None

    for unit in set().union(*(nums.keys() for _, nums in per_source_numbers)):
        values_by_source = [(s, nums[unit]) for s, nums in per_source_numbers if unit in nums]
        if len(values_by_source) < 2:
            continue
        distinct_values = {round(v, 6) for _, v in values_by_source}
        if len(distinct_values) < 2:
            continue
        # Tolère les petits écarts d'arrondi/formatage (< 0.5% de différence relative)
        vals = sorted(distinct_values)
        relative_gap = (vals[-1] - vals[0]) / vals[-1] if vals[-1] else 0
        if relative_gap < 0.005:
            continue
        return {
            "unit": unit,
            "conflicting": [
                {"source": s["source"], "url": s["url"], "value": v}
                for s, v in values_by_source
            ],
        }
    return None


def _wiki_task(query):
    """Wikipédia FR, repli EN si rien trouvé (dépendance interne, reste une seule tâche)."""
    wiki = search_wikipedia(query, lang="fr")
    if not wiki:
        wiki = search_wikipedia(query, lang="en")
    return wiki


def _news_task(query):
    """Google News, repli Wikinews si rien trouvé (dépendance interne, reste une seule tâche)."""
    news = search_news(query)
    return news if news else search_wikinews(query)


def ai_formulate_answer(main_text, other_snippets):
    """
    Tente de faire reformuler la réponse par le moteur IA local (formulation
    plus naturelle qu'un simple template), avec des règles strictes contre
    l'invention de faits. Retourne None si le moteur est indisponible ou en
    erreur — l'appelant retombe alors sur humanizer.py (templates), qui reste
    le mode de repli garanti de Veritas BJ, jamais remplacé de force.

    Limite assumée et non cachée : un petit modèle 3B sur CPU peut, malgré la
    consigne, reformuler de façon imprécise sur des cas complexes. C'est un
    risque connu des LLM, pas un bug — voir AI_LOCAL.md pour le contexte.
    """
    provider = get_ai_provider()
    if not provider.is_available():
        return None

    system = (
        "Tu es Veritas BJ, un assistant qui reformule des extraits de sources "
        "de façon naturelle et concise, en français. RÈGLES STRICTES : "
        "1) N'utilise QUE les informations présentes dans les extraits fournis. "
        "2) N'ajoute JAMAIS un fait, un chiffre, une date ou un nom qui n'est "
        "pas explicitement dans les extraits. "
        "3) Si les extraits ne suffisent pas à répondre complètement, dis-le "
        "plutôt que de compléter par toi-même. "
        "4) Reste bref (3-5 phrases maximum)."
    )
    prompt = f"Extrait principal :\n{main_text}\n"
    if other_snippets:
        prompt += "\nAutres extraits (à mentionner seulement s'ils apportent une info utile et différente) :\n"
        prompt += "\n".join(f"- {s}" for s in other_snippets[:2])
    prompt += "\n\nReformule ces extraits en une réponse naturelle, sans rien inventer."

    return provider.generate(prompt, system=system)


# ---------------------------------------------------------------------------
# RÉPONSES IDENTITÉ / CONVERSATION (routées par l'orchestrateur)
# ---------------------------------------------------------------------------
# L'identité de Veritas BJ (point 35) ne dépend JAMAIS du modèle IA — un petit
# modèle local pourrait halluciner un autre nom. C'est un texte fixe, fiable
# à 100%, quel que soit l'état du moteur IA.
IDENTITY_TEXT = (
    "Je suis Veritas BJ 🇧🇯, un assistant qui cherche et croise plusieurs "
    "sources — Wikipédia, DuckDuckGo, les sites officiels du Bénin, l'actualité "
    "— pour te répondre avec ses preuves. Je ne suis pas un humain, et je ne "
    "prétends jamais l'être. Une question ?"
)

_CANNED_GREETINGS = [
    "Bonjour ! Je suis Veritas BJ. Pose-moi une question quand tu veux.",
    "Salut ! Comment puis-je t'aider aujourd'hui ?",
    "Bonjour, je t'écoute.",
]
_CANNED_THANKS = ["Avec plaisir !", "De rien, n'hésite pas si tu as d'autres questions.", "Content d'avoir pu aider !"]


def conversation_reply(query):
    """
    Réponse à une salutation/formule de politesse. Tente le moteur IA local
    pour une formulation plus naturelle et adaptée (personnalité définie au
    point 35 : professionnelle, calme, pédagogique) ; sinon repli sur une
    réponse simple mais toujours correcte.
    """
    provider = get_ai_provider()
    if provider.is_available():
        system = (
            "Tu es Veritas BJ, un assistant béninois professionnel, calme et "
            "pédagogique (jamais familier à l'excès, jamais froid). Réponds "
            "en une phrase courte à ce message de politesse, en français. "
            "Ne prétends jamais être humain."
        )
        ai_reply = provider.generate(query, system=system)
        if ai_reply:
            return ai_reply

    q_lower = query.lower()
    if "merci" in q_lower:
        return random.choice(_CANNED_THANKS)
    return random.choice(_CANNED_GREETINGS)


# ---------------------------------------------------------------------------
# MÉMOIRE CONVERSATIONNELLE — résolution de contexte (point 10)
# ---------------------------------------------------------------------------
# On ne fait JAMAIS suivre tout l'historique d'une conversation à une
# recherche ou au modèle : seulement une fenêtre bornée des derniers échanges
# (voir MAX_HISTORY_MESSAGES). Le vrai résumé automatique des très longues
# conversations n'est PAS implémenté ici — limite assumée, pas cachée (voir
# AI_LOCAL.md et le README pour le détail de ce qui est fait/pas fait).

MAX_HISTORY_MESSAGES = 8  # 4 échanges (question+réponse) maximum
MAX_HISTORY_MESSAGE_CHARS = 500  # anti-abus : un message énorme dans l'historique n'explose pas le prompt


def sanitize_history(raw_history):
    """
    Ne fait jamais confiance à ce qu'envoie le client : borne la taille et le
    format, quoi qu'il envoie (même 10 000 messages ou des champs manquants).
    """
    if not isinstance(raw_history, list):
        return []
    clean = []
    for item in raw_history[-MAX_HISTORY_MESSAGES:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        text = item.get("text")
        if role in ("user", "ai") and isinstance(text, str) and text.strip():
            clean.append({"role": role, "text": text.strip()[:MAX_HISTORY_MESSAGE_CHARS]})
    return clean


def resolve_query_with_context(query, history):
    """
    Reformule la question en une question autonome si elle contient une
    référence au contexte ('il', 'et lui', 'continue'...), en s'appuyant
    UNIQUEMENT sur les derniers échanges fournis. Retourne la question
    d'origine si : pas d'historique, moteur IA indisponible, ou la
    reformulation échoue/semble invalide — jamais de blocage.
    """
    if not history:
        return query

    provider = get_ai_provider()
    if not provider.is_available():
        # Limite honnête : sans moteur IA, pas de résolution de contexte
        # possible ; la question part telle quelle, comme avant cette étape.
        return query

    context_lines = [
        f"{'Utilisateur' if m['role'] == 'user' else 'Veritas'} : {m['text']}"
        for m in history
    ]
    system = (
        "Tu reformules une question en une question autonome et complète, en "
        "t'appuyant UNIQUEMENT sur le contexte de conversation fourni pour "
        "résoudre les références ('il', 'elle', 'ça', 'et lui', 'continue', "
        "'pourquoi'...). N'ajoute AUCUNE information absente du contexte ou "
        "de la question. Si la question est déjà autonome, renvoie-la telle "
        "quelle. Réponds UNIQUEMENT avec la question reformulée, sans "
        "commentaire ni guillemets."
    )
    prompt = "Contexte de la conversation :\n" + "\n".join(context_lines) + f"\n\nQuestion à reformuler : {query}"

    rewritten = provider.generate(prompt, system=system)
    if not rewritten:
        return query

    rewritten = rewritten.strip().strip('"').strip()
    # Garde-fous : une reformulation vide, absurdement longue, ou qui ne
    # ressemble plus à une question est ignorée par prudence.
    if not rewritten or len(rewritten) > 300:
        return query
    return rewritten


def build_answer(query):
    """Interroge plusieurs sources en parallèle et construit une réponse consolidée."""
    sources = []
    related_links = []

    # Les sources ci-dessous sont indépendantes les unes des autres : on les
    # interroge EN PARALLÈLE plutôt qu'en série. Avant ce correctif, jusqu'à
    # 5 requêtes HTTP s'enchaînaient l'une après l'autre (jusqu'à 6-8s de
    # timeout chacune) ; maintenant elles tournent en même temps, la durée
    # totale de cette étape est celle de la plus lente d'entre elles, pas la
    # somme de toutes.
    tasks = {}
    with ThreadPoolExecutor(max_workers=6) as executor:
        if is_benin_query(query):
            tasks["benin"] = executor.submit(search_benin_official, query)
            tasks["kb"] = executor.submit(search_knowledge_base, query)
        tasks["wiki"] = executor.submit(_wiki_task, query)
        tasks["ddg"] = executor.submit(search_duckduckgo, query)
        tasks["wikidata"] = executor.submit(search_wikidata, query)
        tasks["news"] = executor.submit(_news_task, query)

        results = {}
        for name, future in tasks.items():
            try:
                results[name] = future.result()
            except Exception as e:
                # Une source qui échoue (timeout, erreur réseau...) ne doit
                # jamais faire planter les autres ni la réponse globale —
                # mais on le note dans les logs pour pouvoir diagnostiquer
                # une source qui échouerait systématiquement.
                log_event("warning", f"Source '{name}' indisponible", tool=name, error=str(e))
                results[name] = None

    # Ordre de reconstitution identique à l'ancienne version séquentielle,
    # pour ne rien changer au comportement de sélection du texte principal.
    # La base de connaissances Bénin passe juste après les sites officiels
    # (même niveau de confiance visé, contenu pré-vérifié à l'ingestion).
    if results.get("benin"):
        sources.extend(results["benin"])

    if results.get("kb"):
        sources.extend(results["kb"])

    wiki = results.get("wiki")
    if wiki:
        sources.append(wiki)
        related_links.extend(wiki.get("related_links", []))

    if results.get("ddg"):
        sources.append(results["ddg"])

    if results.get("wikidata"):
        sources.append(results["wikidata"])

    if results.get("news"):
        sources.append(results["news"])

    if not sources:
        wikt = search_wiktionary(query)
        if wikt:
            sources.append(wikt)

    # Repli final : recherche web élargie (sites officiels et institutionnels
    # indexés par les grands moteurs), utile quand aucune des API structurées
    # ci-dessus n'a de résultat, ou pour renforcer une réponse avec très peu
    # de sources.
    if len(sources) < 2:
        for extra in search_official_web(query, max_results=2):
            if extra["url"] not in {s["url"] for s in sources}:
                sources.append(extra)

    if not sources:
        return {
            "answer": no_result_message(),
            "sources": [],
            "related_links": [],
            "verified": False,
            "verification_status": "INSUFFICIENT_EVIDENCE",
        }

    # Texte principal : priorité absolue à un site officiel béninois ou à la
    # base de connaissances Bénin (contenu pré-vérifié à l'ingestion) s'il y
    # en a un. Sinon, l'extrait le plus informatif (le plus long, hors
    # actualité qui ne fournit qu'un titre court).
    official = next(
        (s for s in sources if s["source"].startswith("Site officiel") or s["source"].startswith("Base de connaissances")),
        None,
    )
    text_sources = [s for s in sources if s["source"] != "Wikidata" and not s["source"].startswith("Actualité")]
    if official:
        main = official
    elif text_sources:
        main = max(text_sources, key=lambda s: len(s["text"]))
    else:
        main = sources[0]
    main_text = clean_text(main["text"])
    if len(main_text) > 700:
        main_text = main_text[:700].rsplit(".", 1)[0] + "."

    other_snippets = [clean_text(s["text"]) for s in sources if s is not main]

    contradiction = detect_numeric_contradiction(sources)

    # On tente d'abord une formulation par le moteur IA local (plus naturelle) ;
    # s'il est indisponible, en erreur, ou hors délai, on retombe immédiatement
    # sur les templates de humanizer.py — jamais de blocage, jamais de plantage.
    answer_text = ai_formulate_answer(main_text, other_snippets)
    if not answer_text:
        if len(sources) >= 2:
            answer_text = humanize_multi_source(main_text, other_snippets)
        else:
            answer_text = humanize_single_source(main_text)

    # Statut de vérification honnête :
    # - CONTRADICTED : des sources donnent des chiffres différents pour la même
    #   unité -> jamais annoncé comme fiable, la contradiction est montrée telle quelle.
    # - CONFIRMED : au moins 2 sources indépendantes, sans contradiction chiffrée détectée
    #   (ça reste une corroboration, pas une preuve absolue).
    # - UNCONFIRMED : une seule source disponible.
    if contradiction:
        verification_status = "CONTRADICTED"
        answer_text += (
            f"\n\n⚠️ Attention : les sources ne donnent pas le même chiffre "
            f"pour « {contradiction['unit']} » — "
            + " vs ".join(f"{c['value']:g} ({c['source']})" for c in contradiction["conflicting"])
            + ". Vérifie directement les sources ci-dessous avant de considérer ce chiffre comme fiable."
        )
    elif len(sources) >= 2:
        verification_status = "CONFIRMED"
    else:
        verification_status = "UNCONFIRMED"

    verified = verification_status == "CONFIRMED"

    # Dédoublonnage des liens connexes, limité à 6 pour ne pas surcharger l'interface
    seen_urls = set()
    unique_related = []
    for link in related_links:
        if link["url"] not in seen_urls:
            seen_urls.add(link["url"])
            unique_related.append(link)
    unique_related = unique_related[:6]

    return {
        "answer": answer_text,
        "sources": [{"source": s["source"], "title": s["title"], "url": s["url"]} for s in sources],
        "related_links": unique_related,
        "verified": verified,
        "verification_status": verification_status,
    }


# ---------------------------------------------------------------------------
# "INFO LA PLUS POPULAIRE DU JOUR" (mise à jour automatique)
# ---------------------------------------------------------------------------
# On utilise l'API officielle de pageviews de Wikimedia : le classement des
# articles les plus consultés est un fait réel et vérifiable (pas une
# invention), là où un LLM générique pourrait halluciner "ce qui buzz
# aujourd'hui". Cette API a ~1 jour de décalage (les stats de la veille se
# consolident dans la nuit), on utilise donc la date d'hier.

_TRENDING_CACHE = {"date": None, "topic": None, "teaser": None, "detail": None}

_TRENDING_EXCLUDE_PREFIXES = (
    "Spécial:", "Wikipédia:", "Portail:", "Modèle:", "Catégorie:",
    "Aide:", "Fichier:", "Discussion", "Utilisateur:",
)
_TRENDING_EXCLUDE_TITLES = {"Wikipédia:Accueil_principal", "Page_de_titre", "-", "Recherche"}


def _fetch_trending_wikipedia_title():
    """Renvoie le titre de l'article francophone le plus consulté hier (hors pages techniques)."""
    try:
        yesterday = datetime.date.today() - datetime.timedelta(days=1)
        url = (
            "https://wikimedia.org/api/rest_v1/metrics/pageviews/top/fr.wikipedia/"
            f"all-access/{yesterday.year}/{yesterday.month:02d}/{yesterday.day:02d}"
        )
        r = requests.get(url, headers=HEADERS, timeout=6)
        r.raise_for_status()
        articles = r.json().get("items", [{}])[0].get("articles", [])
        for article in articles:
            title = article.get("article", "")
            if title in _TRENDING_EXCLUDE_TITLES:
                continue
            if any(title.startswith(p) for p in _TRENDING_EXCLUDE_PREFIXES):
                continue
            return title.replace("_", " ")
        return None
    except Exception:
        return None


def get_trending_topic():
    """
    Retourne le sujet le plus populaire du jour, avec mise en cache (une seule
    requête externe par jour, pas à chaque visite) :
    {"topic": "Nom", "teaser": "phrase courte", "full": {réponse complète type build_answer}}
    """
    today_key = datetime.date.today().isoformat()
    if _TRENDING_CACHE["date"] == today_key and _TRENDING_CACHE["topic"]:
        return _TRENDING_CACHE

    title = _fetch_trending_wikipedia_title()
    if not title:
        return None

    wiki = search_wikipedia(title, lang="fr", include_related=True)
    if not wiki:
        return None

    teaser_text = clean_text(wiki["text"])
    if len(teaser_text) > 160:
        teaser_text = teaser_text[:160].rsplit(" ", 1)[0] + "…"

    _TRENDING_CACHE.update({
        "date": today_key,
        "topic": title,
        "teaser": teaser_text,
        "detail": build_answer(title),
    })
    return _TRENDING_CACHE


@app.route("/api/daily-briefing", methods=["GET"])
def daily_briefing():
    """Renvoie un message de bienvenue personnalisé avec le sujet le plus populaire du jour."""
    username = request.args.get("username", "").strip() or "cher utilisateur"
    trending = get_trending_topic()

    if trending:
        message = (
            f"Bonjour {username} 👋 Aujourd'hui, on parle beaucoup de "
            f"**{trending['topic']}** — {trending['teaser']} "
            f"Tu veux que je t'en dise plus ?"
        )
    else:
        trending = None
        message = (
            f"Bonjour {username} 👋 Je n'ai pas pu récupérer le sujet du jour "
            f"pour le moment, mais pose-moi une question quand tu veux !"
        )

    return jsonify({
        "message": message,
        "trending_topic": trending["topic"] if trending else None,
        "date": datetime.date.today().isoformat(),
    })


@app.route("/api/trending-detail", methods=["GET"])
def trending_detail():
    """Renvoie la réponse complète (avec sources) sur le sujet le plus populaire du jour."""
    trending = get_trending_topic()
    if not trending:
        return jsonify({"error": "Aucun sujet tendance disponible pour le moment."}), 404
    return jsonify(trending["detail"])


# ---------------------------------------------------------------------------
# ENDPOINT PRINCIPAL
# ---------------------------------------------------------------------------

@app.route("/api/ask", methods=["POST"])
@limiter.limit("20 per minute")
def ask():
    data = request.get_json(silent=True) or {}
    query = (data.get("query") or "").strip()
    history = sanitize_history(data.get("history"))

    if not query:
        return jsonify({"error": "La question est vide."}), 400
    if len(query) > 500:
        return jsonify({"error": "La question est trop longue (max 500 caractères)."}), 400

    # Orchestrateur (point 8) : on route selon l'intention détectée plutôt que
    # de toujours lancer une recherche web complète, même pour "25 x 12" ou
    # "bonjour" — plus rapide, et plus pertinent. La détection d'intention se
    # fait sur la question BRUTE (pas de résolution de contexte utile pour
    # "bonjour" ou un calcul).
    intent = detect_intent(query)
    log_event("info", "Question reçue", intent=intent, query_length=len(query))

    if intent == "IDENTITY":
        return jsonify({
            "answer": IDENTITY_TEXT, "sources": [], "related_links": [],
            "verified": True, "verification_status": "CONFIRMED", "intent": intent,
            # Clé de la banque de phrases Fon (knowledge/benin/fon_phrases.json)
            # à utiliser pour /api/tts — seulement si validée par un locuteur
            # natif, sinon /api/tts renverra une erreur explicite (pas de son).
            "tts_phrase_key": "identity",
        })

    if intent == "CALCULATION":
        calc_result = try_calculate(query) or try_calculate_average(query)
        if calc_result is not None:
            return jsonify({
                "answer": calc_result, "sources": [{"source": "Calculatrice Veritas", "title": "Calcul", "url": ""}],
                "related_links": [], "verified": True, "verification_status": "CONFIRMED", "intent": intent,
            })
        # La question ressemblait à un calcul mais n'en était pas un
        # exploitable (ex. "calcule ma moyenne" sans les notes) -> on ne
        # bloque jamais, on retombe sur la recherche normale.
        intent = "SEARCH"

    if intent == "CONVERSATION":
        return jsonify({
            "answer": conversation_reply(query), "sources": [], "related_links": [],
            "verified": True, "verification_status": "CONFIRMED", "intent": intent,
        })

    # Mémoire conversationnelle (point 10) : seulement ici, pour une vraie
    # recherche, où résoudre "il"/"et lui"/"continue" change réellement le
    # résultat. La question envoyée à build_answer peut différer de celle
    # affichée à l'utilisateur (transparence : on renvoie les deux).
    effective_query = resolve_query_with_context(query, history)

    result = build_answer(effective_query)
    result["intent"] = intent
    if effective_query != query:
        result["resolved_query"] = effective_query
    return jsonify(result)


_fon_phrases_cache = None


def _load_fon_phrases():
    """Charge knowledge/benin/fon_phrases.json (mis en cache en mémoire).
    Fichier absent ou invalide -> dict vide, jamais de crash serveur pour
    une fonctionnalité optionnelle et désactivée par défaut."""
    global _fon_phrases_cache
    if _fon_phrases_cache is None:
        try:
            with open(app_config.FON_PHRASES_PATH, "r", encoding="utf-8") as f:
                _fon_phrases_cache = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            log_event("error", "Impossible de charger fon_phrases.json", error=str(exc))
            _fon_phrases_cache = {}
    return _fon_phrases_cache


@app.route("/api/tts", methods=["POST"])
@limiter.limit("20 per minute")
def text_to_speech_fon():
    """
    Audio Fon pour une phrase de la banque, ou traduction automatique
    expérimentale — voir FON_TTS.md.

    Deux modes, mutuellement exclusifs :
    - {"phrase_key": "..."} : phrase de la banque validée par un humain
      (voir plus bas). Recommandé, fiable.
    - {"text": "...", "auto_translate": true} : traduction automatique
      NLLB-200 + synthèse. NON VÉRIFIÉ par un humain — le frontend doit
      afficher un avertissement explicite avant/à côté de ce bouton.

    Priorité 1 (recommandée, mode phrase_key) : un vrai fichier audio
    enregistré par un humain dans knowledge/benin/audio_fon/ (voir
    tools/fon_recorder.html).
    Priorité 2 (repli, mode phrase_key) : synthèse IA
    (ai/tts_fon_provider.py), seulement si TTS_ENABLED=1 et qu'aucun
    fichier audio n'est disponible.

    Dans le mode phrase_key, "validated": true est obligatoire dans
    fon_phrases.json — jamais de Fon deviné ou traduit automatiquement
    diffusé SANS avertissement à un utilisateur réel.
    """
    data = request.get_json(silent=True) or {}
    phrase_key = (data.get("phrase_key") or "").strip()
    auto_translate = bool(data.get("auto_translate"))
    free_text = (data.get("text") or "").strip()

    # --- Mode expérimental : traduction automatique NLLB + synthèse ---
    # Distinct du mode "phrase_key" ci-dessous : ici, PAS de validation
    # humaine, la traduction peut contenir des erreurs. Le frontend doit
    # afficher un avertissement explicite pour tout appel utilisant ce mode
    # (voir app.js, bouton "🔊 Fon (auto, non vérifié)").
    if auto_translate:
        if not app_config.AUTO_TRANSLATE_FON_ENABLED:
            return jsonify({
                "error": "La traduction automatique Fon n'est pas activée "
                         "sur ce serveur (AUTO_TRANSLATE_FON_ENABLED=0) — "
                         "voir FON_TTS.md."
            }), 503
        if not free_text:
            return jsonify({"error": "text manquant pour la traduction automatique."}), 400
        if len(free_text) > 400:
            return jsonify({"error": "Texte trop long pour la traduction automatique (max 400 caractères)."}), 400
        try:
            from ai.translate_fon_provider import translate_fr_to_fon, FonTranslationUnavailable
            from ai.tts_fon_provider import synthesize_fon, FonTTSUnavailable
            fon_text = translate_fr_to_fon(free_text)
            audio_bytes = synthesize_fon(fon_text)
        except (FonTranslationUnavailable, FonTTSUnavailable) as exc:
            log_event("error", "Pipeline traduction/TTS Fon indisponible", error=str(exc))
            return jsonify({"error": str(exc)}), 503
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400
        response = app.response_class(audio_bytes, mimetype="audio/wav")
        # En-tête informatif seulement (le frontend n'en dépend pas pour
        # afficher son propre avertissement, qui doit être visible AVANT
        # même l'appel) — utile pour du débogage/inspection.
        response.headers["X-Veritas-Fon-Verified"] = "false"
        return response

    if not phrase_key:
        return jsonify({"error": "phrase_key manquant."}), 400

    phrases = _load_fon_phrases()
    entry = phrases.get(phrase_key)
    if not entry:
        return jsonify({"error": f"Clé inconnue : '{phrase_key}'."}), 404
    if not entry.get("validated"):
        return jsonify({
            "error": "Cette phrase n'a pas encore été validée par un(e) "
                     "locuteur(trice) Fon natif(ve) — audio non disponible "
                     "pour l'instant (voir FON_TTS.md)."
        }), 409

    # Priorité 1 : vrai enregistrement humain
    audio_file = entry.get("audio_file")
    if audio_file:
        audio_path = os.path.join(app_config.FON_AUDIO_DIR, audio_file)
        if os.path.isfile(audio_path):
            mimetype = {
                ".webm": "audio/webm", ".mp3": "audio/mpeg",
                ".wav": "audio/wav", ".ogg": "audio/ogg",
            }.get(os.path.splitext(audio_path)[1].lower(), "application/octet-stream")
            with open(audio_path, "rb") as f:
                return app.response_class(f.read(), mimetype=mimetype)
        log_event("error", "Fichier audio Fon manquant", phrase_key=phrase_key, expected=audio_path)
        return jsonify({
            "error": f"Fichier audio attendu introuvable : {audio_file}. "
                     "Enregistre-le avec tools/fon_recorder.html et place-le "
                     f"dans {app_config.FON_AUDIO_DIR}/."
        }), 404

    # Priorité 2 : repli sur la synthèse IA (nécessite TTS_ENABLED=1)
    if not app_config.TTS_ENABLED:
        return jsonify({
            "error": "Aucun enregistrement humain disponible pour cette "
                     "phrase, et la synthèse IA (TTS_ENABLED) n'est pas "
                     "activée. Voir FON_TTS.md."
        }), 503
    fon_text = (entry.get("fon") or "").strip()
    if not fon_text:
        return jsonify({"error": f"Aucun texte Fon renseigné pour '{phrase_key}'."}), 409
    try:
        from ai.tts_fon_provider import synthesize_fon, FonTTSUnavailable
        audio_bytes = synthesize_fon(fon_text)
    except FonTTSUnavailable as exc:
        log_event("error", "TTS Fon indisponible", error=str(exc))
        return jsonify({"error": str(exc)}), 503
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    return app.response_class(audio_bytes, mimetype="audio/wav")


MAX_AUDIO_UPLOAD_SIZE = 5 * 1024 * 1024  # 5 Mo — court message vocal, pas un fichier long


@app.route("/api/stt", methods=["POST"])
@limiter.limit("15 per minute")
def speech_to_text_fon():
    """
    Reconnaissance vocale Fon — voir FON_TTS.md et ai/asr_fon_provider.py.

    Reçoit un fichier audio (multipart, champ "audio"), retourne :
    - "fon_text" : transcription brute (modèle whettenr/asr-fon-with-diacritics)
    - "fr_text" : traduction automatique en français (NLLB), pour rejoindre
      le moteur de recherche existant

    HONNÊTETÉ : les deux champs sont des BROUILLONS. Aucune validation
    humaine n'a eu lieu. Le frontend doit toujours laisser la personne
    relire/corriger avant d'envoyer une vraie question — jamais d'envoi
    automatique direct à /api/ask.
    """
    if not app_config.STT_ENABLED:
        return jsonify({
            "error": "La reconnaissance vocale Fon n'est pas activée sur ce "
                     "serveur (STT_ENABLED=0). Voir FON_TTS.md."
        }), 503

    if "audio" not in request.files:
        return jsonify({"error": "Aucun fichier audio reçu (champ 'audio' attendu)."}), 400
    audio_file = request.files["audio"]

    audio_bytes = audio_file.read(MAX_AUDIO_UPLOAD_SIZE + 1)
    if len(audio_bytes) > MAX_AUDIO_UPLOAD_SIZE:
        return jsonify({"error": "Fichier audio trop volumineux (max 5 Mo — un message court suffit)."}), 413
    if not audio_bytes:
        return jsonify({"error": "Fichier audio vide."}), 400

    suffix = os.path.splitext(audio_file.filename or "")[1] or ".webm"

    try:
        from ai.asr_fon_provider import transcribe_fon, FonASRUnavailable
        fon_text = transcribe_fon(audio_bytes, original_suffix=suffix)
    except FonASRUnavailable as exc:
        log_event("error", "ASR Fon indisponible", error=str(exc))
        return jsonify({"error": str(exc)}), 503
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    if not fon_text:
        return jsonify({
            "fon_text": "", "fr_text": "",
            "warning": "Aucune parole détectée dans l'enregistrement.",
        })

    fr_text = None
    translation_error = None
    if app_config.AUTO_TRANSLATE_FON_ENABLED:
        try:
            from ai.translate_fon_provider import translate_fon_to_fr, FonTranslationUnavailable
            fr_text = translate_fon_to_fr(fon_text)
        except (FonTranslationUnavailable, ValueError) as exc:
            translation_error = str(exc)
            log_event("error", "Traduction Fon->FR indisponible", error=translation_error)

    return jsonify({
        "fon_text": fon_text,
        "fr_text": fr_text,
        "translation_error": translation_error,
        "warning": "Transcription et traduction automatiques, non vérifiées "
                   "— relis avant d'envoyer.",
    })


MAX_DOCUMENT_UPLOAD_SIZE = 5 * 1024 * 1024  # 5 Mo


@app.route("/api/documents/analyze", methods=["POST"])
@login_required
@limiter.limit("10 per hour")
def analyze_document():
    """
    Analyse un document PDF ou TXT (point 24) : résumé ou réponse à une
    question, traité entièrement côté serveur. Nécessite le moteur IA
    (local ou Gemini) — contrairement à la recherche web, cette
    fonctionnalité n'a pas de repli par template : un résumé fiable
    nécessite une vraie compréhension du texte, jamais simulée.
    """
    if "file" not in request.files:
        return jsonify({"error": "Aucun fichier envoyé (champ 'file' manquant)."}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "Nom de fichier manquant."}), 400

    mode = (request.form.get("mode") or "summary").strip().lower()
    question = (request.form.get("question") or "").strip()
    if mode not in ("summary", "qa"):
        return jsonify({"error": "Mode invalide (attendu : 'summary' ou 'qa')."}), 400
    if mode == "qa" and not question:
        return jsonify({"error": "Une question est requise en mode questions/réponses."}), 400

    # Lit au maximum MAX_DOCUMENT_UPLOAD_SIZE + 1 octet : suffisant pour
    # détecter un dépassement sans avoir à charger un fichier énorme en
    # entier en mémoire avant de le rejeter.
    file_bytes = file.read(MAX_DOCUMENT_UPLOAD_SIZE + 1)
    if len(file_bytes) > MAX_DOCUMENT_UPLOAD_SIZE:
        return jsonify({"error": "Fichier trop volumineux (5 Mo maximum)."}), 400
    if not file_bytes:
        return jsonify({"error": "Fichier vide."}), 400

    try:
        text, truncated = extract_text(file.filename, file_bytes)
    except DocumentError as e:
        return jsonify({"error": str(e)}), 400

    provider = get_ai_provider()
    if not provider.is_available():
        return jsonify({
            "error": "L'analyse de documents nécessite le moteur IA (Ollama local, ou Gemini) — "
                     "actuellement indisponible. Voir AI_LOCAL.md pour l'installation."
        }), 503

    if mode == "qa":
        from ai.local_provider import OllamaEmbedder
        embedder = OllamaEmbedder(
            endpoint=app_config.LOCAL_AI_ENDPOINT,
            model=app_config.EMBEDDING_MODEL,
            timeout=app_config.EMBEDDING_TIMEOUT,
        )
        result = answer_document_question(provider, text, question, truncated, embedder=embedder)
    else:
        result = summarize_document(provider, text, truncated)

    if result is None:
        return jsonify({"error": "L'analyse a échoué (le moteur IA n'a pas pu générer de réponse)."}), 500

    log_event("info", "Document analysé", tool="document", mode=mode, truncated=truncated)

    return jsonify({"answer": result, "truncated": truncated, "mode": mode})


@app.route("/api/health", methods=["GET"])
def health():
    """
    Health check réel (point 29) : vérifie chaque composant plutôt que de
    renvoyer un "ok" de façade. N'expose aucune info sensible (pas de config,
    pas de secrets) — juste des statuts booléens/textuels.
    """
    ai_provider = get_ai_provider()
    ai_ok = ai_provider.is_available()

    try:
        db.session.execute(db.text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False

    components = {
        "api": True,  # si ce code s'exécute, l'API répond
        "database": db_ok,
        "ai_local": ai_ok,  # informatif seulement : Veritas reste fonctionnel sans (repli humanizer)
    }
    overall = "healthy" if all([components["api"], components["database"]]) else "unhealthy"
    if overall == "healthy" and not ai_ok:
        overall = "degraded"  # dégradé, pas en panne : le repli template prend le relai

    return jsonify({"status": overall, "components": components})


@app.route("/api/about", methods=["GET"])
def about():
    return jsonify({
        "app": "Veritas",
        "developer": "AlphaDevs BJ 🦁",
        "contact": "alphadevsbj229@gmail.com",
        "sources": [
            "Wikipédia (FR/EN)", "DuckDuckGo", "Wikidata", "Wiktionnaire",
            "Google News", "Wikinews", "Liens connexes Wikipédia",
            "Recherche web élargie (DuckDuckGo HTML)",
            "Sites officiels du Bénin (gouv.bj, presidence.bj, assemblee-nationale.bj, "
            "sgg.gouv.bj, journalofficiel.gouv.bj, finances.bj, impots.finances.gouv.bj, "
            "e-services.impots.bj, douanes.gouv.bj, justice.gouv.bj, diplomatie.gouv.bj, "
            "developpement.gouv.bj, service-public.bj, marches-publics.bj, andf.bj, "
            "evisa.gouv.bj, dei.gouv.bj, ravip.bj, anip.bj, instad.bj, apdp.bj)",
            "Base de connaissances Bénin (documents vérifiés, indexés localement)",
        ],
    })


if __name__ == "__main__":
    # Debug désactivé par défaut : ne l'active qu'en développement local avec
    # FLASK_DEBUG=1. Jamais en production (expose la stack trace complète).
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=5000, debug=debug_mode)
