# Déployer le backend Veritas sur Render (gratuit)

Ce guide suppose que tu n'as ni compte GitHub ni compte Render.

## Étape 1 — Créer un compte GitHub (si pas déjà fait)

1. Va sur https://github.com
2. "Sign up" → email, mot de passe, nom d'utilisateur
3. Confirme ton email

## Étape 2 — Mettre le projet sur GitHub

1. Sur github.com, clique le bouton **"+"** en haut à droite → **"New repository"**
2. Nom du dépôt : `veritas`
3. Laisse "Public" coché, ne coche aucune case en bas
4. Clique **"Create repository"**
5. Sur la page qui s'affiche, clique **"uploading an existing file"**
6. Glisse-dépose **tout le contenu du dossier `veritas`** (tous les fichiers à la racine : `app.py`, `render.yaml`, etc.)
7. En bas, clique **"Commit changes"**

## Étape 3 — Créer ton compte Render

1. Va sur https://render.com
2. **"Get Started"** → connecte-toi avec ton compte **GitHub** (le plus simple, un seul clic)
3. Autorise Render à accéder à tes dépôts GitHub

## Étape 4 — Déployer le backend

1. Sur le tableau de bord Render, clique **"New +"** → **"Web Service"**
2. Choisis ton dépôt `veritas` dans la liste (connecte-le si demandé)
3. Render devrait détecter automatiquement le fichier `render.yaml` et pré-remplir la config. Si ce n'est pas le cas, renseigne manuellement :
   - **Name** : `veritas-backend`
   - **Root Directory** : laisse vide
   - **Runtime** : Python 3
   - **Build Command** : `pip install -r requirements.txt`
   - **Start Command** : `gunicorn app:app --bind 0.0.0.0:$PORT`
   - **Plan** : Free
4. Descends jusqu'à **"Environment Variables"** → clique **"Add Environment Variable"**
   - Key : `SECRET_KEY`
   - Value : n'importe quelle longue chaîne aléatoire, par exemple `a8f3k2m9x7q1w5e4r6t8y2u3i0p9o8l7`
   (Cette clé sert à sécuriser les sessions de connexion — garde-la secrète, ne la partage à personne.)
5. Clique **"Create Web Service"**

Render va installer les dépendances et démarrer le serveur — ça prend 2 à 5 minutes la première fois. Tu peux suivre les logs en direct sur la page.

## Étape 5 — Récupérer l'adresse de ton backend

Une fois le déploiement terminé (statut "Live" en vert), Render t'attribue une adresse du type :

```
https://veritas-backend-xxxx.onrender.com
```

**Note cette adresse précieusement** — c'est elle qu'on utilisera dans l'appli Android pour contacter le serveur.

Teste-la : ouvre `https://veritas-backend-xxxx.onrender.com/api/health` dans un navigateur. Tu dois voir `{"status": "ok"}`.

## Limites importantes à connaître (plan gratuit Render)

- **Le serveur s'endort après 15 minutes d'inactivité.** La première requête après une pause peut prendre 30-50 secondes le temps qu'il se réveille — c'est normal, pas un bug.
- **La base de données SQLite est réinitialisée à chaque redéploiement.** Si tu modifies le code et redéploies, tous les comptes/conversations sont perdus. Pour un usage sérieux à long terme, il faudrait passer à une vraie base de données persistante (PostgreSQL, aussi disponible gratuitement sur Render) — dis-le-moi quand tu en seras là, on pourra migrer.
- C'est largement suffisant pour tester et développer l'appli Android tranquillement.
