"""
Veritas - Authentification
----------------------------
Inscription / connexion par email + mot de passe.
- Mots de passe hashés avec bcrypt (jamais stockés en clair).
- Sessions gérées par token JWT signé, valable 30 jours, envoyé dans le
  header `Authorization: Bearer <token>` de chaque requête protégée.

Développé par AlphaDevs BJ 🦁
"""

import re
import os
import secrets
import hashlib
import datetime
from functools import wraps

import bcrypt
import jwt
from flask import request, jsonify, current_app
from google.oauth2 import id_token as google_id_token
from google.auth.transport import requests as google_auth_requests

import config
from models import db, User, RevokedToken, PasswordResetToken
from email_utils import send_email

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
TOKEN_LIFETIME_DAYS = 30
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")


def _hash_reset_token(raw_token):
    """SHA-256 suffit ici (contrairement à un mot de passe) : le jeton brut a
    une entropie énorme (secrets.token_urlsafe(32)), pas besoin d'un hachage
    lent type bcrypt pour se protéger d'une attaque par force brute."""
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Aides
# ---------------------------------------------------------------------------

def _validate_password(password):
    """Au moins 8 caractères, avec au moins une lettre et un chiffre."""
    if not password or len(password) < 8:
        return "Le mot de passe doit contenir au moins 8 caractères."
    if not re.search(r"[A-Za-z]", password):
        return "Le mot de passe doit contenir au moins une lettre."
    if not re.search(r"[0-9]", password):
        return "Le mot de passe doit contenir au moins un chiffre."
    return None


def _hash_password(password):
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def _check_password(password, password_hash):
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except Exception:
        return False


def _issue_token(user_id):
    payload = {
        "user_id": user_id,
        "jti": secrets.token_hex(16),  # identifiant unique du token, nécessaire pour pouvoir le révoquer individuellement
        "exp": datetime.datetime.utcnow() + datetime.timedelta(days=TOKEN_LIFETIME_DAYS),
        "iat": datetime.datetime.utcnow(),
    }
    return jwt.encode(payload, current_app.config["SECRET_KEY"], algorithm="HS256")


def _decode_token(token):
    return jwt.decode(token, current_app.config["SECRET_KEY"], algorithms=["HS256"])


# ---------------------------------------------------------------------------
# Décorateur de protection des routes
# ---------------------------------------------------------------------------

def login_required(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Authentification requise."}), 401

        token = auth_header.split(" ", 1)[1].strip()
        try:
            payload = _decode_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Session expirée, merci de te reconnecter."}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Token invalide."}), 401

        # Vérifie que ce token précis n'a pas été explicitement révoqué
        # (déconnexion) avant d'accepter la requête, même s'il n'est pas
        # encore expiré naturellement.
        jti = payload.get("jti")
        if jti and RevokedToken.query.filter_by(jti=jti).first():
            return jsonify({"error": "Session déconnectée, merci de te reconnecter."}), 401

        user = User.query.get(payload.get("user_id"))
        if not user:
            return jsonify({"error": "Utilisateur introuvable."}), 401

        # Si le mot de passe a été changé APRÈS l'émission de ce token
        # (réinitialisation), le token est encore "valide" cryptographiquement
        # mais ne doit plus être accepté — sinon un token volé avant un
        # changement de mot de passe resterait utilisable après coup.
        if user.password_changed_at and payload.get("iat"):
            issued_at = datetime.datetime.utcfromtimestamp(payload["iat"])
            if issued_at < user.password_changed_at:
                return jsonify({"error": "Mot de passe changé depuis, merci de te reconnecter."}), 401

        request.current_user = user
        request.current_token_payload = payload  # nécessaire pour /api/auth/logout
        return view_func(*args, **kwargs)

    return wrapper


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

def register_auth_routes(app, limiter=None):
    # Décorateur no-op si aucun limiteur n'est fourni (ex. tests unitaires) :
    # évite de rendre flask-limiter obligatoire pour utiliser ce module.
    limit = limiter.limit if limiter else (lambda *a, **k: (lambda f: f))

    @app.route("/api/auth/register", methods=["POST"])
    @limit("5 per hour")
    def auth_register():
        data = request.get_json(silent=True) or {}
        username = (data.get("username") or "").strip()
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""

        if not username:
            return jsonify({"error": "Le pseudo est requis."}), 400
        if not EMAIL_RE.match(email):
            return jsonify({"error": "Adresse email invalide."}), 400
        pwd_error = _validate_password(password)
        if pwd_error:
            return jsonify({"error": pwd_error}), 400

        if User.query.filter_by(email=email).first():
            return jsonify({"error": "Un compte existe déjà avec cet email."}), 409

        user = User(
            email=email,
            username=username[:50],
            password_hash=_hash_password(password),
        )
        db.session.add(user)
        db.session.commit()

        token = _issue_token(user.id)
        return jsonify({"token": token, "user": user.to_public_dict()}), 201

    @app.route("/api/auth/login", methods=["POST"])
    @limit("10 per minute")
    def auth_login():
        data = request.get_json(silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""

        user = User.query.filter_by(email=email).first()
        if not user or not _check_password(password, user.password_hash):
            return jsonify({"error": "Email ou mot de passe incorrect."}), 401

        token = _issue_token(user.id)
        return jsonify({"token": token, "user": user.to_public_dict()})

    @app.route("/api/auth/google", methods=["POST"])
    @limit("10 per minute")
    def auth_google():
        """
        Connexion via Google Identity Services. Le frontend envoie le jeton
        d'identité (`credential`) reçu de Google ; on le vérifie ici
        cryptographiquement (signature + audience) avant de faire confiance
        à son contenu — on ne fait jamais confiance à un jeton non vérifié.
        """
        if not GOOGLE_CLIENT_ID:
            return jsonify({
                "error": "La connexion Google n'est pas configurée côté serveur "
                         "(variable d'environnement GOOGLE_CLIENT_ID manquante)."
            }), 500

        data = request.get_json(silent=True) or {}
        credential = data.get("credential")
        if not credential:
            return jsonify({"error": "Jeton Google manquant."}), 400

        try:
            idinfo = google_id_token.verify_oauth2_token(
                credential, google_auth_requests.Request(), GOOGLE_CLIENT_ID
            )
        except Exception:
            return jsonify({"error": "Jeton Google invalide ou expiré."}), 401

        if not idinfo.get("email_verified", True):
            return jsonify({"error": "Cette adresse email Google n'est pas vérifiée."}), 401

        google_sub = idinfo["sub"]
        email = (idinfo.get("email") or "").strip().lower()
        name = idinfo.get("name") or email.split("@")[0] or "Utilisateur Google"
        picture = idinfo.get("picture")

        user = User.query.filter_by(google_id=google_sub).first()
        if not user:
            # Un compte existe déjà avec cet email (créé par mot de passe) : on le lie.
            user = User.query.filter_by(email=email).first()
            if user:
                user.google_id = google_sub
            else:
                user = User(
                    email=email,
                    username=name[:50],
                    google_id=google_sub,
                    avatar_url=picture,
                    password_hash=None,
                )
                db.session.add(user)
        if picture and user.avatar_url != picture:
            user.avatar_url = picture
        db.session.commit()

        token = _issue_token(user.id)
        return jsonify({"token": token, "user": user.to_public_dict()})

    @app.route("/api/auth/me", methods=["GET"])
    @login_required
    def auth_me():
        return jsonify({"user": request.current_user.to_public_dict()})

    @app.route("/api/auth/logout", methods=["POST"])
    @login_required
    def auth_logout():
        """
        Révoque le token actuel : il devient immédiatement invalide, même
        avant sa date d'expiration naturelle (30 jours). Sans ça, "se
        déconnecter" n'était qu'un effacement local côté navigateur — le
        token restait utilisable ailleurs (voir point 26).
        """
        payload = request.current_token_payload
        jti = payload.get("jti")
        if jti:
            exp_timestamp = payload.get("exp")
            expires_at = (
                datetime.datetime.utcfromtimestamp(exp_timestamp)
                if exp_timestamp else datetime.datetime.utcnow() + datetime.timedelta(days=TOKEN_LIFETIME_DAYS)
            )
            db.session.add(RevokedToken(jti=jti, expires_at=expires_at))

            # Nettoyage opportuniste (pas de tâche planifiée séparée, on reste
            # simple) : purge les entrées déjà expirées à chaque déconnexion,
            # pour empêcher la table de grossir indéfiniment.
            RevokedToken.query.filter(RevokedToken.expires_at < datetime.datetime.utcnow()).delete()

            db.session.commit()

        return jsonify({"message": "Déconnecté."})

    @app.route("/api/auth/forgot-password", methods=["POST"])
    @limit("3 per hour")
    def auth_forgot_password():
        """
        Envoie un lien de réinitialisation par email. Renvoie TOUJOURS le
        même message générique, que l'email existe ou non — sinon on
        laisserait n'importe qui déterminer quelles adresses ont un compte
        chez nous (énumération d'utilisateurs), une fuite d'info discrète
        mais réelle.
        """
        data = request.get_json(silent=True) or {}
        email = (data.get("email") or "").strip().lower()
        generic_message = {
            "message": "Si un compte existe avec cet email, un lien de réinitialisation vient d'être envoyé."
        }

        if not EMAIL_RE.match(email):
            return jsonify(generic_message)  # même réponse, pas d'indice sur la validité du format

        user = User.query.filter_by(email=email).first()
        if user and user.password_hash:  # un compte Google pur n'a pas de mot de passe à réinitialiser
            raw_token = secrets.token_urlsafe(32)
            reset_entry = PasswordResetToken(
                user_id=user.id,
                token_hash=_hash_reset_token(raw_token),
                expires_at=datetime.datetime.utcnow() + datetime.timedelta(
                    minutes=config.PASSWORD_RESET_TOKEN_LIFETIME_MINUTES
                ),
            )
            db.session.add(reset_entry)
            db.session.commit()

            reset_link = f"{config.FRONTEND_URL}/?reset_token={raw_token}"
            send_email(
                to_email=user.email,
                subject="Réinitialisation de ton mot de passe Veritas BJ",
                body=(
                    f"Bonjour {user.username},\n\n"
                    f"Tu as demandé à réinitialiser ton mot de passe Veritas BJ.\n"
                    f"Clique sur ce lien dans les {config.PASSWORD_RESET_TOKEN_LIFETIME_MINUTES} minutes "
                    f"qui suivent pour en choisir un nouveau :\n\n{reset_link}\n\n"
                    f"Si tu n'es pas à l'origine de cette demande, ignore simplement cet email — "
                    f"ton mot de passe actuel reste inchangé.\n\n"
                    f"Veritas BJ 🇧🇯"
                ),
            )
            # Si l'email n'a pas pu être envoyé (SMTP non configuré), on le
            # note dans les logs mais on renvoie quand même le message
            # générique au client — jamais de faux positif ni de fuite
            # d'info sur l'existence du compte.

        return jsonify(generic_message)

    @app.route("/api/auth/reset-password", methods=["POST"])
    @limit("10 per hour")
    def auth_reset_password():
        data = request.get_json(silent=True) or {}
        raw_token = (data.get("token") or "").strip()
        new_password = data.get("password") or ""

        if not raw_token:
            return jsonify({"error": "Jeton de réinitialisation manquant."}), 400

        pwd_error = _validate_password(new_password)
        if pwd_error:
            return jsonify({"error": pwd_error}), 400

        token_hash = _hash_reset_token(raw_token)
        reset_entry = PasswordResetToken.query.filter_by(token_hash=token_hash).first()

        if (
            not reset_entry
            or reset_entry.used
            or reset_entry.expires_at < datetime.datetime.utcnow()
        ):
            return jsonify({"error": "Jeton invalide ou expiré. Refais une demande de réinitialisation."}), 400

        user = User.query.get(reset_entry.user_id)
        if not user:
            return jsonify({"error": "Compte introuvable."}), 404

        user.password_hash = _hash_password(new_password)
        # Tronqué à la seconde : un token JWT encode iat en timestamp Unix
        # entier (perd les microsecondes). Sans cette troncature, un token
        # émis une fraction de seconde après ce changement pourrait sembler
        # "antérieur" à password_changed_at une fois décodé, et être rejeté
        # à tort par login_required alors qu'il vient d'être légitimement émis.
        #
        # Compromis assumé et documenté (pas éliminable sans abandonner les
        # JWT standards) : un ancien token pourrait, dans une fenêtre
        # théorique de moins d'1 seconde coïncidant exactement avec l'instant
        # du changement, rester valide. Non exploitable en pratique (il
        # faudrait qu'un attaquant utilise un token volé exactement la même
        # seconde que le reset) — le compromis inverse (rejeter par excès)
        # casserait le cas beaucoup plus fréquent d'un utilisateur qui se
        # reconnecte juste après avoir réinitialisé son mot de passe.
        user.password_changed_at = datetime.datetime.utcnow().replace(microsecond=0)
        reset_entry.used = True
        db.session.commit()

        return jsonify({"message": "Mot de passe mis à jour. Tu peux te reconnecter."})
