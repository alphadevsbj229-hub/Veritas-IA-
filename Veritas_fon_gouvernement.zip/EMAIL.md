# EMAIL.md — Configurer l'envoi d'email (mot de passe oublié)

Veritas BJ envoie un email uniquement pour la réinitialisation de mot de
passe. Le code fonctionne avec **n'importe quel fournisseur SMTP** — aucun
service précis n'est imposé.

## Sans configuration (par défaut)

La fonctionnalité "mot de passe oublié" reste utilisable côté logique (un
jeton est créé, il expire après 1h, il ne peut servir qu'une fois), mais
**aucun email n'est réellement envoyé**. C'est visible dans les logs
(`logs/veritas.log`) : `"Email non envoyé : SMTP non configuré"`.

## Configurer un fournisseur (exemple avec Gmail)

1. Active la validation en 2 étapes sur le compte Gmail à utiliser
2. Crée un "mot de passe d'application" : [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Configure ces variables d'environnement avant de lancer `python app.py` :

```powershell
$env:SMTP_HOST = "smtp.gmail.com"
$env:SMTP_PORT = "587"
$env:SMTP_USER = "ton-compte@gmail.com"
$env:SMTP_PASSWORD = "le-mot-de-passe-d-application-genere"
$env:SMTP_FROM = "ton-compte@gmail.com"
$env:FRONTEND_URL = "http://localhost:8080"   # ou ton URL de production
```

**Ne mets jamais ce mot de passe d'application dans un fichier versionné ou
un chat** — uniquement en variable d'environnement, comme pour toute clé API
(voir `SECURITY.md`).

## Autres fournisseurs

N'importe quel service qui expose une interface SMTP standard fonctionne de
la même façon (Outlook/Microsoft 365, SendGrid en mode SMTP, Brevo,
Mailgun...) — seuls `SMTP_HOST` et `SMTP_PORT` changent selon le
fournisseur ; consulte leur documentation pour les valeurs exactes.

## Vérifier que ça fonctionne

1. Configure les variables ci-dessus
2. Depuis l'écran de connexion de Veritas, utilise "mot de passe oublié" avec un compte existant
3. Vérifie la boîte de réception (et les spams) de cet email
4. En cas d'échec, regarde `logs/veritas.log` pour le message d'erreur exact (identifiants incorrects, port bloqué par un pare-feu, etc.)
