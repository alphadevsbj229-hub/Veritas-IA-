# INSTALLATION.md — Installer Veritas BJ

Ce fichier regroupe les étapes ; chaque section renvoie vers le guide
détaillé correspondant pour ne pas dupliquer l'information.

## 1. Backend (obligatoire)

```powershell
pip install -r requirements.txt
python app.py
```
Détails, variables d'environnement (`ALLOWED_ORIGINS`, `DATABASE_URL`...) : voir **README.md**, section "1. Lancer le backend".

Fonctionnalités Fon (voix, écoute, traduction) et OCR : **pas nécessaires
pour ce premier lancement**, désactivées par défaut. Voir `requirements-fon.txt`
et **FON_TTS.md** quand tu voudras les activer.

## 2. Frontend (obligatoire)

```powershell
python -m http.server 8080
```
Détails, configuration pour un accès depuis ton téléphone : voir **README.md**, sections "2." et "3.".

## 3. Moteur IA local (recommandé, optionnel)

Installation d'Ollama, choix du modèle (minimal/confort/élevé), base de
connaissances Bénin, fournisseur Gemini optionnel : voir **AI_LOCAL.md**
(guide complet, spécifique Windows).

## 4. Base de données en production (PostgreSQL)

SQLite fonctionne sans rien installer de plus (par défaut). Pour
PostgreSQL en production : voir **MIGRATIONS.md**.

## 5. Vérifier que tout fonctionne

```powershell
pip install -r requirements-dev.txt
pytest
```
Détails : voir **TESTING.md**.

## 6. Déploiement en ligne (accessible depuis n'importe où)

Voir **DEPLOIEMENT.md** (déploiement du backend sur Render, gratuit).

## Ordre recommandé pour un premier lancement

1. Backend (§1) → vérifier `http://localhost:5000/api/health`
2. Frontend (§2) → créer un compte, poser une première question
3. Ollama (§3) → si tu veux des réponses mieux formulées et le contexte conversationnel
4. Tests (§5) → pour confirmer que tout est en ordre avant de personnaliser
