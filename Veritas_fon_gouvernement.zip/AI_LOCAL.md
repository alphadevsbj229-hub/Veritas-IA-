# AI_LOCAL.md — Installer le moteur IA local (Windows)

Veritas BJ utilise **Ollama** comme moteur IA local. Il tourne entièrement sur
ton PC — aucune clé API, aucun compte, aucune donnée envoyée à un tiers pour
la génération de texte. C'est le fournisseur par défaut et recommandé de
Veritas BJ, conçu pour fonctionner avec juste **un PC Windows normal et une
connexion internet** (pas de carte graphique dédiée requise).

**Important à comprendre dès le départ :** le moteur IA local ne sert **pas**
à connaître des faits — il sert à comprendre l'intention de la question et à
formuler la réponse de façon naturelle à partir des sources déjà trouvées par
Veritas (Wikipédia, sites officiels du Bénin, etc.). Les faits viennent
toujours des sources, jamais inventés par le modèle. Si le moteur local est
indisponible ou pas installé, Veritas continue de fonctionner normalement,
avec une formulation par templates (`humanizer.py`) au lieu de l'IA — jamais
de panne totale.

## 1. Configuration minimale requise

- Windows 10 ou 11 (64 bits)
- **8 Go de RAM libre** minimum (16 Go recommandés si tu fais tourner Veritas ET Ollama sur la même machine)
- ~4 Go d'espace disque libre (pour le modèle)
- Une connexion internet (uniquement pour le téléchargement initial du modèle, et pour les recherches habituelles de Veritas — pas besoin d'internet pour la génération IA elle-même une fois le modèle téléchargé)
- Pas de carte graphique dédiée nécessaire — tout tourne sur le processeur (CPU)

## 2. Installer Ollama

1. Va sur [https://ollama.com/download](https://ollama.com/download)
2. Télécharge l'installeur Windows (`OllamaSetup.exe`)
3. Lance-le, suis les instructions (installation standard, aucune option à changer)
4. Ollama démarre automatiquement en arrière-plan après l'installation (une icône apparaît dans la barre des tâches)

## 3. Télécharger le modèle recommandé

Ouvre **PowerShell** (touche Windows → tape "PowerShell" → Entrée) et lance :

```powershell
ollama pull llama3.2:3b
```

Le téléchargement fait environ 2 Go — patiente selon ta connexion. C'est le
modèle par défaut de Veritas BJ (voir `config.py`), choisi spécifiquement
pour tourner de façon fluide sur CPU avec 8 Go de RAM.

**Pour vérifier que ça a fonctionné :**

```powershell
ollama list
```

Tu dois voir `llama3.2:3b` dans la liste.

## 4. Lancer Veritas BJ

Rien de spécial à faire — Ollama tourne déjà en arrière-plan. Lance juste le
backend normalement :

```powershell
pip install -r requirements.txt
python app.py
```

Au démarrage, si tu vas sur `http://localhost:5000/api/health`, tu dois voir
`"ai_local": true` si tout est bien connecté.

## 5. Les 3 profils — prêts à l'avance, tu bascules quand tu veux

Veritas BJ a **déjà** 3 profils de modèle définis dans `config.py`. Tu
démarres avec `minimal` aujourd'hui. Le jour où tu as les moyens d'un
meilleur matériel, tu changes **une seule variable d'environnement** — zéro
ligne de code à modifier, zéro redéploiement compliqué.

| Profil | Modèle | Matériel requis | Statut |
|---|---|---|---|
| `minimal` (actuel) | `llama3.2:3b` | PC Windows standard, CPU seul, 8 Go RAM libre | ✅ C'est ce que tu utilises maintenant |
| `confort` | `llama3.1:8b` | 16 Go RAM, ou petit GPU 6-8 Go VRAM (ex. RTX 4060 Ti 16 Go, ~460 $) | Prêt, à activer quand tu as ce matériel |
| `eleve` | `llama3.1:70b` | GPU sérieux **obligatoire** : 2x RTX 4090 (~6 300 $ à eux seuls) ou 1x A100/H100 80 Go (achat 8 000-15 000 $, ou location dès ~1,09 $/h) | Prêt, à activer quand tu as ce matériel |

**Pour basculer** (PowerShell) :

```powershell
# Passer au profil "confort" une fois le matériel prêt
ollama pull llama3.1:8b
$env:AI_PROFILE = "confort"
python app.py
```

```powershell
# Passer au profil "élevé" une fois le GPU/serveur prêt
ollama pull llama3.1:70b
$env:AI_PROFILE = "eleve"
python app.py
```

⚠️ **Ce que ça change vraiment, et ce que ça ne change pas :**
- Basculer le profil = **instantané et gratuit** côté logiciel (une variable d'environnement)
- Ça ne fait **pas apparaître le matériel par magie** : si tu passes à `eleve` sans le GPU qui va avec, Ollama sera soit incapable de charger le modèle 70B (pas assez de RAM/VRAM), soit extrêmement lent — le système peut se mettre à utiliser le disque dur comme mémoire ("swap"), ce qui transforme une réponse de quelques secondes en plusieurs **minutes**
- Autrement dit : le code est prêt à l'avance, mais c'est toujours l'achat/la location du matériel qui débloque réellement le profil supérieur

## 6. Problèmes fréquents

- **`ai_local: false` dans /api/health alors qu'Ollama est installé** → vérifie qu'Ollama tourne bien (icône dans la barre des tâches) et que le modèle est bien téléchargé (`ollama list`)
- **Réponses très lentes (>20s)** → normal sur CPU seul avec un PC peu puissant ; augmente `LOCAL_AI_TIMEOUT` si besoin (`config.py`), ou passe à un PC avec plus de RAM/CPU
- **Le PC devient lent pendant que Veritas répond** → normal, la génération CPU consomme les ressources du processeur le temps de la réponse (quelques secondes)

## 7. Base de connaissances Bénin (optionnel, mais recommandé)

En plus du modèle de génération, Veritas BJ peut interroger une petite base
de documents vérifiés sur le Bénin (institutions, éducation...), stockés
dans `knowledge/benin/`. Ça demande un second petit modèle Ollama, dédié aux
embeddings (pas à la génération de texte) :

```powershell
ollama pull nomic-embed-text
```

Puis, à chaque fois que tu ajoutes ou modifies un document dans
`knowledge/benin/`, relance l'indexation (obligatoire, ce n'est pas
automatique) :

```powershell
python -m rag.ingest
```

**Comment ajouter un document** : crée un fichier `.md` dans
`knowledge/benin/`, avec ce format exact en en-tête :

```markdown
# Titre du document
Source: https://url-de-la-source-officielle
Consulté le: 2026-09-11

Le contenu du document, en paragraphes normaux...
```

**Règle stricte à respecter toi-même en ajoutant du contenu** : chaque
document doit citer une vraie source vérifiable (site officiel, Wikipédia,
presse sérieuse) — jamais de contenu inventé ou de mémoire non vérifiée. Deux
documents de départ sont déjà fournis (institutions politiques, système
éducatif), sourcés et datés — la base est volontairement petite au démarrage
et prévue pour grandir document par document, pas d'un coup.

Si `nomic-embed-text` n'est pas installé ou qu'aucun document n'a encore été
indexé, Veritas continue de fonctionner normalement — cette source est juste
absente des résultats, sans aucun impact sur le reste.

## 8. Fournisseur cloud optionnel : Gemini (Google)

En plus d'Ollama (local, recommandé), Veritas BJ peut utiliser l'API Gemini
comme second fournisseur — utile si tu veux des réponses plus rapides sans
matériel dédié. **Ce n'est jamais obligatoire** : Veritas fonctionne très
bien sans, avec Ollama.

**Comment activer Gemini :**

1. Récupère une clé API sur [Google AI Studio](https://aistudio.google.com/apikey)
2. **Ne colle JAMAIS cette clé dans un chat, un fichier versionné (Git), ou du code.** Uniquement dans une variable d'environnement, juste avant de lancer le serveur :

```powershell
$env:AI_PROVIDER = "gemini"
$env:GEMINI_API_KEY = "ta-cle-ici"
python app.py
```

3. Si jamais une clé a été exposée accidentellement (collée quelque part par erreur), **révoque-la immédiatement** sur Google AI Studio et génère-en une nouvelle — une clé exposée doit être considérée comme compromise, même si tu penses que personne ne l'a vue.

**Différence importante avec Ollama** : chaque appel à Gemini a un coût réel et une limite de débit (contrairement à Ollama qui est gratuit et local). Pour cette raison, Veritas ne vérifie pas la disponibilité de Gemini par un appel réseau à chaque question — seulement qu'une clé est configurée. Si la clé est invalide ou le quota dépassé, Veritas retombe proprement sur le mode de repli (`humanizer.py`), exactement comme pour Ollama.

**Revenir à Ollama** : remets simplement `AI_PROVIDER=local` (ou ne définis pas la variable, c'est le défaut).

## 9. Aller plus loin (plus tard, pas maintenant)

Si l'usage de Veritas BJ grandit et que ce PC ne suffit plus, les options
(déjà prévues dans l'architecture `AIProvider`, sans réécriture du code) sont
discutées séparément : matériel dédié plus puissant, ou location de GPU dans
le cloud à l'usage. Rien de tout ça n'est nécessaire pour démarrer.
