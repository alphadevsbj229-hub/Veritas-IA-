# MIGRATIONS.md — Faire évoluer la base de données (point 27)

Veritas BJ utilise **Flask-Migrate** (basé sur Alembic) pour gérer les
changements de structure de la base de données en production, sans jamais
dépendre de `db.create_all()` une fois de vraies données en place.

## Pourquoi ça compte

`db.create_all()` (utilisé pour le démarrage rapide en SQLite) crée les
tables si elles n'existent pas, mais **ne modifie jamais** une table
existante. Si demain on ajoute une colonne à `User` et que ta base de
production a déjà des milliers d'utilisateurs, `create_all()` ne fera rien
— la colonne n'apparaîtra jamais. Alembic, lui, sait générer et appliquer
le changement exact (`ALTER TABLE ...`).

## Important : je n'ai pas fabriqué les fichiers de migration à la main

Les fichiers `migrations/env.py` et les scripts de version dans
`migrations/versions/` sont normalement **générés automatiquement** par
Alembic, en inspectant la vraie base de données et les vrais modèles en
train de s'exécuter. Les écrire à la main sans pouvoir les exécuter risquait
de produire des fichiers qui semblent corrects mais échouent au premier
`flask db upgrade` — j'ai préféré ne rien inventer plutôt que de te livrer
quelque chose de potentiellement cassé. Les 3 commandes ci-dessous les
génèrent correctement, chez toi, en une minute.

## Mise en place (une seule fois)

```powershell
pip install -r requirements.txt   # inclut maintenant Flask-Migrate
$env:FLASK_APP = "app.py"

# 1. Initialise le dossier migrations/ (structure standard Alembic)
flask db init

# 2. Génère automatiquement le script de migration en comparant models.py
#    à l'état actuel de la base
flask db migrate -m "Migration initiale : User, Conversation, Message, RevokedToken"

# 3. Applique la migration à la base configurée (DATABASE_URL, ou SQLite par défaut)
flask db upgrade
```

Après ça, un dossier `migrations/` apparaît dans le projet — **commite-le
dans Git**, il fait partie du projet au même titre que le code.

## Ajouter un changement plus tard (ex. nouvelle colonne)

1. Modifie `models.py` normalement (ajoute ta colonne, ta table...)
2. Génère la migration : `flask db migrate -m "Description du changement"`
3. **Relis le script généré** dans `migrations/versions/` avant de l'appliquer — l'autogénération d'Alembic est très bonne mais pas infaillible (elle ne détecte pas tout, ex. un renommage de colonne est vu comme une suppression + un ajout)
4. Applique : `flask db upgrade`

## Passer à PostgreSQL en production

```powershell
pip install psycopg2-binary
$env:DATABASE_URL = "postgresql://utilisateur:motdepasse@hote/nom_de_la_base"
flask db upgrade
```

`app.py` détecte automatiquement que `DATABASE_URL` ne commence pas par
`sqlite` et n'appelle plus `create_all()` — c'est bien `flask db upgrade`
qui prend le relais pour créer/faire évoluer les tables.

## Revenir en arrière (annuler la dernière migration)

```powershell
flask db downgrade
```
