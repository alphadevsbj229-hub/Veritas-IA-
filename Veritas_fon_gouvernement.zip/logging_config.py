"""
Veritas BJ - Logs structurés
--------------------------------
Chaque ligne de log est un objet JSON, avec un request_id commun à toutes
les lignes d'une même requête HTTP — pour pouvoir reconstituer le parcours
complet d'une question ("quelle recherche a été lancée, quelle source a
échoué, combien de temps ça a pris") sans avoir à deviner (point 30).

RÈGLE ABSOLUE, jamais contournée : mot de passe, token JWT, secrets, ou
données personnelles inutiles ne sont JAMAIS écrits dans les logs — voir
_FORBIDDEN_KEYS ci-dessous, qui filtre activement plutôt que de compter sur
la discipline de chaque appelant.

Fichiers de logs : logs/veritas.log (rotation automatique à 5 Mo, 3 fichiers
d'historique max — jamais un fichier qui grossit indéfiniment).

Développé par AlphaDevs BJ 🦁
"""

import json
import logging
import logging.handlers
import os
import datetime

try:
    from flask import g, has_request_context
except ImportError:  # utilisable même hors contexte Flask (scripts, tests)
    g = None
    def has_request_context():
        return False

LOG_DIR = os.environ.get("LOG_DIR", "logs")
LOG_FILE = os.path.join(LOG_DIR, "veritas.log")

# Champs qui ne doivent JAMAIS apparaître dans un log, quoi qu'un appelant
# tente d'y mettre par erreur — filtre actif, pas une simple convention.
_FORBIDDEN_KEYS = {
    "password", "token", "authorization", "secret", "secret_key",
    "client_secret", "credential", "jwt", "api_key",
}


class JsonFormatter(logging.Formatter):
    def format(self, record):
        payload = {
            "timestamp": datetime.datetime.utcfromtimestamp(record.created).isoformat() + "Z",
            "level": record.levelname,
            "message": record.getMessage(),
        }
        # Les champs additionnels passés via logger.info(msg, extra={...})
        # arrivent comme attributs du record ; on ne garde que ceux qu'on a
        # explicitement ajoutés (voir log_event), en filtrant les interdits.
        for key, value in getattr(record, "extra_fields", {}).items():
            if key.lower() in _FORBIDDEN_KEYS:
                continue
            payload[key] = value
        return json.dumps(payload, ensure_ascii=False)


def setup_logging():
    """À appeler une seule fois, au démarrage de app.py."""
    os.makedirs(LOG_DIR, exist_ok=True)

    logger = logging.getLogger("veritas")
    if logger.handlers:
        return logger  # déjà configuré (évite les doublons si rappelé par erreur)

    logger.setLevel(logging.INFO)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(JsonFormatter())
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(JsonFormatter())
    logger.addHandler(console_handler)

    return logger


def log_event(level, message, **fields):
    """
    Écrit une ligne de log structurée, avec le request_id de la requête HTTP
    en cours si disponible (voir app.py::_log_request_start). Filtre déjà
    géré dans JsonFormatter, mais on ne fait jamais confiance à un seul
    filet de sécurité — voir aussi le filtrage dans JsonFormatter.
    """
    logger = logging.getLogger("veritas")

    if has_request_context() and g is not None:
        request_id = getattr(g, "request_id", None)
        if request_id:
            fields.setdefault("request_id", request_id)

    clean_fields = {k: v for k, v in fields.items() if k.lower() not in _FORBIDDEN_KEYS}

    log_fn = {"info": logger.info, "warning": logger.warning, "error": logger.error}.get(level, logger.info)
    log_fn(message, extra={"extra_fields": clean_fields})
