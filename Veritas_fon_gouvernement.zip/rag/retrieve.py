"""
Veritas BJ - Recherche dans la base de connaissances (RAG)
----------------------------------------------------------------
Trouve les morceaux de documents les plus pertinents pour une question, par
similarité cosinus entre l'embedding de la question et ceux de l'index
(généré par `python -m rag.ingest`). Python pur, sans dépendance numpy/faiss
— largement suffisant pour un index de quelques centaines de morceaux.

Développé par AlphaDevs BJ 🦁
"""

import json
import math
import os

import config
from ai.local_provider import OllamaEmbedder

_index_cache = None
_index_cache_key = None  # (chemin, date de modification) — les deux, pas juste la date


def _cosine_similarity(a, b):
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def load_index():
    """
    Charge l'index depuis le disque, avec un cache invalidé si le fichier a
    changé OU si le chemin lui-même a changé (ex. tests, changement de
    config) — un cache clé uniquement sur la date, sans le chemin, pourrait
    en théorie servir le mauvais index si deux fichiers différents avaient
    la même date de modification. Retourne [] si l'index n'existe pas
    encore — jamais d'erreur.
    """
    global _index_cache, _index_cache_key

    path = config.KNOWLEDGE_INDEX_PATH
    if not os.path.exists(path):
        return []

    cache_key = (path, os.path.getmtime(path))
    if _index_cache is not None and _index_cache_key == cache_key:
        return _index_cache

    try:
        with open(path, "r", encoding="utf-8") as f:
            _index_cache = json.load(f)
        _index_cache_key = cache_key
    except Exception:
        return []

    return _index_cache


def search_knowledge_base(query, top_k=2, min_score=0.55):
    """
    Retourne les morceaux les plus pertinents, au même format que les autres
    sources de app.py, ou [] si : index vide, modèle d'embeddings
    indisponible, ou rien d'assez pertinent (voir min_score — évite de
    renvoyer un morceau sans rapport juste parce que c'est le "moins pire").
    """
    index = load_index()
    if not index:
        return []

    embedder = OllamaEmbedder(
        endpoint=config.LOCAL_AI_ENDPOINT,
        model=config.EMBEDDING_MODEL,
        timeout=config.EMBEDDING_TIMEOUT,
    )
    query_vector = embedder.embed(query)
    if query_vector is None:
        return []

    scored = [
        (entry, _cosine_similarity(query_vector, entry["embedding"]))
        for entry in index
    ]
    scored.sort(key=lambda pair: pair[1], reverse=True)

    results = []
    seen_files = set()
    for entry, score in scored:
        if score < min_score:
            break
        # Au plus un morceau par document source dans les résultats, pour ne
        # pas monopoliser les sources avec plusieurs extraits du même texte.
        if entry["source_file"] in seen_files:
            continue
        seen_files.add(entry["source_file"])
        results.append({
            "source": f"Base de connaissances Bénin — {entry['title']}",
            "title": entry["title"],
            "url": entry.get("source_url") or "",
            "text": entry["text"],
        })
        if len(results) >= top_k:
            break

    return results
