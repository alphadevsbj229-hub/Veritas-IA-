"""
Veritas BJ - Ingestion de la base de connaissances (RAG)
------------------------------------------------------------
Lit les documents de knowledge/benin/, les découpe en paragraphes, calcule un
vecteur (embedding) pour chacun via Ollama, et sauvegarde le tout dans un
index JSON simple. Pas de base vectorielle externe (FAISS, Chroma...) : pour
le volume de documents visé au démarrage (quelques dizaines), un index JSON
+ comparaison en Python pur est largement suffisant et évite une dépendance
supplémentaire (voir point 41 : pas de sur-ingénierie).

Format attendu d'un document source (voir knowledge/benin/*.md) :

    # Titre du document
    Source: https://url-de-la-source-officielle
    Consulté le: 2026-09-11

    Premier paragraphe...

    Deuxième paragraphe...

À lancer manuellement après avoir ajouté/modifié un document :

    python -m rag.ingest

Développé par AlphaDevs BJ 🦁
"""

import json
import os
import re
import sys

import config
from ai.local_provider import OllamaEmbedder

MAX_CHUNK_CHARS = 800  # taille cible d'un morceau de texte à indexer


def _parse_document(filepath):
    """Extrait titre, URL source, date de consultation, et corps du texte."""
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    lines = content.splitlines()
    title = lines[0].lstrip("#").strip() if lines and lines[0].startswith("#") else os.path.basename(filepath)

    source_match = re.search(r"^Source:\s*(.+)$", content, re.MULTILINE)
    source_url = source_match.group(1).strip() if source_match else None

    # Le corps commence après l'en-tête (titre + lignes "Source:"/"Consulté le:")
    body_lines = []
    past_header = False
    for line in lines:
        if not past_header:
            if line.strip() == "" and body_lines == []:
                continue
            if line.startswith("#") or line.startswith("Source:") or line.startswith("Consulté le:"):
                continue
            past_header = True
        body_lines.append(line)
    body = "\n".join(body_lines).strip()

    return {"title": title, "source_url": source_url, "body": body}


def chunk_text(text, max_chars=MAX_CHUNK_CHARS):
    """
    Découpage simple par paragraphes (séparés par une ligne vide), en
    fusionnant les petits paragraphes consécutifs jusqu'à la taille cible, et
    en coupant les paragraphes trop longs à une limite de phrase.
    """
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        if len(para) > max_chars:
            # Paragraphe trop long à lui seul : on le découpe phrase par phrase
            if current:
                chunks.append(current)
                current = ""
            sentences = re.split(r"(?<=[.!?])\s+", para)
            piece = ""
            for sentence in sentences:
                if len(piece) + len(sentence) > max_chars and piece:
                    chunks.append(piece.strip())
                    piece = sentence
                else:
                    piece = f"{piece} {sentence}".strip()
            if piece:
                current = piece
            continue

        if len(current) + len(para) + 1 <= max_chars:
            current = f"{current}\n{para}".strip()
        else:
            if current:
                chunks.append(current)
            current = para

    if current:
        chunks.append(current)

    return chunks


def build_index():
    embedder = OllamaEmbedder(
        endpoint=config.LOCAL_AI_ENDPOINT,
        model=config.EMBEDDING_MODEL,
        timeout=config.EMBEDDING_TIMEOUT,
    )

    if not embedder.is_available():
        print(
            f"❌ Le modèle d'embeddings '{config.EMBEDDING_MODEL}' n'est pas "
            f"disponible sur {config.LOCAL_AI_ENDPOINT}.\n"
            f"   Lance d'abord : ollama pull {config.EMBEDDING_MODEL}\n"
            f"   Voir AI_LOCAL.md pour l'installation complète."
        )
        return False

    if not os.path.isdir(config.KNOWLEDGE_DIR):
        print(f"❌ Dossier introuvable : {config.KNOWLEDGE_DIR}")
        return False

    filenames = sorted(f for f in os.listdir(config.KNOWLEDGE_DIR) if f.endswith((".md", ".txt")))
    if not filenames:
        print(f"⚠️  Aucun document trouvé dans {config.KNOWLEDGE_DIR} — index vide créé.")

    entries = []
    for filename in filenames:
        filepath = os.path.join(config.KNOWLEDGE_DIR, filename)
        doc = _parse_document(filepath)
        chunks = chunk_text(doc["body"])
        print(f"📄 {filename} : {len(chunks)} morceau(x)")

        for i, chunk in enumerate(chunks):
            vector = embedder.embed(chunk)
            if vector is None:
                print(f"   ⚠️  Échec d'embedding pour le morceau {i} de {filename}, ignoré.")
                continue
            entries.append({
                "id": f"{filename}#{i}",
                "source_file": filename,
                "title": doc["title"],
                "source_url": doc["source_url"],
                "text": chunk,
                "embedding": vector,
            })

    os.makedirs(os.path.dirname(config.KNOWLEDGE_INDEX_PATH) or ".", exist_ok=True)
    with open(config.KNOWLEDGE_INDEX_PATH, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False)

    print(f"✅ Index créé : {len(entries)} morceaux indexés dans {config.KNOWLEDGE_INDEX_PATH}")
    return True


if __name__ == "__main__":
    success = build_index()
    sys.exit(0 if success else 1)
