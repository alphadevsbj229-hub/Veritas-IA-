"""Veritas BJ - Base de connaissances Bénin (RAG : ingestion + recherche)."""
