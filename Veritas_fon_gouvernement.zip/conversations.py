"""
Veritas - Routes conversations
---------------------------------
Sauvegarde et récupération des conversations, liées à l'utilisateur
connecté (protégées par login_required).
"""

import json
from flask import request, jsonify
from sqlalchemy.exc import IntegrityError

from models import db, Conversation, Message
from auth import login_required


def register_conversation_routes(app):

    @app.route("/api/conversations", methods=["GET"])
    @login_required
    def list_conversations():
        user = request.current_user
        convs = (
            Conversation.query.filter_by(user_id=user.id)
            .order_by(Conversation.created_at.desc())
            .all()
        )
        return jsonify({"conversations": [c.to_dict() for c in convs]})

    @app.route("/api/conversations/<int:conv_id>", methods=["GET"])
    @login_required
    def get_conversation(conv_id):
        user = request.current_user
        conv = Conversation.query.filter_by(id=conv_id, user_id=user.id).first()
        if not conv:
            return jsonify({"error": "Conversation introuvable."}), 404
        return jsonify({"conversation": conv.to_dict(include_messages=True)})

    @app.route("/api/conversations", methods=["POST"])
    @login_required
    def create_conversation():
        user = request.current_user
        data = request.get_json(silent=True) or {}
        title = (data.get("title") or "Nouvelle discussion").strip()[:200]

        conv = Conversation(user_id=user.id, title=title)
        db.session.add(conv)
        db.session.commit()
        return jsonify({"conversation": conv.to_dict()}), 201

    @app.route("/api/conversations/<int:conv_id>", methods=["PATCH"])
    @login_required
    def update_conversation(conv_id):
        user = request.current_user
        conv = Conversation.query.filter_by(id=conv_id, user_id=user.id).first()
        if not conv:
            return jsonify({"error": "Conversation introuvable."}), 404

        data = request.get_json(silent=True) or {}
        if "title" in data:
            conv.title = (data["title"] or "").strip()[:200] or conv.title
        db.session.commit()
        return jsonify({"conversation": conv.to_dict()})

    @app.route("/api/conversations/<int:conv_id>", methods=["DELETE"])
    @login_required
    def delete_conversation(conv_id):
        user = request.current_user
        conv = Conversation.query.filter_by(id=conv_id, user_id=user.id).first()
        if not conv:
            return jsonify({"error": "Conversation introuvable."}), 404

        db.session.delete(conv)
        db.session.commit()
        return jsonify({"success": True})

    @app.route("/api/conversations/<int:conv_id>/messages", methods=["POST"])
    @login_required
    def add_message(conv_id):
        """Ajoute un message (user ou ai) à une conversation existante."""
        user = request.current_user
        conv = Conversation.query.filter_by(id=conv_id, user_id=user.id).first()
        if not conv:
            return jsonify({"error": "Conversation introuvable."}), 404

        data = request.get_json(silent=True) or {}
        role = data.get("role")
        text = (data.get("text") or "").strip()
        sources = data.get("sources") or []
        related_links = data.get("related_links") or []
        verified = bool(data.get("verified", False))
        verification_status = (data.get("verification_status") or "").strip()[:24] or None
        # UUID généré côté client (voir app.js) : permet de reconnaître un
        # renvoi du même message après un timeout, sans le dupliquer.
        client_message_id = (data.get("client_message_id") or "").strip()[:64] or None

        if role not in ("user", "ai"):
            return jsonify({"error": "Le champ 'role' doit être 'user' ou 'ai'."}), 400
        if not text:
            return jsonify({"error": "Le message est vide."}), 400

        # Idempotence : si ce message (même conversation + même client_message_id)
        # existe déjà, on renvoie l'existant tel quel plutôt que d'en recréer un.
        if client_message_id:
            existing = Message.query.filter_by(
                conversation_id=conv.id, client_message_id=client_message_id
            ).first()
            if existing:
                return jsonify({"message": existing.to_dict()}), 200

        msg = Message(
            conversation_id=conv.id,
            role=role,
            text=text,
            sources_json=json.dumps(sources),
            related_links_json=json.dumps(related_links),
            verified=verified,
            verification_status=verification_status,
            client_message_id=client_message_id,
        )
        db.session.add(msg)

        # Si c'est le tout premier message utilisateur, on s'en sert comme titre
        if role == "user" and len(conv.messages) == 0:
            conv.title = text[:40] + ("…" if len(text) > 40 else "")

        try:
            db.session.commit()
        except IntegrityError:
            # Filet de sécurité en cas de double envoi quasi simultané (deux
            # requêtes en vol en même temps) : la contrainte d'unicité a bloqué
            # l'insertion concurrente, on renvoie le message déjà inséré par
            # l'autre requête plutôt que de renvoyer une erreur au client.
            db.session.rollback()
            existing = Message.query.filter_by(
                conversation_id=conv.id, client_message_id=client_message_id
            ).first()
            if existing:
                return jsonify({"message": existing.to_dict()}), 200
            return jsonify({"error": "Impossible d'enregistrer le message."}), 409

        return jsonify({"message": msg.to_dict()}), 201
