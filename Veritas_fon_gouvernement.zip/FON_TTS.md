# Veritas BJ — Audio en Fon (chantier en cours)

*Développé par AlphaDevs BJ 🦁*

## Objectif

Faire en sorte que Veritas puisse **parler en Fon (fɔ̀ngbè)**, pour que les
personnes qui ne lisent pas le français puissent quand même utiliser
l'appli. C'est la première brique d'un chantier plus large (écouter le Fon
en entrée viendra dans une étape suivante).

## Deux façons d'obtenir l'audio — laquelle utiliser

**Priorité 1, recommandée : un vrai enregistrement humain.**
Un(e) locuteur(trice) Fon enregistre les phrases avec `tools/fon_recorder.html`
(page autonome, ouvre-la simplement dans un navigateur — aucune installation,
aucune dépendance). C'est fiable dès le premier jour : pas de traduction
automatique, pas de modèle IA à faire confiance.

**Priorité 2, repli optionnel : synthèse IA** (`ai/tts_fon_provider.py`,
modèle Meta MMS-TTS). Utile seulement si aucun enregistrement humain n'existe
pour une phrase — voir la section dédiée plus bas. Nécessite d'installer
`transformers`/`torch`/`scipy` et une vraie traduction Fon écrite au
préalable (le module ne traduit pas, il lit seulement du texte déjà en Fon).

Dans les deux cas, **`"validated": true` dans `fon_phrases.json` est
obligatoire** avant que `/api/tts` serve quoi que ce soit — c'est la
confirmation qu'un humain qui parle Fon a vérifié le contenu.

## Étapes pour rendre une phrase 100% prête (voie recommandée)

1. Ouvre `tools/fon_recorder.html` dans un navigateur (double-clic sur le
   fichier suffit).
2. Fais lire chaque phrase FR à voix haute, EN FON, par quelqu'un qui parle
   la langue.
3. Enregistre, écoute pour vérifier, télécharge (le nom de fichier est déjà
   le bon, ex. `identity.webm`).
4. Place le fichier dans `knowledge/benin/audio_fon/`.
5. Dans `knowledge/benin/fon_phrases.json`, passe `"validated"` à `true`
   pour cette clé.
6. Recharge l'appli — le bouton "🔊 Fon" joue maintenant le vrai
   enregistrement, sans aucune dépendance supplémentaire à installer.

## Ce qui est fait

- `tools/fon_recorder.html` — enregistreur autonome (micro du navigateur),
  aucune dépendance, aucune connexion réseau nécessaire.
- Route `POST /api/tts` (`app.py`) — sert en priorité le vrai fichier audio
  s'il existe et est validé ; sinon retombe sur la synthèse IA si activée ;
  sinon renvoie une erreur claire.
- `knowledge/benin/fon_phrases.json` — banque de 3 phrases avec un champ
  `audio_file` pointant vers l'enregistrement attendu.
- Bouton "🔊 Fon" côté frontend (`app.js`/`style.css`), sous la réponse
  "qui es-tu ?" pour l'instant.
- `ai/tts_fon_provider.py` — intégration du modèle Meta MMS-TTS pour le Fon,
  en repli optionnel (voir plus bas).

## Ce qui n'est PAS fait (honnêteté jusqu'au bout)

- **Aucun fichier audio n'est encore enregistré** — les 3 entrées de
  `fon_phrases.json` ont `"validated": false` et pointent vers des fichiers
  qui n'existent pas encore dans `knowledge/benin/audio_fon/`. Tant que ce
  n'est pas fait, `/api/tts` répond une erreur claire, il ne renvoie jamais
  un son deviné.
- Seule la réponse d'identité ("qui es-tu ?") a une clé Fon câblée côté
  frontend pour l'instant. Étendre à d'autres réponses fixes (salutation,
  aucun résultat) est immédiat une fois les 3 phrases enregistrées ; étendre
  aux réponses de recherche libre demanderait de résoudre la traduction
  FR↔Fon — un chantier à part.
- **Testé uniquement dans son fonctionnement logique ici** (le code
  s'exécute, les routes répondent les bonnes erreurs) — pas avec un vrai
  micro ni un vrai locuteur Fon, ce qui reste à faire chez toi.

## Le "dictionnaire Fon" demandé — ce qui existe réellement

J'ai cherché : il n'existe pas de dictionnaire FR↔Fon numérique fiable et
gratuit que je puisse simplement brancher tel quel. En revanche, deux
briques de recherche sérieuses et réutilisables existent :

- **NLLB-200** (Meta, open-source) : modèle de traduction couvrant 200
  langues, DONT le Fon (code `fon_Latn`), évalué sur un vrai jeu de test
  (FLORES-200). C'est la base la plus crédible disponible aujourd'hui pour
  une traduction FR→Fon automatique. Intégrée ici dans
  `ai/translate_fon_provider.py`, avec le plus petit modèle
  (`nllb-200-distilled-600M`, ~2,4 Go) pour rester utilisable sans GPU.
- Un modèle de reconnaissance vocale Fon spécialisé existe aussi sur
  Hugging Face (`whettenr/asr-fon-with-diacritics-bpe-256`, avec gestion
  des tons) — utile pour une future étape "écouter le Fon", pas encore
  intégré ici.

**Honnêteté sur ces deux briques :**
- Meta documente NLLB-200 explicitement comme "a research model... not
  released for production deployment". Sur une langue aussi peu dotée que
  le Fon, la qualité phrase par phrase n'est pas garantie.
- Licence CC-BY-NC 4.0 (comme mms-tts-fon) — non commercial.
- Un projet similaire (fine-tune NLLB pour une autre langue peu dotée)
  précise lui-même : "Outputs have not been validated by human speakers."
  C'est exactement notre situation ici aussi.

**Conséquence concrète dans le code :** ce chemin de traduction automatique
est câblé comme un mode **séparé et explicitement non vérifié**
(`AUTO_TRANSLATE_FON_ENABLED`, désactivé par défaut) : le bouton
correspondant côté appli est visuellement différent ("🔊 Fon (auto, ⚠️ non
vérifié)") et ne remplace jamais un enregistrement humain validé. Ne pas
l'utiliser pour du contenu administratif sans relecture humaine.

## Repli optionnel : synthèse IA (Meta MMS-TTS)

Si tu veux quand même explorer la synthèse IA en complément (par exemple
pour du contenu qui change trop souvent pour être enregistré à la main) :

```bash
pip install -r requirements-fon.txt
# Pour rester léger (pas de GPU nécessaire), installe torch en CPU avant :
# pip install torch --index-url https://download.pytorch.org/whl/cpu
# pip install -r requirements-fon.txt
```

```bash
# Windows PowerShell
$env:TTS_ENABLED = "1"
python app.py
```

Le modèle (`facebook/mms-tts-fon`, ~150 Mo) se télécharge automatiquement au
premier appel, puis reste en cache. **Licence CC-BY-NC 4.0** (usage non
commercial) — à revoir si Veritas BJ devient un jour un produit commercial.
Rappel : ce module ne traduit pas le français, il faut lui fournir du texte
déjà en Fon dans le champ `"fon"` de `fon_phrases.json`.

## Activer la traduction automatique (expérimental)

```bash
pip install -r requirements-fon.txt
```

```bash
# Windows PowerShell
$env:AUTO_TRANSLATE_FON_ENABLED = "1"
$env:TTS_ENABLED = "1"   # nécessaire aussi, pour la synthèse après traduction
python app.py
```

Le modèle NLLB (~2,4 Go) et le modèle TTS (~150 Mo) se téléchargent au
premier appel, puis restent en cache.

## Écoute du Fon (reconnaissance vocale en entrée)

**Ce qui est fait :**
- `ai/asr_fon_provider.py` — intègre `whettenr/asr-fon-with-diacritics`
  (SpeechBrain, conformer ~100M paramètres, **licence Apache 2.0** — plus
  permissive que MMS-TTS/NLLB, pas de restriction non-commerciale).
- Route `POST /api/stt` (`app.py`) — reçoit un enregistrement audio,
  transcrit en Fon, puis (si `AUTO_TRANSLATE_FON_ENABLED=1`) traduit en
  français via `ai/translate_fon_provider.py` (nouvelle fonction
  `translate_fon_to_fr`, sens inverse de celle déjà utilisée pour le TTS).
- Bouton micro 🎙️ dans la zone de saisie (`index.html`/`app.js`) : enregistre,
  envoie à `/api/stt`, **remplit le champ texte avec le résultat sans jamais
  envoyer automatiquement** — la personne doit relire/corriger puis cliquer
  elle-même sur envoyer.

**Honnêteté sur ce qui reste :**
- C'est le modèle **de base** publié par son auteur. Des démos publiques
  existent avec une version affinée non publiée atteignant ~18-19% de taux
  d'erreur en cross-corpus — un ordre de grandeur de ce qui est atteignable,
  PAS une garantie pour notre modèle de base tel quel.
- **Deux sources d'erreur s'additionnent** dans le mode "traduit en
  français" : l'erreur de reconnaissance vocale + l'erreur de traduction
  NLLB. C'est pour ça que le brouillon est toujours montré (Fon entendu +
  traduction) avant envoi, jamais envoyé directement.
- Nécessite `ffmpeg` installé sur le système (au-delà des paquets Python)
  pour convertir l'audio du navigateur (souvent `.webm`) en `.wav` — c'est
  le point le plus susceptible de bloquer selon la machine, d'où l'erreur
  explicite renvoyée par `/api/stt` si la conversion échoue.
- **Rien de tout ça n'a été testé avec un vrai micro ni un vrai locuteur
  Fon** — pas d'accès réseau ni de micro dans mon environnement. Le code
  suit l'usage documenté officiellement du modèle, mais le premier vrai
  test reste à faire chez toi.

Installation :
```bash
pip install -r requirements-fon.txt
# + installer ffmpeg sur le système et l'ajouter au PATH
```
```bash
# Windows PowerShell
$env:STT_ENABLED = "1"
$env:AUTO_TRANSLATE_FON_ENABLED = "1"   # pour obtenir aussi la traduction FR
python app.py
```

## Prochaines étapes possibles

1. Enregistrer et valider les 3 phrases actuelles (identité, salutation,
   message "aucun résultat").
2. Étendre la banque de phrases enregistrées aux questions administratives
   les plus fréquentes (passeport, CNSS, état civil...) — même logique
   "peu de phrases fiables" que la liste des 21 sites officiels béninois.
3. Tester l'écoute du Fon (STT) avec un vrai micro et un vrai locuteur,
   évaluer le taux d'erreur réel sur des questions courantes.
4. Traduction automatique FR↔Fon pour les réponses libres — le point le
   plus risqué : la qualité disponible aujourd'hui pour le Fon reste limitée,
   à ne pas déployer sans relecture humaine sur du contenu administratif.

