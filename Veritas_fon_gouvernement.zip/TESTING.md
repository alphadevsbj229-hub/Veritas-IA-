# TESTING.md — Lancer les tests de Veritas BJ

## Installation

```powershell
pip install -r requirements-dev.txt
```

## Lancer toute la suite

```powershell
pytest
```

## Lancer un seul fichier de tests

```powershell
pytest tests/test_calculator.py -v
```

## Ce que couvre chaque fichier

| Fichier | Ce qu'il vérifie |
|---|---|
| `test_calculator.py` | Calculs valides, questions non-calculables, **sécurité** (injection de code bloquée) |
| `test_orchestrator.py` | Détection d'intention sur les exemples exacts du cahier des charges |
| `test_security_ssrf.py` | Blocage des URLs internes/dangereuses (métadonnées cloud, IP privées...) |
| `test_rag.py` | Découpage de documents, similarité, ingestion/recherche de la base de connaissances Bénin |
| `test_verification.py` | Détection de contradictions chiffrées entre sources |
| `test_ai_providers.py` | Ollama et Gemini : disponibilité, génération, repli propre en cas d'échec, sécurité de la clé API |
| `test_auth.py` | Inscription, connexion, validation du mot de passe, **déconnexion avec révocation réelle**, connexion Google |
| `test_conversations.py` | Création/lecture/suppression, **isolation entre utilisateurs** (un utilisateur ne peut jamais voir les conversations d'un autre), idempotence des messages |
| `test_ask_route.py` | Routage de l'orchestrateur sur l'API réelle (`/api/ask`), résolution de contexte conversationnel |
| `test_documents.py` | Analyse de documents PDF/DOCX/TXT : extraction réelle (pypdf/reportlab), résumé multi-morceaux (map-reduce), questions/réponses par similarité, sécurité (taille, format) |

## Comment ces tests fonctionnent

- `tests/conftest.py` configure une base de données de test **isolée** (jamais `veritas.db`, ta vraie base de développement) et un endpoint IA local volontairement injoignable par défaut — les tests sont donc reproductibles, peu importe si Ollama tourne ou non sur ta machine au moment du test.
- Les appels réseau externes (Ollama, Gemini, DuckDuckGo, Wikipédia...) sont **simulés** (`monkeypatch`) dans les tests — la suite ne dépend jamais d'un vrai accès internet pour passer, et ne fait jamais de vrai appel payant à Gemini.
- Chaque test de base de données nettoie ses données à la fin (fixture `_clean_db`), donc l'ordre d'exécution des tests n'a pas d'importance.

## Important : transparence sur ce qui a été vérifié

Cette suite a été écrite avec le plus grand soin et correspond exactement à
la logique déjà validée manuellement pendant le développement (calculatrice,
orchestrateur, protection SSRF, détection de contradictions, base de
connaissances). **Cependant**, l'environnement où ce projet a été développé
n'avait pas accès à internet pour installer `pytest` et les dépendances
complètes (`flask-sqlalchemy`, `bcrypt`, etc.) — la suite n'a donc pas pu
être exécutée avec la commande `pytest` elle-même avant de te la livrer.

**Ce qu'il te reste à faire** : lance `pytest` une première fois chez toi.
Si un test échoue, envoie-moi le message d'erreur exact et je corrige
immédiatement — c'est le seul moyen d'avoir une confirmation à 100%.

## Ajouter un nouveau test

Un fichier `tests/test_xxx.py` avec des fonctions `def test_xxx():` est
automatiquement détecté par pytest. Utilise les fixtures `client` (client
HTTP de test) et `register_user` (crée un utilisateur de test et renvoie ses
headers d'authentification) pour les tests qui touchent à l'API.
