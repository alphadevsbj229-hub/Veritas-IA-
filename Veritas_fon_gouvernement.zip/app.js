// ===========================================================================
// Veritas - Frontend logic
// ===========================================================================

// Adresse du backend Flask. Change-la si tu déploies le serveur ailleurs
// que sur ta machine locale (ex: "https://ton-serveur.com").
const API_BASE = "http://localhost:5000";

// Identifiant client OAuth Google (voir README pour la procédure de création
// dans Google Cloud Console). Laisse vide pour désactiver "Se connecter avec
// Google" — le formulaire email/mot de passe continue de fonctionner seul.
const GOOGLE_CLIENT_ID = "";

const STORAGE_KEYS = {
  token: "veritas_token",
  user: "veritas_user",
  theme: "veritas_theme",
};

let state = {
  token: null,
  user: null,          // {id, email, username, avatar_url}
  conversations: [],    // liste résumée [{id, title, created_at}]
  activeId: null,
  activeMessages: [],   // messages de la conversation actuellement ouverte
  trendingTopic: null,  // sujet le plus populaire du jour, en attente d'une relance de l'utilisateur
};

// ---------------------------------------------------------------------------
// Helpers réseau
// ---------------------------------------------------------------------------

async function api(path, { method = "GET", body = null, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth && state.token) headers["Authorization"] = `Bearer ${state.token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });

  let data = null;
  try { data = await res.json(); } catch (_) { /* réponse vide */ }

  if (!res.ok) {
    const message = (data && data.error) || `Erreur serveur (${res.status})`;
    throw new Error(message);
  }
  return data;
}

// ---------------------------------------------------------------------------
// Sauvegarde résiliente (file d'attente + retry automatique)
// ---------------------------------------------------------------------------
// Le backend gratuit (Render) peut mettre 30-50s à se réveiller après une
// période d'inactivité, ou une coupure réseau peut survenir. Plutôt que de
// perdre un message, on le met en file d'attente locale et on retente
// automatiquement jusqu'à ce qu'il soit confirmé sauvegardé — comme le fait
// Claude ou ChatGPT côté serveur.

// Identifiant unique pour chaque message envoyé, utilisé par le serveur pour
// détecter un renvoi (retry) du même message et éviter les doublons.
function generateClientId() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }
  // Repli pour les contextes sans crypto.randomUUID (ex. http:// non-localhost)
  return `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}

const SAVE_QUEUE_KEY = "veritas_save_queue";
let saveQueueRunning = false;

function loadSaveQueue() {
  try {
    return JSON.parse(localStorage.getItem(SAVE_QUEUE_KEY) || "[]");
  } catch (_) {
    return [];
  }
}

function persistSaveQueue(queue) {
  localStorage.setItem(SAVE_QUEUE_KEY, JSON.stringify(queue));
}

function enqueueSave(path, body) {
  const queue = loadSaveQueue();
  queue.push({ id: `${Date.now()}_${Math.random().toString(36).slice(2)}`, path, body, attempts: 0 });
  persistSaveQueue(queue);
  updateSyncIndicator();
  processSaveQueue();
}

async function processSaveQueue() {
  if (saveQueueRunning) return;
  saveQueueRunning = true;

  let queue = loadSaveQueue();
  while (queue.length > 0) {
    const item = queue[0];
    try {
      await api(item.path, { method: "POST", body: item.body });
      queue.shift(); // succès, on retire de la file
      persistSaveQueue(queue);
      updateSyncIndicator();
    } catch (err) {
      item.attempts += 1;
      persistSaveQueue(queue);
      updateSyncIndicator();
      // Backoff progressif : 2s, 4s, 8s... plafonné à 30s
      const delay = Math.min(2000 * Math.pow(2, item.attempts - 1), 30000);
      await new Promise(r => setTimeout(r, delay));
      queue = loadSaveQueue(); // recharge au cas où d'autres items ont été ajoutés
    }
  }

  saveQueueRunning = false;
}

function updateSyncIndicator() {
  const el = document.getElementById("sync-indicator");
  if (!el) return;
  const pending = loadSaveQueue().length;
  if (pending === 0) {
    el.textContent = "✓ Sauvegardé";
    el.classList.remove("syncing");
  } else {
    el.textContent = `⟳ Sauvegarde en cours… (${pending})`;
    el.classList.add("syncing");
  }
}

// ---------------------------------------------------------------------------
// Thème clair / sombre
// ---------------------------------------------------------------------------
// Le thème est déjà appliqué avant le chargement de ce script (voir le script
// inline dans <head> de index.html, pour éviter un flash) ; ici on gère juste
// le changement en cours d'utilisation et la synchronisation des boutons.

function getTheme() {
  return document.documentElement.getAttribute("data-theme") || "dark";
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(STORAGE_KEYS.theme, theme);
  const label = theme === "dark" ? "🌙 Mode sombre" : "☀️ Mode clair";
  const shortLabel = theme === "dark" ? "🌙" : "☀️";
  const mainBtn = document.getElementById("theme-toggle-btn");
  const onboardingBtn = document.getElementById("theme-toggle-btn-onboarding");
  if (mainBtn) mainBtn.textContent = label;
  if (onboardingBtn) onboardingBtn.textContent = shortLabel;
}

function toggleTheme() {
  applyTheme(getTheme() === "dark" ? "light" : "dark");
}

function initTheme() {
  applyTheme(getTheme()); // synchronise juste le libellé des boutons au départ
  document.getElementById("theme-toggle-btn-onboarding")?.addEventListener("click", toggleTheme);
  document.getElementById("theme-toggle-btn")?.addEventListener("click", toggleTheme);
}

// ---------------------------------------------------------------------------
// Connexion avec Google (Google Identity Services)
// ---------------------------------------------------------------------------

function initGoogleSignIn() {
  const container = document.getElementById("google-signin-container");
  if (!GOOGLE_CLIENT_ID || !container) {
    if (container) container.style.display = "none";
    const divider = document.querySelector(".auth-divider");
    if (divider) divider.style.display = "none";
    return;
  }

  function render() {
    if (!window.google || !window.google.accounts) {
      setTimeout(render, 200); // le script Google peut charger après ce script
      return;
    }
    window.google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: handleGoogleCredential,
    });
    window.google.accounts.id.renderButton(container, {
      theme: getTheme() === "dark" ? "filled_black" : "outline",
      size: "large",
      width: 300,
      text: "continue_with",
      locale: "fr",
    });
  }
  render();
}

async function handleGoogleCredential(response) {
  const loginError = document.getElementById("login-error");
  try {
    const data = await api("/api/auth/google", {
      method: "POST",
      body: { credential: response.credential },
      auth: false,
    });
    state.token = data.token;
    state.user = data.user;
    saveSession();
    document.getElementById("onboarding").style.display = "none";
    await startApp();
  } catch (err) {
    if (loginError) loginError.textContent = err.message;
  }
}



// ---------------------------------------------------------------------------
// Persistance de session locale (juste le token, pas de données sensibles)
// ---------------------------------------------------------------------------

function saveSession() {
  localStorage.setItem(STORAGE_KEYS.token, state.token || "");
  localStorage.setItem(STORAGE_KEYS.user, JSON.stringify(state.user || null));
}

function loadSession() {
  state.token = localStorage.getItem(STORAGE_KEYS.token) || null;
  const rawUser = localStorage.getItem(STORAGE_KEYS.user);
  state.user = rawUser ? JSON.parse(rawUser) : null;
}

function clearSession() {
  localStorage.removeItem(STORAGE_KEYS.token);
  localStorage.removeItem(STORAGE_KEYS.user);
  state.token = null;
  state.user = null;
}

// ---------------------------------------------------------------------------
// Authentification
// ---------------------------------------------------------------------------

function initAuth() {
  loadSession();

  const onboarding = document.getElementById("onboarding");
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const forgotForm = document.getElementById("forgot-form");
  const resetForm = document.getElementById("reset-form");
  const loginError = document.getElementById("login-error");
  const registerError = document.getElementById("register-error");
  const forgotError = document.getElementById("forgot-error");
  const forgotSuccess = document.getElementById("forgot-success");
  const resetError = document.getElementById("reset-error");

  function showOnly(form) {
    [loginForm, registerForm, forgotForm, resetForm].forEach(f => {
      f.style.display = f === form ? "block" : "none";
    });
  }

  document.getElementById("show-register").addEventListener("click", (e) => {
    e.preventDefault();
    showOnly(registerForm);
  });
  document.getElementById("show-login").addEventListener("click", (e) => {
    e.preventDefault();
    showOnly(loginForm);
  });
  document.getElementById("show-forgot").addEventListener("click", (e) => {
    e.preventDefault();
    forgotSuccess.textContent = "";
    forgotError.textContent = "";
    showOnly(forgotForm);
  });
  document.getElementById("show-login-from-forgot").addEventListener("click", (e) => {
    e.preventDefault();
    showOnly(loginForm);
  });

  // Lien reçu par email : https://.../?reset_token=xxxxx -> affiche
  // directement le formulaire de choix du nouveau mot de passe.
  const urlParams = new URLSearchParams(window.location.search);
  const resetTokenFromUrl = urlParams.get("reset_token");
  if (resetTokenFromUrl) {
    showOnly(resetForm);
  }

  forgotForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    forgotError.textContent = "";
    forgotSuccess.textContent = "";
    const email = document.getElementById("forgot-email").value.trim();
    const btn = forgotForm.querySelector("button[type=submit]");
    btn.disabled = true;
    try {
      const data = await api("/api/auth/forgot-password", { method: "POST", body: { email }, auth: false });
      forgotSuccess.textContent = data.message;
    } catch (err) {
      forgotError.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  resetForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    resetError.textContent = "";
    const password = document.getElementById("reset-password").value;
    const btn = resetForm.querySelector("button[type=submit]");
    btn.disabled = true;
    try {
      await api("/api/auth/reset-password", {
        method: "POST", body: { token: resetTokenFromUrl, password }, auth: false,
      });
      // Nettoie l'URL (retire le jeton) et repart sur l'écran de connexion
      window.history.replaceState({}, "", window.location.pathname);
      showOnly(loginForm);
      loginError.textContent = "";
      forgotSuccess.textContent = "";
    } catch (err) {
      resetError.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    loginError.textContent = "";
    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-password").value;
    const btn = loginForm.querySelector("button[type=submit]");
    btn.disabled = true;

    try {
      const data = await api("/api/auth/login", {
        method: "POST",
        body: { email, password },
        auth: false,
      });
      state.token = data.token;
      state.user = data.user;
      saveSession();
      onboarding.style.display = "none";
      await startApp();
    } catch (err) {
      loginError.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    registerError.textContent = "";
    const username = document.getElementById("register-username").value.trim();
    const email = document.getElementById("register-email").value.trim();
    const password = document.getElementById("register-password").value;
    const btn = registerForm.querySelector("button[type=submit]");
    btn.disabled = true;

    try {
      const data = await api("/api/auth/register", {
        method: "POST",
        body: { username, email, password },
        auth: false,
      });
      state.token = data.token;
      state.user = data.user;
      saveSession();
      onboarding.style.display = "none";
      await startApp();
    } catch (err) {
      registerError.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  // Session déjà active ?
  if (state.token && state.user) {
    onboarding.style.display = "none";
    startApp().catch(() => {
      // Token invalide/expiré -> retour à l'écran de connexion
      clearSession();
      onboarding.style.display = "flex";
    });
  }
}

async function logout() {
  // Révocation côté serveur (point 26) : le token ne doit plus être
  // utilisable nulle part après une déconnexion explicite, pas seulement
  // supprimé du navigateur local. On n'attend pas indéfiniment ni ne bloque
  // la déconnexion locale si le serveur est injoignable (ex. hors ligne) —
  // l'utilisateur doit toujours pouvoir se déconnecter localement.
  try {
    await api("/api/auth/logout", { method: "POST" });
  } catch (err) {
    // Serveur injoignable ou token déjà expiré : pas grave, on nettoie quand
    // même la session locale ci-dessous.
  }

  clearSession();
  state.trendingTopic = null;
  document.getElementById("app").style.display = "none";
  document.getElementById("onboarding").style.display = "flex";
  document.getElementById("login-form").style.display = "block";
  document.getElementById("register-form").style.display = "none";
  document.getElementById("forgot-form").style.display = "none";
  document.getElementById("reset-form").style.display = "none";
  document.getElementById("login-email").value = "";
  document.getElementById("login-password").value = "";
}

// ---------------------------------------------------------------------------
// Démarrage de l'application (après connexion réussie)
// ---------------------------------------------------------------------------

async function startApp() {
  document.getElementById("app").style.display = "flex";
  document.getElementById("sidebar-username").textContent = state.user.username;

  const avatarImg = document.getElementById("sidebar-avatar");
  const avatarFallback = document.getElementById("sidebar-avatar-fallback");
  if (state.user.avatar_url) {
    avatarImg.src = state.user.avatar_url;
    avatarImg.style.display = "block";
    avatarFallback.style.display = "none";
  } else {
    avatarFallback.textContent = (state.user.username || "?").trim().charAt(0).toUpperCase();
    avatarFallback.style.display = "flex";
    avatarImg.style.display = "none";
  }

  bindUIEvents();
  loadDailyBriefing();
  updateSyncIndicator();
  processSaveQueue(); // reprend les sauvegardes qui étaient en attente
  await refreshConversationList();

  if (state.conversations.length > 0) {
    await openConversation(state.conversations[0].id);
  } else {
    showWelcome(true);
  }
}

// ---------------------------------------------------------------------------
// Fait / briefing du jour
// ---------------------------------------------------------------------------

async function loadDailyBriefing() {
  const title = document.getElementById("welcome-title");
  const factEl = document.getElementById("daily-fact");
  title.textContent = `Bonjour ${state.user.username}`;

  try {
    const data = await api(
      `/api/daily-briefing?username=${encodeURIComponent(state.user.username)}`,
      { auth: false }
    );
    factEl.textContent = data.message;
    // Mémorisé pour reconnaître une relance de l'utilisateur ("oui", "dis m'en
    // plus"...) sur son tout premier message et lui donner directement la
    // réponse complète avec sources, plutôt que de relancer une recherche à
    // partir de sa phrase de relance (qui, seule, ne veut rien dire).
    state.trendingTopic = data.trending_topic || null;
  } catch (err) {
    factEl.textContent = "Impossible de contacter le serveur Veritas. Vérifie qu'il est bien lancé (python app.py).";
  }
}

// ---------------------------------------------------------------------------
// Gestion des conversations (sauvegardées côté serveur)
// ---------------------------------------------------------------------------

async function refreshConversationList() {
  try {
    const data = await api("/api/conversations");
    state.conversations = data.conversations;
    renderConversationList();
  } catch (err) {
    console.error("Impossible de charger les conversations :", err.message);
  }
}

async function createConversation() {
  const data = await api("/api/conversations", {
    method: "POST",
    body: { title: "Nouvelle discussion" },
  });
  state.conversations.unshift(data.conversation);
  state.activeId = data.conversation.id;
  state.activeMessages = [];
  renderConversationList();
  renderMessages();
  showWelcome(true);
}

async function openConversation(id) {
  state.activeId = id;
  try {
    const data = await api(`/api/conversations/${id}`);
    state.activeMessages = data.conversation.messages;
  } catch (err) {
    state.activeMessages = [];
  }
  renderConversationList();
  renderMessages();
  showWelcome(state.activeMessages.length === 0);
}

function renderConversationList() {
  const list = document.getElementById("conversation-list");
  list.innerHTML = "";
  state.conversations.forEach(conv => {
    const item = document.createElement("div");
    item.className = "conversation-item" + (conv.id === state.activeId ? " active" : "");
    item.textContent = conv.title;
    item.addEventListener("click", () => {
      openConversation(conv.id);
      closeMobileSidebar();
    });
    list.appendChild(item);
  });
}

function showWelcome(show) {
  document.getElementById("welcome-screen").style.display = show ? "block" : "none";
}

// ---------------------------------------------------------------------------
// Affichage des messages
// ---------------------------------------------------------------------------

function renderMessages() {
  const container = document.getElementById("messages");
  container.innerHTML = "";
  state.activeMessages.forEach(msg => container.appendChild(buildMessageEl(msg)));
  scrollToBottom();
}

function buildMessageEl(msg) {
  const wrapper = document.createElement("div");
  wrapper.className = `msg ${msg.role}`;

  if (msg.role === "ai") {
    const avatar = document.createElement("div");
    avatar.className = "msg-avatar";
    avatar.textContent = "V";
    wrapper.appendChild(avatar);
  }

  const bubble = document.createElement("div");
  bubble.className = "msg-bubble";

  // Transparence (point 34) : si la question a été reformulée grâce au
  // contexte de la conversation ("il" -> "Patrice Talon"), on le montre
  // discrètement plutôt que de le cacher.
  if (msg.role === "ai" && msg.resolved_query) {
    const note = document.createElement("div");
    note.className = "resolved-query-note";
    note.textContent = `Compris comme : « ${msg.resolved_query} »`;
    bubble.appendChild(note);
  }

  const textEl = document.createElement("div");
  textEl.textContent = msg.text;
  bubble.appendChild(textEl);

  // Écoute en Fon (accessibilité — voir FON_TTS.md). N'apparaît que si le
  // backend a indiqué une clé de la banque de phrases ; le bouton lui-même
  // gère le cas où le serveur répond que le TTS est désactivé ou que la
  // phrase n'est pas encore validée par un locuteur natif.
  if (msg.role === "ai" && msg.tts_phrase_key) {
    const fonBtn = document.createElement("button");
    fonBtn.className = "fon-tts-btn";
    fonBtn.type = "button";
    fonBtn.textContent = "🔊 Fon";
    fonBtn.title = "Enregistrement humain validé";
    fonBtn.addEventListener("click", () => playFonAudio({ phrase_key: msg.tts_phrase_key }, fonBtn));
    bubble.appendChild(fonBtn);
  }

  // Traduction automatique expérimentale (NLLB) — disponible pour
  // n'importe quelle réponse, mais TOUJOURS visuellement distincte et
  // étiquetée comme non vérifiée (voir FON_TTS.md). Ne remplace jamais le
  // bouton ci-dessus quand une phrase validée existe déjà.
  if (msg.role === "ai" && msg.text) {
    const autoFonBtn = document.createElement("button");
    autoFonBtn.className = "fon-tts-btn fon-tts-btn-auto";
    autoFonBtn.type = "button";
    autoFonBtn.textContent = "🔊 Fon (auto, ⚠️ non vérifié)";
    autoFonBtn.title = "Traduction automatique non relue par un locuteur Fon — peut contenir des erreurs";
    autoFonBtn.addEventListener("click", () => playFonAudio({ text: msg.text, auto_translate: true }, autoFonBtn));
    bubble.appendChild(autoFonBtn);
  }

  if (msg.role === "ai" && msg.sources && msg.sources.length > 0) {
    if (msg.verification_status === "CONTRADICTED") {
      const tag = document.createElement("div");
      tag.className = "contradiction-tag";
      tag.textContent = "⚠️ Sources contradictoires — vérifie toi-même";
      bubble.appendChild(tag);
    } else if (msg.verified) {
      const tag = document.createElement("div");
      tag.className = "verified-tag";
      tag.textContent = `✓ Vérifié sur ${msg.sources.length} sources`;
      bubble.appendChild(tag);
    }
    const sourcesEl = document.createElement("div");
    sourcesEl.className = "msg-sources";
    msg.sources.forEach(s => {
      const chip = document.createElement("a");
      chip.className = "source-chip";
      chip.href = s.url;
      chip.target = "_blank";
      chip.rel = "noopener noreferrer";
      chip.textContent = `${s.source}`;
      sourcesEl.appendChild(chip);
    });
    bubble.appendChild(sourcesEl);
  }

  if (msg.role === "ai" && msg.related_links && msg.related_links.length > 0) {
    const relatedTitle = document.createElement("div");
    relatedTitle.className = "related-title";
    relatedTitle.textContent = "Pour aller plus loin :";
    bubble.appendChild(relatedTitle);

    const relatedEl = document.createElement("div");
    relatedEl.className = "msg-related";
    msg.related_links.forEach(link => {
      const a = document.createElement("a");
      a.className = "related-chip";
      a.href = link.url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = link.label;
      relatedEl.appendChild(a);
    });
    bubble.appendChild(relatedEl);
  }

  wrapper.appendChild(bubble);
  return wrapper;
}

function scrollToBottom() {
  const area = document.getElementById("chat-area");
  area.scrollTop = area.scrollHeight;
}

// ---------------------------------------------------------------------------
// Envoi d'une question
// ---------------------------------------------------------------------------

// Phrases courtes typiques d'une relance après "Tu veux que je t'en dise
// plus ?" — si l'utilisateur répond ça juste après le message d'accueil, on
// lui donne directement l'info complète sur le sujet du jour plutôt que de
// chercher sa phrase de relance mot pour mot (qui, seule, ne veut rien dire).
const TRENDING_FOLLOWUP_RE = /^(oui|ouais|ouep|yes|ok|okay|d'accord|vas[- ]?y|raconte|dis[- ]?(moi|m'en plus)?|en savoir plus|plus d'infos?|c'est quoi|de quoi s'agit[- ]?il|explique|pourquoi|comment ça|ça m'intéresse|je veux (bien )?savoir|tell me more|quoi)\s*[!.?]*$/i;

function isTrendingFollowUp(text) {
  if (!state.trendingTopic) return false;
  const normalized = text.trim();
  if (TRENDING_FOLLOWUP_RE.test(normalized)) return true;
  // L'utilisateur a directement mentionné le sujet du jour dans sa question
  return normalized.toLowerCase().includes(state.trendingTopic.toLowerCase());
}

// ---------------------------------------------------------------------------
// Analyse de documents (point 24) — PDF/DOCX/TXT, résumé via le moteur IA
// ---------------------------------------------------------------------------

async function analyzeDocument(file) {
  if (!state.activeId) {
    await createConversation();
  }
  showWelcome(false);

  const userLabel = `📎 Document envoyé : ${file.name}`;
  state.activeMessages.push({ role: "user", text: userLabel, sources: [], verified: false });
  renderMessages();
  enqueueSave(`/api/conversations/${state.activeId}/messages`, {
    role: "user", text: userLabel, client_message_id: generateClientId(),
  });

  const typingEl = showTypingIndicator();

  const formData = new FormData();
  formData.append("file", file);
  formData.append("mode", "summary");

  let aiMessage;
  try {
    const headers = {};
    if (state.token) headers["Authorization"] = `Bearer ${state.token}`;
    // Upload direct (pas via api()) : un envoi de fichier utilise FormData,
    // pas du JSON, et le navigateur doit fixer lui-même le Content-Type
    // (avec la "boundary" multipart) — jamais le forcer manuellement.
    const res = await fetch(`${API_BASE}/api/documents/analyze`, {
      method: "POST", headers, body: formData,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      throw new Error((data && data.error) || `Erreur serveur (${res.status})`);
    }
    aiMessage = {
      role: "ai",
      text: data.truncated
        ? `${data.answer}\n\n(Document tronqué car trop long — ce résumé ne couvre que le début.)`
        : data.answer,
      sources: [{ source: "Analyse de document", title: file.name, url: "" }],
      related_links: [], verified: false, verification_status: null,
    };
  } catch (err) {
    aiMessage = {
      role: "ai",
      text: `Je n'ai pas pu analyser ce document : ${err.message}`,
      sources: [], related_links: [], verified: false, verification_status: null,
    };
  }

  typingEl.remove();
  state.activeMessages.push(aiMessage);
  renderMessages();
  enqueueSave(`/api/conversations/${state.activeId}/messages`, {
    role: "ai", text: aiMessage.text, sources: aiMessage.sources, related_links: aiMessage.related_links,
    verified: aiMessage.verified, verification_status: aiMessage.verification_status,
    client_message_id: generateClientId(),
  });
}

async function sendMessage(text) {
  if (!state.activeId) {
    await createConversation();
  }

  showWelcome(false);

  // Est-ce une relance sur le sujet du jour (voir loadDailyBriefing) ? On ne
  // vérifie ça que sur le tout premier message de la conversation.
  const isFirstMessage = state.activeMessages.length === 0;
  const useTrendingDetail = isFirstMessage && isTrendingFollowUp(text);

  // Affichage optimiste du message utilisateur
  state.activeMessages.push({ role: "user", text, sources: [], verified: false });
  renderMessages();

  // Sauvegarde résiliente : mise en file, retry automatique en arrière-plan,
  // jamais perdu même si le serveur met du temps à répondre. Un identifiant
  // unique accompagne l'envoi : si le retry renvoie ce même message après
  // que la 1ère tentative ait en fait réussi côté serveur, le serveur le
  // reconnaît et ne le duplique pas.
  enqueueSave(`/api/conversations/${state.activeId}/messages`, {
    role: "user", text, client_message_id: generateClientId(),
  });
  refreshConversationList().catch(() => {}); // met à jour le titre si c'est le 1er message

  const typingEl = showTypingIndicator();

  // Mémoire conversationnelle (point 10) : on envoie les derniers échanges
  // pour permettre au serveur de résoudre "il", "et lui", "continue"... —
  // JAMAIS tout l'historique (borné ici ET re-vérifié côté serveur, qui ne
  // fait jamais confiance à cette limite côté client).
  const MAX_HISTORY_MESSAGES = 8;
  const history = state.activeMessages
    .slice(0, -1) // exclut le message qu'on vient de pousser au-dessus (la question posée maintenant)
    .slice(-MAX_HISTORY_MESSAGES)
    .map(m => ({ role: m.role, text: m.text }));

  let aiMessage;
  try {
    const data = useTrendingDetail
      ? await api("/api/trending-detail", { auth: false })
      : await api("/api/ask", { method: "POST", body: { query: text, history }, auth: false });

    if (data.error) {
      aiMessage = { role: "ai", text: `Erreur : ${data.error}`, sources: [], related_links: [], verified: false, verification_status: null };
    } else {
      aiMessage = {
        role: "ai",
        text: data.answer,
        sources: data.sources || [],
        related_links: data.related_links || [],
        verified: data.verified || false,
        verification_status: data.verification_status || null,
        resolved_query: data.resolved_query || null,
        tts_phrase_key: data.tts_phrase_key || null,
      };
    }
  } catch (err) {
    aiMessage = {
      role: "ai",
      text: "Impossible de contacter le serveur Veritas. Vérifie que le backend Python est bien lancé (python app.py) et accessible.",
      sources: [],
      related_links: [],
      verified: false,
      verification_status: null,
    };
  }

  // Le sujet du jour ne sert que pour la toute première relance de la conversation.
  state.trendingTopic = null;

  typingEl.remove();
  state.activeMessages.push(aiMessage);
  renderMessages();

  // Sauvegarde résiliente de la réponse IA (même mécanisme d'idempotence)
  enqueueSave(`/api/conversations/${state.activeId}/messages`, {
    role: "ai",
    text: aiMessage.text,
    sources: aiMessage.sources,
    related_links: aiMessage.related_links,
    verified: aiMessage.verified,
    verification_status: aiMessage.verification_status,
    client_message_id: generateClientId(),
  });
}

async function playFonAudio(payload, buttonEl) {
  const originalLabel = buttonEl.textContent;
  buttonEl.disabled = true;
  buttonEl.textContent = "⏳";
  try {
    const res = await fetch(`${API_BASE}/api/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      alert(errData.error || "Audio Fon indisponible pour l'instant.");
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    audio.play();
    audio.addEventListener("ended", () => URL.revokeObjectURL(url));
  } catch (err) {
    alert("Impossible de contacter le serveur pour l'audio Fon.");
  } finally {
    buttonEl.disabled = false;
    buttonEl.textContent = originalLabel;
  }
}

function showTypingIndicator() {
  const container = document.getElementById("messages");
  const wrapper = document.createElement("div");
  wrapper.className = "msg ai";
  wrapper.innerHTML = `
    <div class="msg-avatar">V</div>
    <div class="msg-bubble"><div class="typing"><span></span><span></span><span></span></div></div>
  `;
  container.appendChild(wrapper);
  scrollToBottom();
  return wrapper;
}

// ---------------------------------------------------------------------------
// Événements UI
// ---------------------------------------------------------------------------

function bindUIEvents() {
  const form = document.getElementById("chat-form");
  const input = document.getElementById("chat-input");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    autoResize(input);
    sendMessage(text);
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  input.addEventListener("input", () => autoResize(input));

  document.getElementById("new-chat-btn").addEventListener("click", () => {
    createConversation();
    closeMobileSidebar();
  });

  document.getElementById("menu-btn").addEventListener("click", openMobileSidebar);
  document.getElementById("overlay-mobile").addEventListener("click", closeMobileSidebar);
  document.getElementById("logout-btn").addEventListener("click", logout);

  document.getElementById("attach-btn").addEventListener("click", () => {
    document.getElementById("document-input").click();
  });
  document.getElementById("document-input").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) analyzeDocument(file);
    e.target.value = ""; // permet de re-sélectionner le même fichier ensuite
  });

  bindFonMicButton(input);
}

// ---------------------------------------------------------------------------
// Micro Fon (STT) — voir FON_TTS.md. Remplit le champ de saisie avec un
// BROUILLON à relire/corriger, n'envoie jamais automatiquement.
// ---------------------------------------------------------------------------

function bindFonMicButton(input) {
  const micBtn = document.getElementById("mic-fon-btn");
  let mediaRecorder = null;
  let chunks = [];
  let recording = false;

  micBtn.addEventListener("click", async () => {
    if (!recording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        chunks = [];
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
        mediaRecorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          micBtn.textContent = "⏳";
          micBtn.disabled = true;
          await transcribeAndFill(new Blob(chunks, { type: "audio/webm" }), input);
          micBtn.disabled = false;
          micBtn.textContent = "🎙️";
        };
        mediaRecorder.start();
        recording = true;
        micBtn.textContent = "⏹️";
        micBtn.title = "Arrêter l'enregistrement";
      } catch (err) {
        alert("Impossible d'accéder au micro : " + err.message);
      }
    } else {
      mediaRecorder.stop();
      recording = false;
      micBtn.title = "Parler en Fon (brouillon à relire avant envoi)";
    }
  });
}

async function transcribeAndFill(blob, input) {
  const formData = new FormData();
  formData.append("audio", blob, "recording.webm");
  try {
    const res = await fetch(`${API_BASE}/api/stt`, { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      alert(data.error || "Reconnaissance vocale Fon indisponible pour l'instant.");
      return;
    }
    // On remplit le champ avec la traduction française si disponible
    // (pour rejoindre la recherche existante), sinon avec le texte Fon brut.
    // Dans tous les cas : un BROUILLON, jamais envoyé automatiquement —
    // la personne doit relire/corriger puis appuyer elle-même sur envoyer.
    input.value = data.fr_text || data.fon_text || "";
    autoResize(input);
    input.focus();
    if (data.fon_text) {
      alert(
        `Brouillon (non vérifié) :\nFon entendu : « ${data.fon_text} »\n` +
        (data.fr_text ? `Traduit en : « ${data.fr_text} »\n` : "") +
        `\nRelis et corrige avant d'envoyer.`
      );
    } else if (data.warning) {
      alert(data.warning);
    }
  } catch (err) {
    alert("Impossible de contacter le serveur pour la reconnaissance vocale.");
  }
}

function autoResize(el) {
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 140) + "px";
}

function openMobileSidebar() {
  document.getElementById("sidebar").classList.add("open");
  document.getElementById("overlay-mobile").classList.add("open");
}
function closeMobileSidebar() {
  document.getElementById("sidebar").classList.remove("open");
  document.getElementById("overlay-mobile").classList.remove("open");
}

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initGoogleSignIn();
  initAuth();
});
